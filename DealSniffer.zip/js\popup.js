/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/get-infos.tsx":
/*!***************************!*\
  !*** ./src/get-infos.tsx ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const getInfos = (url) => {
    function getAmazonInfo() {
        const a = {};
        a.name = document.getElementById('productTitle')?.innerText ?? 'Not Found';
        a.price = Number(document
            .querySelector('#corePrice_feature_div .a-price-whole')
            ?.childNodes[0].nodeValue?.replace(',', '.'));
        a.imgUrl =
            document.querySelector('#imgTagWrapperId img')?.getAttribute('src') ??
                'Not Found';
        return a;
    }
    function getPcComponentesInfo() {
        const a = {};
        a.name = document.getElementById('pdp-title')?.innerText ?? 'Not Found';
        a.price = Number(document
            .getElementById('pdp-price-current-integer')
            ?.childNodes[0].nodeValue?.replace(',', '.'));
        a.imgUrl =
            document.querySelector('#pdp-section-images img')?.getAttribute('src') ??
                'Not Found';
        return a;
    }
    function getCdiscountInfo() {
        const a = {};
        a.name =
            document.querySelector('.fpTMain .fpDesCol h1')
                ?.innerText ?? 'Not Found';
        a.price = Number(document
            .querySelector('.fTopPrice  .fpPrice')
            ?.childNodes[0].nodeValue?.replace(',', '.'));
        a.imgUrl =
            document
                .querySelector('#fpZnPrdMain img#picture0')
                ?.getAttribute('src') ?? 'Not Found';
        return a;
    }
    function getGrosBillInfo() {
        const a = {};
        a.name =
            document.querySelector('.grb_fch-prod__content-title .grb_fch-prod__title')?.innerText ?? 'Not Found';
        a.price = Number(document
            .querySelector('.fiche-produit-r  .fiche_product_price > span')
            ?.childNodes[0].nodeValue?.replace('€', '')
            .replace(',', '.'));
        a.imgUrl =
            'https://www.grosbill.com' +
                document
                    .querySelector('#product_buy [data-swiper-slide-index="0"] img')
                    ?.getAttribute('src') ?? 'Not Found';
        return a;
    }
    function getCybertekInfo() {
        const a = {};
        a.name =
            document.querySelector('.fiche-produit__bloc-achat__container .title_fiche')?.innerText ?? 'Not Found';
        a.price = Number(document
            .querySelector('.fiche-produit__bloc-achat__prix  .fiche_product_price > span')
            ?.childNodes[0].nodeValue?.replace('€', '')
            .replace(',', '.'));
        a.imgUrl =
            document
                .querySelector('#fiche-produit__container-photos [data-swiper-slide-index="0"] img')
                ?.getAttribute('src') ?? 'Not Found';
        return a;
    }
    function getTopAchatInfo() {
        const a = {};
        a.name =
            document.querySelector('.ps-main__product-title')
                ?.innerText ?? 'Not Found';
        a.price = Number(document
            .querySelector('.ps-main__offer  .offer-price__price')
            ?.childNodes[0].nodeValue?.replace(' €', '')
            .replace(',', '.'));
        a.imgUrl =
            document
                .querySelector('.product-main-image.ps-main__main-image img')
                ?.getAttribute('src') ?? 'Not Found';
        return a;
    }
    function getInfoDiscountInfo() {
        const a = {};
        a.name =
            document.querySelector('.product-sheet_title')
                ?.innerText ?? 'Not Found';
        a.price = Number(document.querySelector('.product-sheet_buybox .product-sheet_buybox_offer_price').innerText
            ?.replace('\n', '')
            .replace(' €', '')
            .replace(',', '.'));
        a.imgUrl =
            'https://www.1fodiscount.com/' +
                document
                    .querySelector('.product-sheet_slideshow_scrollable img.product-sheet_slideshow_slide_img')
                    ?.getAttribute('src') ?? 'Not Found';
        return a;
    }
    function getReicheltInfo() {
        const a = {};
        a.name =
            document.querySelector('.av_articleheader [itemprop="name"]')?.innerText ?? 'Not Found';
        a.price = Number(document.querySelector('#av_price').innerText?.replace(',', '.'));
        a.imgUrl =
            document.querySelector('#gallery img')?.getAttribute('src') ??
                'Not Found';
        return a;
    }
    function getBPMPowerInfo() {
        const a = {};
        a.name =
            document.querySelector('.titleText h1')?.innerText ??
                'Not Found';
        a.price = Number(document.querySelector('#divProductInfoAndHelp .prezzoScheda').innerText
            .replace(' € ', '')
            .replace(',', '.'));
        a.imgUrl =
            document.querySelector('#mainImageDiv img')?.getAttribute('src') ??
                'Not Found';
        return a;
    }
    function getRDCInfo() {
        const a = {};
        a.name =
            document.querySelector('.product-name span')
                ?.innerText ?? 'Not Found';
        a.price = Number(document.querySelector('.product__price .dyn_prod_price').innerText
            .replace('€', '')
            .replaceAll(',', '.')
            .replaceAll(' ', ''));
        a.imgUrl =
            'https://www.rueducommerce.fr' +
                document.querySelector('#gallery .owl-item img')?.getAttribute('src') ??
                'Not Found';
        return a;
    }
    function getCasekingInfo() {
        const a = {};
        a.name =
            document.querySelector('#ck_detail  #detailbox h1')
                ?.innerText ?? 'Not Found';
        a.price = Number(document.querySelector('#ck_detail #buybox .article_details_price strong').innerText
            .replace('€', '')
            .replaceAll(',', '.')
            .replaceAll(' ', '')
            .replaceAll(' ', ''));
        a.imgUrl =
            'https:' +
                document
                    .querySelector('#ck_detail  #detailbox #img img')
                    ?.getAttribute('src') ?? 'Not Found';
        return a;
    }
    let a = {};
    if (url.includes('pccomponentes.fr')) {
        a = getPcComponentesInfo();
        a.vendor = 'PC Componentes';
    }
    else if (url.includes('pccomponentes.com')) {
        a = getPcComponentesInfo();
        a.vendor = 'PC Componentes ES';
    }
    else if (url.includes('amazon.fr')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon FR';
    }
    else if (url.includes('amazon.de')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon DE';
    }
    else if (url.includes('amazon.it')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon IT';
    }
    else if (url.includes('amazon.es')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon ES';
    }
    else if (url.includes('cdiscount.com')) {
        a = getCdiscountInfo();
        a.vendor = 'CDiscount';
    }
    else if (url.includes('grosbill.com')) {
        a = getGrosBillInfo();
        a.vendor = 'GrosBill';
    }
    else if (url.includes('cybertek.fr')) {
        a = getCybertekInfo();
        a.vendor = 'Cybertek';
    }
    else if (url.includes('topachat.com')) {
        a = getTopAchatInfo();
        a.vendor = 'TopAchat';
        if (a.price && a.price < 200) {
            a.fdp = 5.95;
        }
        if (a.price && a.price >= 1000) {
            a.warning = 'Demander un code de réduction 5% au CM sur twitter';
            a.price = Math.round(a.price * 0.95);
        }
    }
    else if (url.includes('1fodiscount.com')) {
        a = getInfoDiscountInfo();
        a.vendor = '1foDiscount';
    }
    else if (url.includes('reichelt.com')) {
        a = getReicheltInfo();
        a.vendor = 'Reichelt';
    }
    else if (url.includes('bpm-power.com')) {
        a = getBPMPowerInfo();
        a.vendor = 'BPM-Power';
        a.fdp = 20;
        a.warning = "Bien Vérifier sous 5j qu'il n'y a pas de dégat sur le colis";
    }
    else if (url.includes('rueducommerce.fr')) {
        a = getRDCInfo();
        a.vendor = 'Rue du Commerce';
    }
    else if (url.includes('caseking.de')) {
        a = getCasekingInfo();
        a.vendor = 'CaseKing';
        a.fdp = 7;
    }
    a.name = a.name?.replace('\n', ' ') ?? 'Not found';
    let selection = window?.getSelection()?.toString();
    a.name = selection != '' ? selection : a?.name?.replace('"', '');
    return a;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getInfos);


/***/ }),

/***/ "./src/popup.tsx":
/*!***********************!*\
  !*** ./src/popup.tsx ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom/client */ "./node_modules/react-dom/client.js");
/* harmony import */ var _preact_signals_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @preact/signals-react */ "./node_modules/@preact/signals-react/dist/signals.module.js");
/* harmony import */ var _get_infos__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./get-infos */ "./src/get-infos.tsx");
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material/Button */ "./node_modules/@mui/material/Button/Button.js");
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/material/TextField */ "./node_modules/@mui/material/TextField/TextField.js");
/* harmony import */ var _iconify_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @iconify/react */ "./node_modules/@iconify/react/dist/iconify.mjs");







const seller = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)('');
const article = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)({});
const preferedMethod = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)('none');
const amazonCode = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)('');
const cdiscountCode = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)('');
const rdcCode = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)('');
function generateExcelClipboardString() {
    let price = Math.round((article.value.price ?? 0) + (article.value.fdp ?? 0));
    let s = `=IMAGE("${article.value.imgUrl}")\t`;
    s += `=HYPERLINK("${article.value.url}";"${article.value.name}")\t`;
    s += `${article.value.vendor}\t`;
    s += `${price} €\t`;
    navigator.clipboard.writeText(s);
}
function generateDiscordClipboardString() {
    let price = Math.round((article.value.price ?? 0) + (article.value.fdp ?? 0));
    let s = `**${article.value.name}** à **${price}€** vendu par **${article.value.vendor}** :`;
    if (article.value.warning)
        s += `\n:warning:${article.value.warning}:warning:`;
    s += `\n${article.value.url}`;
    navigator.clipboard.writeText(s);
}
const cleanVendorUrl = (url, vendor = '') => {
    if (vendor.includes('Amazon')) {
        url = url.replace(/\?.+/, `?${amazonCode}`);
    }
    if (vendor.includes('CDiscount')) {
        url = url.replace(/\?.+/, `?${cdiscountCode}`);
    }
    if (vendor.includes('Rue du Commerce')) {
        url = url.replace(/\?.+/, `?${rdcCode}`);
    }
    return url;
};
const analyzeUrl = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const tab = tabs[0];
        chrome.scripting
            .executeScript({
            target: { tabId: tab.id },
            func: _get_infos__WEBPACK_IMPORTED_MODULE_3__["default"],
            args: [tab.url],
        })
            .then((injectionResults) => {
            for (const { frameId, result } of injectionResults) {
                article.value = result;
                article.value.url = cleanVendorUrl(tab.url, article.value.vendor);
            }
        });
    });
};
chrome.runtime.onMessage.addListener(function (request) {
    console.log('popu' + request);
});
const cardContent = {
    display: 'flex',
    'flex-direction': 'column',
    alignItems: 'strech',
    rowGap: '10px',
    minWidth: '800px',
};
const cardAction = {
    display: 'flex',
    columnGap: '5px',
};
const inputStyle = {
    width: '100%',
};
const priceContainerStyle = {
    display: 'flex',
    columnGap: '5px',
};
const priceInputStyle = {
    width: '80%',
};
const fdpInputStyle = {
    width: '20%',
};
const iconStyle = {
    marginRight: '2px',
};
const handleChange = (event) => {
    if (event.target.id === 'name')
        article.value = { ...article.value, name: event.target.value };
    if (event.target.id === 'url')
        article.value = { ...article.value, url: event.target.value };
    if (event.target.id === 'vendor')
        article.value = { ...article.value, vendor: event.target.value };
    if (event.target.id === 'price')
        article.value = { ...article.value, price: Number(event.target.value) };
    if (event.target.id === 'fdp')
        article.value = { ...article.value, fdp: Number(event.target.value) };
    if (event.target.id === 'imgUrl')
        article.value = { ...article.value, imgUrl: event.target.value };
    if (event.target.id === 'warning')
        article.value = { ...article.value, warning: event.target.value };
};
const Popup = () => {
    // chrome.action.setBadgeText({ text: count.toString() });
    (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.useSignalEffect)(() => {
        chrome.storage.sync.get({
            preferedMethod: 'discord',
            amazonCode: '',
            cdiscountCode: '',
        }, (items) => {
            preferedMethod.value = items.preferedMethod;
            amazonCode.value = items.amazonCode;
            cdiscountCode.value = items.cdiscountCode;
            rdcCode.value = items.rdcCode;
            console.log('get data from options');
            analyzeUrl();
        });
    });
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardContent },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardContent },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: inputStyle, onChange: handleChange, value: article.value.url, id: "url", multiline: true, label: "URL", defaultValue: "Error" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: inputStyle, onChange: handleChange, value: article.value.vendor, id: "vendor", label: "Seller", defaultValue: "Error" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: inputStyle, onChange: handleChange, value: article.value.name, id: "name", label: "Article", defaultValue: "Error" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: priceContainerStyle },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: priceInputStyle, onChange: handleChange, value: article.value.price, id: "price", type: "number", label: "Price", defaultValue: "404" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: fdpInputStyle, onChange: handleChange, value: article.value.fdp, id: "fdp", type: "number", label: "Frais De Port", defaultValue: "0" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: inputStyle, onChange: handleChange, value: article.value.warning, id: "warning", label: "Warning", multiline: true, maxRows: 4, defaultValue: " " }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: inputStyle, onChange: handleChange, value: article.value.imgUrl, id: "imgUrl", label: "Image Url", defaultValue: "Error" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardAction },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_6__["default"], { variant: "contained", onClick: analyzeUrl },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_4__.Icon, { style: iconStyle, icon: "charm:refresh", height: "30" }),
                    "Refresh"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_6__["default"], { variant: "contained", onClick: generateExcelClipboardString },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_4__.Icon, { icon: "simple-icons:googlesheets", height: "36" }),
                    "Generate Excel String"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_6__["default"], { variant: "contained", onClick: generateDiscordClipboardString },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_4__.Icon, { style: iconStyle, icon: "ic:baseline-discord", height: "30" }),
                    "Generate Discord String")))));
};
const root = (0,react_dom_client__WEBPACK_IMPORTED_MODULE_1__.createRoot)(document.getElementById('root'));
root.render(react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().StrictMode), null,
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Popup, null)));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"popup": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkdeal_sniffer"] = self["webpackChunkdeal_sniffer"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__("./src/popup.tsx")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpRUFBZSxRQUFRLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcE9FO0FBQ29CO0FBQ2tCO0FBQzdCO0FBQ087QUFDTTtBQUNWO0FBQ3RDLGVBQWUsNkRBQU07QUFDckIsZ0JBQWdCLDZEQUFNLEdBQUc7QUFDekIsdUJBQXVCLDZEQUFNO0FBQzdCLG1CQUFtQiw2REFBTTtBQUN6QixzQkFBc0IsNkRBQU07QUFDNUIsZ0JBQWdCLDZEQUFNO0FBQ3RCO0FBQ0E7QUFDQSx1QkFBdUIscUJBQXFCO0FBQzVDLHdCQUF3QixrQkFBa0IsRUFBRSxHQUFHLG1CQUFtQjtBQUNsRSxZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLE9BQU87QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsbUJBQW1CLFNBQVMsTUFBTSxrQkFBa0IscUJBQXFCO0FBQzFGO0FBQ0EsMkJBQTJCLHNCQUFzQjtBQUNqRCxjQUFjLGtCQUFrQjtBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQyxXQUFXO0FBQ2pEO0FBQ0E7QUFDQSxzQ0FBc0MsY0FBYztBQUNwRDtBQUNBO0FBQ0Esc0NBQXNDLFFBQVE7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsbUNBQW1DO0FBQzNEO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixlQUFlO0FBQ3JDLGtCQUFrQixrREFBUTtBQUMxQjtBQUNBLFNBQVM7QUFDVDtBQUNBLHlCQUF5QixrQkFBa0I7QUFDM0M7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBO0FBQ0Esb0NBQW9DLHdCQUF3QjtBQUM1RCxJQUFJLHNFQUFlO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0wsWUFBWSwwREFBbUIsQ0FBQyx1REFBYztBQUM5QyxRQUFRLDBEQUFtQixVQUFVLG9CQUFvQjtBQUN6RCxZQUFZLDBEQUFtQixVQUFVLG9CQUFvQjtBQUM3RCxnQkFBZ0IsMERBQW1CLENBQUMsK0RBQVMsSUFBSSxzSUFBc0k7QUFDdkwsZ0JBQWdCLDBEQUFtQixDQUFDLCtEQUFTLElBQUksOEhBQThIO0FBQy9LLGdCQUFnQiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLDJIQUEySDtBQUM1SyxnQkFBZ0IsMERBQW1CLFVBQVUsNEJBQTRCO0FBQ3pFLG9CQUFvQiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLDhJQUE4STtBQUNuTSxvQkFBb0IsMERBQW1CLENBQUMsK0RBQVMsSUFBSSw4SUFBOEk7QUFDbk0sZ0JBQWdCLDBEQUFtQixDQUFDLCtEQUFTLElBQUksMEpBQTBKO0FBQzNNLGdCQUFnQiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLGlJQUFpSTtBQUNsTCxZQUFZLDBEQUFtQixVQUFVLG1CQUFtQjtBQUM1RCxnQkFBZ0IsMERBQW1CLENBQUMsNERBQU0sSUFBSSwyQ0FBMkM7QUFDekYsb0JBQW9CLDBEQUFtQixDQUFDLGdEQUFJLElBQUksdURBQXVEO0FBQ3ZHO0FBQ0EsZ0JBQWdCLDBEQUFtQixDQUFDLDREQUFNLElBQUksNkRBQTZEO0FBQzNHLG9CQUFvQiwwREFBbUIsQ0FBQyxnREFBSSxJQUFJLGlEQUFpRDtBQUNqRztBQUNBLGdCQUFnQiwwREFBbUIsQ0FBQyw0REFBTSxJQUFJLCtEQUErRDtBQUM3RyxvQkFBb0IsMERBQW1CLENBQUMsZ0RBQUksSUFBSSw2REFBNkQ7QUFDN0c7QUFDQTtBQUNBLGFBQWEsNERBQVU7QUFDdkIsWUFBWSwwREFBbUIsQ0FBQyx5REFBZ0I7QUFDaEQsSUFBSSwwREFBbUI7Ozs7Ozs7VUNoSnZCO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOzs7OztXQzVCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLCtCQUErQix3Q0FBd0M7V0FDdkU7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQkFBaUIscUJBQXFCO1dBQ3RDO1dBQ0E7V0FDQSxrQkFBa0IscUJBQXFCO1dBQ3ZDO1dBQ0E7V0FDQSxLQUFLO1dBQ0w7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOzs7OztXQzNCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsaUNBQWlDLFdBQVc7V0FDNUM7V0FDQTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsR0FBRztXQUNIO1dBQ0E7V0FDQSxDQUFDOzs7OztXQ1BEOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7V0NOQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOzs7OztXQ0pBOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxNQUFNLHFCQUFxQjtXQUMzQjtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBO1dBQ0E7V0FDQTs7Ozs7VUVoREE7VUFDQTtVQUNBO1VBQ0E7VUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL2RlYWwtc25pZmZlci8uL3NyYy9nZXQtaW5mb3MudHN4Iiwid2VicGFjazovL2RlYWwtc25pZmZlci8uL3NyYy9wb3B1cC50c3giLCJ3ZWJwYWNrOi8vZGVhbC1zbmlmZmVyL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY2h1bmsgbG9hZGVkIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvZ2xvYmFsIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbm9kZSBtb2R1bGUgZGVjb3JhdG9yIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvanNvbnAgY2h1bmsgbG9hZGluZyIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgZ2V0SW5mb3MgPSAodXJsKSA9PiB7XG4gICAgZnVuY3Rpb24gZ2V0QW1hem9uSW5mbygpIHtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncHJvZHVjdFRpdGxlJyk/LmlubmVyVGV4dCA/PyAnTm90IEZvdW5kJztcbiAgICAgICAgYS5wcmljZSA9IE51bWJlcihkb2N1bWVudFxuICAgICAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoJyNjb3JlUHJpY2VfZmVhdHVyZV9kaXYgLmEtcHJpY2Utd2hvbGUnKVxuICAgICAgICAgICAgPy5jaGlsZE5vZGVzWzBdLm5vZGVWYWx1ZT8ucmVwbGFjZSgnLCcsICcuJykpO1xuICAgICAgICBhLmltZ1VybCA9XG4gICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjaW1nVGFnV3JhcHBlcklkIGltZycpPy5nZXRBdHRyaWJ1dGUoJ3NyYycpID8/XG4gICAgICAgICAgICAgICAgJ05vdCBGb3VuZCc7XG4gICAgICAgIHJldHVybiBhO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRQY0NvbXBvbmVudGVzSW5mbygpIHtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncGRwLXRpdGxlJyk/LmlubmVyVGV4dCA/PyAnTm90IEZvdW5kJztcbiAgICAgICAgYS5wcmljZSA9IE51bWJlcihkb2N1bWVudFxuICAgICAgICAgICAgLmdldEVsZW1lbnRCeUlkKCdwZHAtcHJpY2UtY3VycmVudC1pbnRlZ2VyJylcbiAgICAgICAgICAgID8uY2hpbGROb2Rlc1swXS5ub2RlVmFsdWU/LnJlcGxhY2UoJywnLCAnLicpKTtcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI3BkcC1zZWN0aW9uLWltYWdlcyBpbWcnKT8uZ2V0QXR0cmlidXRlKCdzcmMnKSA/P1xuICAgICAgICAgICAgICAgICdOb3QgRm91bmQnO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0Q2Rpc2NvdW50SW5mbygpIHtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPVxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmZwVE1haW4gLmZwRGVzQ29sIGgxJylcbiAgICAgICAgICAgICAgICA/LmlubmVyVGV4dCA/PyAnTm90IEZvdW5kJztcbiAgICAgICAgYS5wcmljZSA9IE51bWJlcihkb2N1bWVudFxuICAgICAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoJy5mVG9wUHJpY2UgIC5mcFByaWNlJylcbiAgICAgICAgICAgID8uY2hpbGROb2Rlc1swXS5ub2RlVmFsdWU/LnJlcGxhY2UoJywnLCAnLicpKTtcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgZG9jdW1lbnRcbiAgICAgICAgICAgICAgICAucXVlcnlTZWxlY3RvcignI2ZwWm5QcmRNYWluIGltZyNwaWN0dXJlMCcpXG4gICAgICAgICAgICAgICAgPy5nZXRBdHRyaWJ1dGUoJ3NyYycpID8/ICdOb3QgRm91bmQnO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0R3Jvc0JpbGxJbmZvKCkge1xuICAgICAgICBjb25zdCBhID0ge307XG4gICAgICAgIGEubmFtZSA9XG4gICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZ3JiX2ZjaC1wcm9kX19jb250ZW50LXRpdGxlIC5ncmJfZmNoLXByb2RfX3RpdGxlJyk/LmlubmVyVGV4dCA/PyAnTm90IEZvdW5kJztcbiAgICAgICAgYS5wcmljZSA9IE51bWJlcihkb2N1bWVudFxuICAgICAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoJy5maWNoZS1wcm9kdWl0LXIgIC5maWNoZV9wcm9kdWN0X3ByaWNlID4gc3BhbicpXG4gICAgICAgICAgICA/LmNoaWxkTm9kZXNbMF0ubm9kZVZhbHVlPy5yZXBsYWNlKCfigqwnLCAnJylcbiAgICAgICAgICAgIC5yZXBsYWNlKCcsJywgJy4nKSk7XG4gICAgICAgIGEuaW1nVXJsID1cbiAgICAgICAgICAgICdodHRwczovL3d3dy5ncm9zYmlsbC5jb20nICtcbiAgICAgICAgICAgICAgICBkb2N1bWVudFxuICAgICAgICAgICAgICAgICAgICAucXVlcnlTZWxlY3RvcignI3Byb2R1Y3RfYnV5IFtkYXRhLXN3aXBlci1zbGlkZS1pbmRleD1cIjBcIl0gaW1nJylcbiAgICAgICAgICAgICAgICAgICAgPy5nZXRBdHRyaWJ1dGUoJ3NyYycpID8/ICdOb3QgRm91bmQnO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0Q3liZXJ0ZWtJbmZvKCkge1xuICAgICAgICBjb25zdCBhID0ge307XG4gICAgICAgIGEubmFtZSA9XG4gICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZmljaGUtcHJvZHVpdF9fYmxvYy1hY2hhdF9fY29udGFpbmVyIC50aXRsZV9maWNoZScpPy5pbm5lclRleHQgPz8gJ05vdCBGb3VuZCc7XG4gICAgICAgIGEucHJpY2UgPSBOdW1iZXIoZG9jdW1lbnRcbiAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcuZmljaGUtcHJvZHVpdF9fYmxvYy1hY2hhdF9fcHJpeCAgLmZpY2hlX3Byb2R1Y3RfcHJpY2UgPiBzcGFuJylcbiAgICAgICAgICAgID8uY2hpbGROb2Rlc1swXS5ub2RlVmFsdWU/LnJlcGxhY2UoJ+KCrCcsICcnKVxuICAgICAgICAgICAgLnJlcGxhY2UoJywnLCAnLicpKTtcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgZG9jdW1lbnRcbiAgICAgICAgICAgICAgICAucXVlcnlTZWxlY3RvcignI2ZpY2hlLXByb2R1aXRfX2NvbnRhaW5lci1waG90b3MgW2RhdGEtc3dpcGVyLXNsaWRlLWluZGV4PVwiMFwiXSBpbWcnKVxuICAgICAgICAgICAgICAgID8uZ2V0QXR0cmlidXRlKCdzcmMnKSA/PyAnTm90IEZvdW5kJztcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldFRvcEFjaGF0SW5mbygpIHtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPVxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLnBzLW1haW5fX3Byb2R1Y3QtdGl0bGUnKVxuICAgICAgICAgICAgICAgID8uaW5uZXJUZXh0ID8/ICdOb3QgRm91bmQnO1xuICAgICAgICBhLnByaWNlID0gTnVtYmVyKGRvY3VtZW50XG4gICAgICAgICAgICAucXVlcnlTZWxlY3RvcignLnBzLW1haW5fX29mZmVyICAub2ZmZXItcHJpY2VfX3ByaWNlJylcbiAgICAgICAgICAgID8uY2hpbGROb2Rlc1swXS5ub2RlVmFsdWU/LnJlcGxhY2UoJ8Kg4oKsJywgJycpXG4gICAgICAgICAgICAucmVwbGFjZSgnLCcsICcuJykpO1xuICAgICAgICBhLmltZ1VybCA9XG4gICAgICAgICAgICBkb2N1bWVudFxuICAgICAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcucHJvZHVjdC1tYWluLWltYWdlLnBzLW1haW5fX21haW4taW1hZ2UgaW1nJylcbiAgICAgICAgICAgICAgICA/LmdldEF0dHJpYnV0ZSgnc3JjJykgPz8gJ05vdCBGb3VuZCc7XG4gICAgICAgIHJldHVybiBhO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRJbmZvRGlzY291bnRJbmZvKCkge1xuICAgICAgICBjb25zdCBhID0ge307XG4gICAgICAgIGEubmFtZSA9XG4gICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcucHJvZHVjdC1zaGVldF90aXRsZScpXG4gICAgICAgICAgICAgICAgPy5pbm5lclRleHQgPz8gJ05vdCBGb3VuZCc7XG4gICAgICAgIGEucHJpY2UgPSBOdW1iZXIoZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLnByb2R1Y3Qtc2hlZXRfYnV5Ym94IC5wcm9kdWN0LXNoZWV0X2J1eWJveF9vZmZlcl9wcmljZScpLmlubmVyVGV4dFxuICAgICAgICAgICAgPy5yZXBsYWNlKCdcXG4nLCAnJylcbiAgICAgICAgICAgIC5yZXBsYWNlKCcg4oKsJywgJycpXG4gICAgICAgICAgICAucmVwbGFjZSgnLCcsICcuJykpO1xuICAgICAgICBhLmltZ1VybCA9XG4gICAgICAgICAgICAnaHR0cHM6Ly93d3cuMWZvZGlzY291bnQuY29tLycgK1xuICAgICAgICAgICAgICAgIGRvY3VtZW50XG4gICAgICAgICAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcucHJvZHVjdC1zaGVldF9zbGlkZXNob3dfc2Nyb2xsYWJsZSBpbWcucHJvZHVjdC1zaGVldF9zbGlkZXNob3dfc2xpZGVfaW1nJylcbiAgICAgICAgICAgICAgICAgICAgPy5nZXRBdHRyaWJ1dGUoJ3NyYycpID8/ICdOb3QgRm91bmQnO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0UmVpY2hlbHRJbmZvKCkge1xuICAgICAgICBjb25zdCBhID0ge307XG4gICAgICAgIGEubmFtZSA9XG4gICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuYXZfYXJ0aWNsZWhlYWRlciBbaXRlbXByb3A9XCJuYW1lXCJdJyk/LmlubmVyVGV4dCA/PyAnTm90IEZvdW5kJztcbiAgICAgICAgYS5wcmljZSA9IE51bWJlcihkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjYXZfcHJpY2UnKS5pbm5lclRleHQ/LnJlcGxhY2UoJywnLCAnLicpKTtcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2dhbGxlcnkgaW1nJyk/LmdldEF0dHJpYnV0ZSgnc3JjJykgPz9cbiAgICAgICAgICAgICAgICAnTm90IEZvdW5kJztcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldEJQTVBvd2VySW5mbygpIHtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPVxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLnRpdGxlVGV4dCBoMScpPy5pbm5lclRleHQgPz9cbiAgICAgICAgICAgICAgICAnTm90IEZvdW5kJztcbiAgICAgICAgYS5wcmljZSA9IE51bWJlcihkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjZGl2UHJvZHVjdEluZm9BbmRIZWxwIC5wcmV6em9TY2hlZGEnKS5pbm5lclRleHRcbiAgICAgICAgICAgIC5yZXBsYWNlKCcg4oKsICcsICcnKVxuICAgICAgICAgICAgLnJlcGxhY2UoJywnLCAnLicpKTtcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI21haW5JbWFnZURpdiBpbWcnKT8uZ2V0QXR0cmlidXRlKCdzcmMnKSA/P1xuICAgICAgICAgICAgICAgICdOb3QgRm91bmQnO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0UkRDSW5mbygpIHtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPVxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLnByb2R1Y3QtbmFtZSBzcGFuJylcbiAgICAgICAgICAgICAgICA/LmlubmVyVGV4dCA/PyAnTm90IEZvdW5kJztcbiAgICAgICAgYS5wcmljZSA9IE51bWJlcihkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcucHJvZHVjdF9fcHJpY2UgLmR5bl9wcm9kX3ByaWNlJykuaW5uZXJUZXh0XG4gICAgICAgICAgICAucmVwbGFjZSgn4oKsJywgJycpXG4gICAgICAgICAgICAucmVwbGFjZUFsbCgnLCcsICcuJylcbiAgICAgICAgICAgIC5yZXBsYWNlQWxsKCcgJywgJycpKTtcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgJ2h0dHBzOi8vd3d3LnJ1ZWR1Y29tbWVyY2UuZnInICtcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjZ2FsbGVyeSAub3dsLWl0ZW0gaW1nJyk/LmdldEF0dHJpYnV0ZSgnc3JjJykgPz9cbiAgICAgICAgICAgICAgICAnTm90IEZvdW5kJztcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldENhc2VraW5nSW5mbygpIHtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPVxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2NrX2RldGFpbCAgI2RldGFpbGJveCBoMScpXG4gICAgICAgICAgICAgICAgPy5pbm5lclRleHQgPz8gJ05vdCBGb3VuZCc7XG4gICAgICAgIGEucHJpY2UgPSBOdW1iZXIoZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2NrX2RldGFpbCAjYnV5Ym94IC5hcnRpY2xlX2RldGFpbHNfcHJpY2Ugc3Ryb25nJykuaW5uZXJUZXh0XG4gICAgICAgICAgICAucmVwbGFjZSgn4oKsJywgJycpXG4gICAgICAgICAgICAucmVwbGFjZUFsbCgnLCcsICcuJylcbiAgICAgICAgICAgIC5yZXBsYWNlQWxsKCcgJywgJycpXG4gICAgICAgICAgICAucmVwbGFjZUFsbCgnwqAnLCAnJykpO1xuICAgICAgICBhLmltZ1VybCA9XG4gICAgICAgICAgICAnaHR0cHM6JyArXG4gICAgICAgICAgICAgICAgZG9jdW1lbnRcbiAgICAgICAgICAgICAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoJyNja19kZXRhaWwgICNkZXRhaWxib3ggI2ltZyBpbWcnKVxuICAgICAgICAgICAgICAgICAgICA/LmdldEF0dHJpYnV0ZSgnc3JjJykgPz8gJ05vdCBGb3VuZCc7XG4gICAgICAgIHJldHVybiBhO1xuICAgIH1cbiAgICBsZXQgYSA9IHt9O1xuICAgIGlmICh1cmwuaW5jbHVkZXMoJ3BjY29tcG9uZW50ZXMuZnInKSkge1xuICAgICAgICBhID0gZ2V0UGNDb21wb25lbnRlc0luZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnUEMgQ29tcG9uZW50ZXMnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ3BjY29tcG9uZW50ZXMuY29tJykpIHtcbiAgICAgICAgYSA9IGdldFBjQ29tcG9uZW50ZXNJbmZvKCk7XG4gICAgICAgIGEudmVuZG9yID0gJ1BDIENvbXBvbmVudGVzIEVTJztcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdhbWF6b24uZnInKSkge1xuICAgICAgICBhID0gZ2V0QW1hem9uSW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdBbWF6b24gRlInO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2FtYXpvbi5kZScpKSB7XG4gICAgICAgIGEgPSBnZXRBbWF6b25JbmZvKCk7XG4gICAgICAgIGEudmVuZG9yID0gJ0FtYXpvbiBERSc7XG4gICAgfVxuICAgIGVsc2UgaWYgKHVybC5pbmNsdWRlcygnYW1hem9uLml0JykpIHtcbiAgICAgICAgYSA9IGdldEFtYXpvbkluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnQW1hem9uIElUJztcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdhbWF6b24uZXMnKSkge1xuICAgICAgICBhID0gZ2V0QW1hem9uSW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdBbWF6b24gRVMnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2NkaXNjb3VudC5jb20nKSkge1xuICAgICAgICBhID0gZ2V0Q2Rpc2NvdW50SW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdDRGlzY291bnQnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2dyb3NiaWxsLmNvbScpKSB7XG4gICAgICAgIGEgPSBnZXRHcm9zQmlsbEluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnR3Jvc0JpbGwnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2N5YmVydGVrLmZyJykpIHtcbiAgICAgICAgYSA9IGdldEN5YmVydGVrSW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdDeWJlcnRlayc7XG4gICAgfVxuICAgIGVsc2UgaWYgKHVybC5pbmNsdWRlcygndG9wYWNoYXQuY29tJykpIHtcbiAgICAgICAgYSA9IGdldFRvcEFjaGF0SW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdUb3BBY2hhdCc7XG4gICAgICAgIGlmIChhLnByaWNlICYmIGEucHJpY2UgPCAyMDApIHtcbiAgICAgICAgICAgIGEuZmRwID0gNS45NTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYS5wcmljZSAmJiBhLnByaWNlID49IDEwMDApIHtcbiAgICAgICAgICAgIGEud2FybmluZyA9ICdEZW1hbmRlciB1biBjb2RlIGRlIHLDqWR1Y3Rpb24gNSUgYXUgQ00gc3VyIHR3aXR0ZXInO1xuICAgICAgICAgICAgYS5wcmljZSA9IE1hdGgucm91bmQoYS5wcmljZSAqIDAuOTUpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2UgaWYgKHVybC5pbmNsdWRlcygnMWZvZGlzY291bnQuY29tJykpIHtcbiAgICAgICAgYSA9IGdldEluZm9EaXNjb3VudEluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnMWZvRGlzY291bnQnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ3JlaWNoZWx0LmNvbScpKSB7XG4gICAgICAgIGEgPSBnZXRSZWljaGVsdEluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnUmVpY2hlbHQnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2JwbS1wb3dlci5jb20nKSkge1xuICAgICAgICBhID0gZ2V0QlBNUG93ZXJJbmZvKCk7XG4gICAgICAgIGEudmVuZG9yID0gJ0JQTS1Qb3dlcic7XG4gICAgICAgIGEuZmRwID0gMjA7XG4gICAgICAgIGEud2FybmluZyA9IFwiQmllbiBWw6lyaWZpZXIgc291cyA1aiBxdSdpbCBuJ3kgYSBwYXMgZGUgZMOpZ2F0IHN1ciBsZSBjb2xpc1wiO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ3J1ZWR1Y29tbWVyY2UuZnInKSkge1xuICAgICAgICBhID0gZ2V0UkRDSW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdSdWUgZHUgQ29tbWVyY2UnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2Nhc2VraW5nLmRlJykpIHtcbiAgICAgICAgYSA9IGdldENhc2VraW5nSW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdDYXNlS2luZyc7XG4gICAgICAgIGEuZmRwID0gNztcbiAgICB9XG4gICAgYS5uYW1lID0gYS5uYW1lPy5yZXBsYWNlKCdcXG4nLCAnICcpID8/ICdOb3QgZm91bmQnO1xuICAgIGxldCBzZWxlY3Rpb24gPSB3aW5kb3c/LmdldFNlbGVjdGlvbigpPy50b1N0cmluZygpO1xuICAgIGEubmFtZSA9IHNlbGVjdGlvbiAhPSAnJyA/IHNlbGVjdGlvbiA6IGE/Lm5hbWU/LnJlcGxhY2UoJ1wiJywgJycpO1xuICAgIHJldHVybiBhO1xufTtcbmV4cG9ydCBkZWZhdWx0IGdldEluZm9zO1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNyZWF0ZVJvb3QgfSBmcm9tICdyZWFjdC1kb20vY2xpZW50JztcbmltcG9ydCB7IHNpZ25hbCwgdXNlU2lnbmFsRWZmZWN0IH0gZnJvbSAnQHByZWFjdC9zaWduYWxzLXJlYWN0JztcbmltcG9ydCBnZXRJbmZvcyBmcm9tICcuL2dldC1pbmZvcyc7XG5pbXBvcnQgQnV0dG9uIGZyb20gJ0BtdWkvbWF0ZXJpYWwvQnV0dG9uJztcbmltcG9ydCBUZXh0RmllbGQgZnJvbSAnQG11aS9tYXRlcmlhbC9UZXh0RmllbGQnO1xuaW1wb3J0IHsgSWNvbiB9IGZyb20gJ0BpY29uaWZ5L3JlYWN0JztcbmNvbnN0IHNlbGxlciA9IHNpZ25hbCgnJyk7XG5jb25zdCBhcnRpY2xlID0gc2lnbmFsKHt9KTtcbmNvbnN0IHByZWZlcmVkTWV0aG9kID0gc2lnbmFsKCdub25lJyk7XG5jb25zdCBhbWF6b25Db2RlID0gc2lnbmFsKCcnKTtcbmNvbnN0IGNkaXNjb3VudENvZGUgPSBzaWduYWwoJycpO1xuY29uc3QgcmRjQ29kZSA9IHNpZ25hbCgnJyk7XG5mdW5jdGlvbiBnZW5lcmF0ZUV4Y2VsQ2xpcGJvYXJkU3RyaW5nKCkge1xuICAgIGxldCBwcmljZSA9IE1hdGgucm91bmQoKGFydGljbGUudmFsdWUucHJpY2UgPz8gMCkgKyAoYXJ0aWNsZS52YWx1ZS5mZHAgPz8gMCkpO1xuICAgIGxldCBzID0gYD1JTUFHRShcIiR7YXJ0aWNsZS52YWx1ZS5pbWdVcmx9XCIpXFx0YDtcbiAgICBzICs9IGA9SFlQRVJMSU5LKFwiJHthcnRpY2xlLnZhbHVlLnVybH1cIjtcIiR7YXJ0aWNsZS52YWx1ZS5uYW1lfVwiKVxcdGA7XG4gICAgcyArPSBgJHthcnRpY2xlLnZhbHVlLnZlbmRvcn1cXHRgO1xuICAgIHMgKz0gYCR7cHJpY2V9IOKCrFxcdGA7XG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQocyk7XG59XG5mdW5jdGlvbiBnZW5lcmF0ZURpc2NvcmRDbGlwYm9hcmRTdHJpbmcoKSB7XG4gICAgbGV0IHByaWNlID0gTWF0aC5yb3VuZCgoYXJ0aWNsZS52YWx1ZS5wcmljZSA/PyAwKSArIChhcnRpY2xlLnZhbHVlLmZkcCA/PyAwKSk7XG4gICAgbGV0IHMgPSBgKioke2FydGljbGUudmFsdWUubmFtZX0qKiDDoCAqKiR7cHJpY2V94oKsKiogdmVuZHUgcGFyICoqJHthcnRpY2xlLnZhbHVlLnZlbmRvcn0qKiA6YDtcbiAgICBpZiAoYXJ0aWNsZS52YWx1ZS53YXJuaW5nKVxuICAgICAgICBzICs9IGBcXG46d2FybmluZzoke2FydGljbGUudmFsdWUud2FybmluZ306d2FybmluZzpgO1xuICAgIHMgKz0gYFxcbiR7YXJ0aWNsZS52YWx1ZS51cmx9YDtcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChzKTtcbn1cbmNvbnN0IGNsZWFuVmVuZG9yVXJsID0gKHVybCwgdmVuZG9yID0gJycpID0+IHtcbiAgICBpZiAodmVuZG9yLmluY2x1ZGVzKCdBbWF6b24nKSkge1xuICAgICAgICB1cmwgPSB1cmwucmVwbGFjZSgvXFw/LisvLCBgPyR7YW1hem9uQ29kZX1gKTtcbiAgICB9XG4gICAgaWYgKHZlbmRvci5pbmNsdWRlcygnQ0Rpc2NvdW50JykpIHtcbiAgICAgICAgdXJsID0gdXJsLnJlcGxhY2UoL1xcPy4rLywgYD8ke2NkaXNjb3VudENvZGV9YCk7XG4gICAgfVxuICAgIGlmICh2ZW5kb3IuaW5jbHVkZXMoJ1J1ZSBkdSBDb21tZXJjZScpKSB7XG4gICAgICAgIHVybCA9IHVybC5yZXBsYWNlKC9cXD8uKy8sIGA/JHtyZGNDb2RlfWApO1xuICAgIH1cbiAgICByZXR1cm4gdXJsO1xufTtcbmNvbnN0IGFuYWx5emVVcmwgPSAoKSA9PiB7XG4gICAgY2hyb21lLnRhYnMucXVlcnkoeyBhY3RpdmU6IHRydWUsIGN1cnJlbnRXaW5kb3c6IHRydWUgfSwgZnVuY3Rpb24gKHRhYnMpIHtcbiAgICAgICAgY29uc3QgdGFiID0gdGFic1swXTtcbiAgICAgICAgY2hyb21lLnNjcmlwdGluZ1xuICAgICAgICAgICAgLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgICAgIGZ1bmM6IGdldEluZm9zLFxuICAgICAgICAgICAgYXJnczogW3RhYi51cmxdLFxuICAgICAgICB9KVxuICAgICAgICAgICAgLnRoZW4oKGluamVjdGlvblJlc3VsdHMpID0+IHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgeyBmcmFtZUlkLCByZXN1bHQgfSBvZiBpbmplY3Rpb25SZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgYXJ0aWNsZS52YWx1ZSA9IHJlc3VsdDtcbiAgICAgICAgICAgICAgICBhcnRpY2xlLnZhbHVlLnVybCA9IGNsZWFuVmVuZG9yVXJsKHRhYi51cmwsIGFydGljbGUudmFsdWUudmVuZG9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSk7XG59O1xuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKGZ1bmN0aW9uIChyZXF1ZXN0KSB7XG4gICAgY29uc29sZS5sb2coJ3BvcHUnICsgcmVxdWVzdCk7XG59KTtcbmNvbnN0IGNhcmRDb250ZW50ID0ge1xuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAnZmxleC1kaXJlY3Rpb24nOiAnY29sdW1uJyxcbiAgICBhbGlnbkl0ZW1zOiAnc3RyZWNoJyxcbiAgICByb3dHYXA6ICcxMHB4JyxcbiAgICBtaW5XaWR0aDogJzgwMHB4Jyxcbn07XG5jb25zdCBjYXJkQWN0aW9uID0ge1xuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBjb2x1bW5HYXA6ICc1cHgnLFxufTtcbmNvbnN0IGlucHV0U3R5bGUgPSB7XG4gICAgd2lkdGg6ICcxMDAlJyxcbn07XG5jb25zdCBwcmljZUNvbnRhaW5lclN0eWxlID0ge1xuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBjb2x1bW5HYXA6ICc1cHgnLFxufTtcbmNvbnN0IHByaWNlSW5wdXRTdHlsZSA9IHtcbiAgICB3aWR0aDogJzgwJScsXG59O1xuY29uc3QgZmRwSW5wdXRTdHlsZSA9IHtcbiAgICB3aWR0aDogJzIwJScsXG59O1xuY29uc3QgaWNvblN0eWxlID0ge1xuICAgIG1hcmdpblJpZ2h0OiAnMnB4Jyxcbn07XG5jb25zdCBoYW5kbGVDaGFuZ2UgPSAoZXZlbnQpID0+IHtcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAnbmFtZScpXG4gICAgICAgIGFydGljbGUudmFsdWUgPSB7IC4uLmFydGljbGUudmFsdWUsIG5hbWU6IGV2ZW50LnRhcmdldC52YWx1ZSB9O1xuICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICd1cmwnKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0geyAuLi5hcnRpY2xlLnZhbHVlLCB1cmw6IGV2ZW50LnRhcmdldC52YWx1ZSB9O1xuICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICd2ZW5kb3InKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0geyAuLi5hcnRpY2xlLnZhbHVlLCB2ZW5kb3I6IGV2ZW50LnRhcmdldC52YWx1ZSB9O1xuICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICdwcmljZScpXG4gICAgICAgIGFydGljbGUudmFsdWUgPSB7IC4uLmFydGljbGUudmFsdWUsIHByaWNlOiBOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKSB9O1xuICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICdmZHAnKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0geyAuLi5hcnRpY2xlLnZhbHVlLCBmZHA6IE51bWJlcihldmVudC50YXJnZXQudmFsdWUpIH07XG4gICAgaWYgKGV2ZW50LnRhcmdldC5pZCA9PT0gJ2ltZ1VybCcpXG4gICAgICAgIGFydGljbGUudmFsdWUgPSB7IC4uLmFydGljbGUudmFsdWUsIGltZ1VybDogZXZlbnQudGFyZ2V0LnZhbHVlIH07XG4gICAgaWYgKGV2ZW50LnRhcmdldC5pZCA9PT0gJ3dhcm5pbmcnKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0geyAuLi5hcnRpY2xlLnZhbHVlLCB3YXJuaW5nOiBldmVudC50YXJnZXQudmFsdWUgfTtcbn07XG5jb25zdCBQb3B1cCA9ICgpID0+IHtcbiAgICAvLyBjaHJvbWUuYWN0aW9uLnNldEJhZGdlVGV4dCh7IHRleHQ6IGNvdW50LnRvU3RyaW5nKCkgfSk7XG4gICAgdXNlU2lnbmFsRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoe1xuICAgICAgICAgICAgcHJlZmVyZWRNZXRob2Q6ICdkaXNjb3JkJyxcbiAgICAgICAgICAgIGFtYXpvbkNvZGU6ICcnLFxuICAgICAgICAgICAgY2Rpc2NvdW50Q29kZTogJycsXG4gICAgICAgIH0sIChpdGVtcykgPT4ge1xuICAgICAgICAgICAgcHJlZmVyZWRNZXRob2QudmFsdWUgPSBpdGVtcy5wcmVmZXJlZE1ldGhvZDtcbiAgICAgICAgICAgIGFtYXpvbkNvZGUudmFsdWUgPSBpdGVtcy5hbWF6b25Db2RlO1xuICAgICAgICAgICAgY2Rpc2NvdW50Q29kZS52YWx1ZSA9IGl0ZW1zLmNkaXNjb3VudENvZGU7XG4gICAgICAgICAgICByZGNDb2RlLnZhbHVlID0gaXRlbXMucmRjQ29kZTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdnZXQgZGF0YSBmcm9tIG9wdGlvbnMnKTtcbiAgICAgICAgICAgIGFuYWx5emVVcmwoKTtcbiAgICAgICAgfSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KFJlYWN0LkZyYWdtZW50LCBudWxsLFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IGNhcmRDb250ZW50IH0sXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IGNhcmRDb250ZW50IH0sXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIHZhbHVlOiBhcnRpY2xlLnZhbHVlLnVybCwgaWQ6IFwidXJsXCIsIG11bHRpbGluZTogdHJ1ZSwgbGFiZWw6IFwiVVJMXCIsIGRlZmF1bHRWYWx1ZTogXCJFcnJvclwiIH0pLFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dEZpZWxkLCB7IHN0eWxlOiBpbnB1dFN0eWxlLCBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLCB2YWx1ZTogYXJ0aWNsZS52YWx1ZS52ZW5kb3IsIGlkOiBcInZlbmRvclwiLCBsYWJlbDogXCJTZWxsZXJcIiwgZGVmYXVsdFZhbHVlOiBcIkVycm9yXCIgfSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIHZhbHVlOiBhcnRpY2xlLnZhbHVlLm5hbWUsIGlkOiBcIm5hbWVcIiwgbGFiZWw6IFwiQXJ0aWNsZVwiLCBkZWZhdWx0VmFsdWU6IFwiRXJyb3JcIiB9KSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IHByaWNlQ29udGFpbmVyU3R5bGUgfSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IHByaWNlSW5wdXRTdHlsZSwgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSwgdmFsdWU6IGFydGljbGUudmFsdWUucHJpY2UsIGlkOiBcInByaWNlXCIsIHR5cGU6IFwibnVtYmVyXCIsIGxhYmVsOiBcIlByaWNlXCIsIGRlZmF1bHRWYWx1ZTogXCI0MDRcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGZkcElucHV0U3R5bGUsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIHZhbHVlOiBhcnRpY2xlLnZhbHVlLmZkcCwgaWQ6IFwiZmRwXCIsIHR5cGU6IFwibnVtYmVyXCIsIGxhYmVsOiBcIkZyYWlzIERlIFBvcnRcIiwgZGVmYXVsdFZhbHVlOiBcIjBcIiB9KSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIHZhbHVlOiBhcnRpY2xlLnZhbHVlLndhcm5pbmcsIGlkOiBcIndhcm5pbmdcIiwgbGFiZWw6IFwiV2FybmluZ1wiLCBtdWx0aWxpbmU6IHRydWUsIG1heFJvd3M6IDQsIGRlZmF1bHRWYWx1ZTogXCIgXCIgfSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIHZhbHVlOiBhcnRpY2xlLnZhbHVlLmltZ1VybCwgaWQ6IFwiaW1nVXJsXCIsIGxhYmVsOiBcIkltYWdlIFVybFwiLCBkZWZhdWx0VmFsdWU6IFwiRXJyb3JcIiB9KSksXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IGNhcmRBY3Rpb24gfSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgeyB2YXJpYW50OiBcImNvbnRhaW5lZFwiLCBvbkNsaWNrOiBhbmFseXplVXJsIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbiwgeyBzdHlsZTogaWNvblN0eWxlLCBpY29uOiBcImNoYXJtOnJlZnJlc2hcIiwgaGVpZ2h0OiBcIjMwXCIgfSksXG4gICAgICAgICAgICAgICAgICAgIFwiUmVmcmVzaFwiKSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgeyB2YXJpYW50OiBcImNvbnRhaW5lZFwiLCBvbkNsaWNrOiBnZW5lcmF0ZUV4Y2VsQ2xpcGJvYXJkU3RyaW5nIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbiwgeyBpY29uOiBcInNpbXBsZS1pY29uczpnb29nbGVzaGVldHNcIiwgaGVpZ2h0OiBcIjM2XCIgfSksXG4gICAgICAgICAgICAgICAgICAgIFwiR2VuZXJhdGUgRXhjZWwgU3RyaW5nXCIpLFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uLCB7IHZhcmlhbnQ6IFwiY29udGFpbmVkXCIsIG9uQ2xpY2s6IGdlbmVyYXRlRGlzY29yZENsaXBib2FyZFN0cmluZyB9LFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEljb24sIHsgc3R5bGU6IGljb25TdHlsZSwgaWNvbjogXCJpYzpiYXNlbGluZS1kaXNjb3JkXCIsIGhlaWdodDogXCIzMFwiIH0pLFxuICAgICAgICAgICAgICAgICAgICBcIkdlbmVyYXRlIERpc2NvcmQgU3RyaW5nXCIpKSkpKTtcbn07XG5jb25zdCByb290ID0gY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpKTtcbnJvb3QucmVuZGVyKFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuU3RyaWN0TW9kZSwgbnVsbCxcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFBvcHVwLCBudWxsKSkpO1xuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHRpZDogbW9kdWxlSWQsXG5cdFx0bG9hZGVkOiBmYWxzZSxcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG5cdG1vZHVsZS5sb2FkZWQgPSB0cnVlO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuLy8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbl9fd2VicGFja19yZXF1aXJlX18ubSA9IF9fd2VicGFja19tb2R1bGVzX187XG5cbiIsInZhciBkZWZlcnJlZCA9IFtdO1xuX193ZWJwYWNrX3JlcXVpcmVfXy5PID0gKHJlc3VsdCwgY2h1bmtJZHMsIGZuLCBwcmlvcml0eSkgPT4ge1xuXHRpZihjaHVua0lkcykge1xuXHRcdHByaW9yaXR5ID0gcHJpb3JpdHkgfHwgMDtcblx0XHRmb3IodmFyIGkgPSBkZWZlcnJlZC5sZW5ndGg7IGkgPiAwICYmIGRlZmVycmVkW2kgLSAxXVsyXSA+IHByaW9yaXR5OyBpLS0pIGRlZmVycmVkW2ldID0gZGVmZXJyZWRbaSAtIDFdO1xuXHRcdGRlZmVycmVkW2ldID0gW2NodW5rSWRzLCBmbiwgcHJpb3JpdHldO1xuXHRcdHJldHVybjtcblx0fVxuXHR2YXIgbm90RnVsZmlsbGVkID0gSW5maW5pdHk7XG5cdGZvciAodmFyIGkgPSAwOyBpIDwgZGVmZXJyZWQubGVuZ3RoOyBpKyspIHtcblx0XHR2YXIgW2NodW5rSWRzLCBmbiwgcHJpb3JpdHldID0gZGVmZXJyZWRbaV07XG5cdFx0dmFyIGZ1bGZpbGxlZCA9IHRydWU7XG5cdFx0Zm9yICh2YXIgaiA9IDA7IGogPCBjaHVua0lkcy5sZW5ndGg7IGorKykge1xuXHRcdFx0aWYgKChwcmlvcml0eSAmIDEgPT09IDAgfHwgbm90RnVsZmlsbGVkID49IHByaW9yaXR5KSAmJiBPYmplY3Qua2V5cyhfX3dlYnBhY2tfcmVxdWlyZV9fLk8pLmV2ZXJ5KChrZXkpID0+IChfX3dlYnBhY2tfcmVxdWlyZV9fLk9ba2V5XShjaHVua0lkc1tqXSkpKSkge1xuXHRcdFx0XHRjaHVua0lkcy5zcGxpY2Uoai0tLCAxKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGZ1bGZpbGxlZCA9IGZhbHNlO1xuXHRcdFx0XHRpZihwcmlvcml0eSA8IG5vdEZ1bGZpbGxlZCkgbm90RnVsZmlsbGVkID0gcHJpb3JpdHk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmKGZ1bGZpbGxlZCkge1xuXHRcdFx0ZGVmZXJyZWQuc3BsaWNlKGktLSwgMSlcblx0XHRcdHZhciByID0gZm4oKTtcblx0XHRcdGlmIChyICE9PSB1bmRlZmluZWQpIHJlc3VsdCA9IHI7XG5cdFx0fVxuXHR9XG5cdHJldHVybiByZXN1bHQ7XG59OyIsIi8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSAobW9kdWxlKSA9PiB7XG5cdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuXHRcdCgpID0+IChtb2R1bGVbJ2RlZmF1bHQnXSkgOlxuXHRcdCgpID0+IChtb2R1bGUpO1xuXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCB7IGE6IGdldHRlciB9KTtcblx0cmV0dXJuIGdldHRlcjtcbn07IiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5nID0gKGZ1bmN0aW9uKCkge1xuXHRpZiAodHlwZW9mIGdsb2JhbFRoaXMgPT09ICdvYmplY3QnKSByZXR1cm4gZ2xvYmFsVGhpcztcblx0dHJ5IHtcblx0XHRyZXR1cm4gdGhpcyB8fCBuZXcgRnVuY3Rpb24oJ3JldHVybiB0aGlzJykoKTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdGlmICh0eXBlb2Ygd2luZG93ID09PSAnb2JqZWN0JykgcmV0dXJuIHdpbmRvdztcblx0fVxufSkoKTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLy8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gKGV4cG9ydHMpID0+IHtcblx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5ubWQgPSAobW9kdWxlKSA9PiB7XG5cdG1vZHVsZS5wYXRocyA9IFtdO1xuXHRpZiAoIW1vZHVsZS5jaGlsZHJlbikgbW9kdWxlLmNoaWxkcmVuID0gW107XG5cdHJldHVybiBtb2R1bGU7XG59OyIsIi8vIG5vIGJhc2VVUklcblxuLy8gb2JqZWN0IHRvIHN0b3JlIGxvYWRlZCBhbmQgbG9hZGluZyBjaHVua3Ncbi8vIHVuZGVmaW5lZCA9IGNodW5rIG5vdCBsb2FkZWQsIG51bGwgPSBjaHVuayBwcmVsb2FkZWQvcHJlZmV0Y2hlZFxuLy8gW3Jlc29sdmUsIHJlamVjdCwgUHJvbWlzZV0gPSBjaHVuayBsb2FkaW5nLCAwID0gY2h1bmsgbG9hZGVkXG52YXIgaW5zdGFsbGVkQ2h1bmtzID0ge1xuXHRcInBvcHVwXCI6IDBcbn07XG5cbi8vIG5vIGNodW5rIG9uIGRlbWFuZCBsb2FkaW5nXG5cbi8vIG5vIHByZWZldGNoaW5nXG5cbi8vIG5vIHByZWxvYWRlZFxuXG4vLyBubyBITVJcblxuLy8gbm8gSE1SIG1hbmlmZXN0XG5cbl9fd2VicGFja19yZXF1aXJlX18uTy5qID0gKGNodW5rSWQpID0+IChpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0gPT09IDApO1xuXG4vLyBpbnN0YWxsIGEgSlNPTlAgY2FsbGJhY2sgZm9yIGNodW5rIGxvYWRpbmdcbnZhciB3ZWJwYWNrSnNvbnBDYWxsYmFjayA9IChwYXJlbnRDaHVua0xvYWRpbmdGdW5jdGlvbiwgZGF0YSkgPT4ge1xuXHR2YXIgW2NodW5rSWRzLCBtb3JlTW9kdWxlcywgcnVudGltZV0gPSBkYXRhO1xuXHQvLyBhZGQgXCJtb3JlTW9kdWxlc1wiIHRvIHRoZSBtb2R1bGVzIG9iamVjdCxcblx0Ly8gdGhlbiBmbGFnIGFsbCBcImNodW5rSWRzXCIgYXMgbG9hZGVkIGFuZCBmaXJlIGNhbGxiYWNrXG5cdHZhciBtb2R1bGVJZCwgY2h1bmtJZCwgaSA9IDA7XG5cdGlmKGNodW5rSWRzLnNvbWUoKGlkKSA9PiAoaW5zdGFsbGVkQ2h1bmtzW2lkXSAhPT0gMCkpKSB7XG5cdFx0Zm9yKG1vZHVsZUlkIGluIG1vcmVNb2R1bGVzKSB7XG5cdFx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8obW9yZU1vZHVsZXMsIG1vZHVsZUlkKSkge1xuXHRcdFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLm1bbW9kdWxlSWRdID0gbW9yZU1vZHVsZXNbbW9kdWxlSWRdO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZihydW50aW1lKSB2YXIgcmVzdWx0ID0gcnVudGltZShfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblx0fVxuXHRpZihwYXJlbnRDaHVua0xvYWRpbmdGdW5jdGlvbikgcGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24oZGF0YSk7XG5cdGZvcig7aSA8IGNodW5rSWRzLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y2h1bmtJZCA9IGNodW5rSWRzW2ldO1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhpbnN0YWxsZWRDaHVua3MsIGNodW5rSWQpICYmIGluc3RhbGxlZENodW5rc1tjaHVua0lkXSkge1xuXHRcdFx0aW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdWzBdKCk7XG5cdFx0fVxuXHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9IDA7XG5cdH1cblx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18uTyhyZXN1bHQpO1xufVxuXG52YXIgY2h1bmtMb2FkaW5nR2xvYmFsID0gc2VsZltcIndlYnBhY2tDaHVua2RlYWxfc25pZmZlclwiXSA9IHNlbGZbXCJ3ZWJwYWNrQ2h1bmtkZWFsX3NuaWZmZXJcIl0gfHwgW107XG5jaHVua0xvYWRpbmdHbG9iYWwuZm9yRWFjaCh3ZWJwYWNrSnNvbnBDYWxsYmFjay5iaW5kKG51bGwsIDApKTtcbmNodW5rTG9hZGluZ0dsb2JhbC5wdXNoID0gd2VicGFja0pzb25wQ2FsbGJhY2suYmluZChudWxsLCBjaHVua0xvYWRpbmdHbG9iYWwucHVzaC5iaW5kKGNodW5rTG9hZGluZ0dsb2JhbCkpOyIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgZGVwZW5kcyBvbiBvdGhlciBsb2FkZWQgY2h1bmtzIGFuZCBleGVjdXRpb24gbmVlZCB0byBiZSBkZWxheWVkXG52YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IF9fd2VicGFja19yZXF1aXJlX18uTyh1bmRlZmluZWQsIFtcInZlbmRvclwiXSwgKCkgPT4gKF9fd2VicGFja19yZXF1aXJlX18oXCIuL3NyYy9wb3B1cC50c3hcIikpKVxuX193ZWJwYWNrX2V4cG9ydHNfXyA9IF9fd2VicGFja19yZXF1aXJlX18uTyhfX3dlYnBhY2tfZXhwb3J0c19fKTtcbiIsIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==