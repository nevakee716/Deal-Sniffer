/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/customConfiguration.tsx":
/*!*************************************!*\
  !*** ./src/customConfiguration.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "emptyConfiguration": () => (/* binding */ emptyConfiguration),
/* harmony export */   "initialConfiguration": () => (/* binding */ initialConfiguration)
/* harmony export */ });
const initialConfiguration = {
    1: {
        fdp: 0,
        name: 'Amazon FR',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.fr',
        uuid: 1,
        warning: '',
        partnerUrl: '',
    },
    2: {
        fdp: 0,
        name: 'Amazon DE',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.de',
        uuid: 2,
        warning: '',
        partnerUrl: '',
    },
    3: {
        fdp: 0,
        name: 'Amazon ES',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.es',
        uuid: 3,
        warning: '',
        partnerUrl: '',
    },
    4: {
        fdp: 0,
        name: 'Amazon IT',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.it',
        uuid: 4,
        warning: '',
        partnerUrl: '',
    },
    5: {
        fdp: 20,
        imgPreUrl: '',
        imgSelector: '#mainImageDiv img',
        name: 'BPM-Power',
        nameSelector: '.titleText h1',
        priceReplacers: [],
        priceSelector: '#divProductInfoAndHelp .prezzoScheda',
        url: 'bpm-power.com',
        uuid: 5,
        warning: "Bien Vérifier sous 5j qu'il n'y a pas de dégat sur le colis",
        partnerUrl: '',
    },
    6: {
        fdp: 0,
        uuid: 6,
        name: 'CaseKing',
        url: 'caseking.de',
        nameSelector: '#ck_detail  #detailbox h1',
        priceSelector: '#ck_detail #buybox strong',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        imgPreUrl: 'https:',
        imgSelector: '#ck_detail  #detailbox #img img',
        warning: '',
        partnerUrl: '',
    },
    7: {
        fdp: 0,
        uuid: 7,
        name: 'Cdiscount',
        url: 'cdiscount.com',
        nameSelector: '.fpTMain .fpDesCol h1',
        priceSelector: '.fTopPrice  .fpPrice',
        priceReplacers: [
            {
                replaced: '€',
                replaceBy: '.',
            },
        ],
        imgPreUrl: '',
        imgSelector: '#fpZnPrdMain img#picture0',
        warning: '',
        partnerUrl: '',
    },
    8: {
        fdp: 0,
        uuid: 8,
        name: 'Cybertek',
        url: 'cybertek.fr',
        nameSelector: '.fiche-produit__bloc-achat__container .title_fiche',
        priceSelector: '.fiche-produit__bloc-achat__prix  .fiche_product_price > span',
        priceReplacers: [
            {
                replaced: '€',
                replaceBy: '.',
            },
        ],
        imgPreUrl: '',
        imgSelector: '#fiche-produit__container-photos [data-swiper-slide-index="0"] img',
        warning: '',
        partnerUrl: '',
    },
    9: {
        fdp: 0,
        uuid: 9,
        name: 'Grosbill',
        url: 'grosbill.com',
        nameSelector: '.grb_fch-prod__content-title .grb_fch-prod__title',
        priceSelector: '.fiche-produit-r  .fiche_product_price > span.p-3x',
        priceReplacers: [
            {
                replaced: '€',
                replaceBy: '.',
            },
        ],
        imgPreUrl: 'https://www.grosbill.com',
        imgSelector: '#product_buy [data-swiper-slide-index="0"] img',
        warning: '',
        partnerUrl: '',
    },
    10: {
        fdp: 0,
        uuid: 10,
        name: '1FoDiscount',
        url: '1fodiscount.com',
        nameSelector: '.product-sheet_title',
        priceSelector: '.product-sheet_buybox .product-sheet_buybox_offer_price',
        priceReplacers: [],
        imgPreUrl: '',
        imgSelector: '.product-sheet_slideshow_scrollable img.product-sheet_slideshow_slide_img',
        warning: '',
        partnerUrl: '',
    },
    11: {
        fdp: 0,
        uuid: 11,
        name: 'PcComponentes FR',
        url: 'pccomponentes.fr',
        nameSelector: '#pdp-title',
        priceSelector: '#pdp-price-current-integer',
        priceReplacers: [],
        imgPreUrl: 'https:',
        imgSelector: '#pdp-section-images img',
        warning: '',
        partnerUrl: '',
    },
    12: {
        fdp: 0,
        uuid: 12,
        name: 'PcComponentes ',
        url: 'pccomponentes.com',
        nameSelector: '#pdp-title',
        priceSelector: '#pdp-price-current-integer',
        priceReplacers: [],
        imgPreUrl: 'https:',
        imgSelector: '#pdp-section-images img',
        warning: '',
        partnerUrl: '',
    },
    13: {
        fdp: 0,
        imgPreUrl: '',
        imgSelector: '.elementor-carousel-image',
        name: 'Psk Mega Store',
        nameSelector: '.ce-product-name',
        partnerUrl: '',
        priceReplacers: [],
        priceSelector: '.ce-product-prices span',
        url: 'pskmegastore.com',
        uuid: 13,
        warning: 'En test',
    },
    14: {
        fdp: 0,
        uuid: 14,
        name: 'Rue du Commerce',
        url: 'rueducommerce.fr',
        nameSelector: '.product-name > span',
        priceSelector: '.product__price .dyn_prod_price',
        priceReplacers: [],
        imgPreUrl: '',
        imgSelector: '#gallery .owl-item img',
        warning: '',
        partnerUrl: '',
    },
    15: {
        fdp: 7,
        uuid: 15,
        name: 'Reichelt',
        url: 'www.reichelt.com',
        nameSelector: '.av_articleheader [itemprop="name"]',
        priceSelector: '#av_price',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        imgPreUrl: '',
        imgSelector: '#gallery img',
        warning: '',
        partnerUrl: '',
    },
    16: {
        fdp: 5,
        uuid: 16,
        name: 'TopAchat',
        url: 'topachat.com',
        nameSelector: '.ps-main__product-title',
        priceSelector: '.ps-main__offer  .offer-price__price',
        priceReplacers: [],
        imgPreUrl: 'https:',
        imgSelector: '.product-main-image.ps-main__main-image img',
        warning: '',
        partnerUrl: '',
    },
};
const emptyConfiguration = {
    name: 'New Configuration',
    fdp: 0,
    uuid: 0,
    url: 'new url',
    warning: 'En test',
    priceSelector: '.ce-product-prices span',
    priceReplacers: [],
    imgSelector: '.elementor-carousel-image',
    imgPreUrl: '',
    nameSelector: '.ce-product-name',
    partnerUrl: '',
};




/***/ }),

/***/ "./src/get-infos.tsx":
/*!***************************!*\
  !*** ./src/get-infos.tsx ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const getInfos = (configuration, url) => {
    let a = {};
    a.name =
        document.querySelector(configuration.nameSelector)
            ?.innerText ?? 'Not Found';
    a.priceText = document.querySelector(configuration.priceSelector).innerText;
    configuration.priceReplacers.forEach((r) => {
        a.priceText = a.priceText?.replaceAll(r.replaced, r.replaceBy);
    });
    a.vendor = configuration.name;
    a.imgUrl =
        (configuration.imgPreUrl ?? '') +
            document.querySelector(configuration.imgSelector)?.getAttribute('src') ??
            'Not Found';
    a.priceText = a.priceText?.replaceAll(',', '.').replace(/[^0-9\.]/g, '');
    a.price = Number(a.priceText);
    a.name = a.name?.replace('\n', ' ') ?? 'Not found';
    a.url = url?.replace(/\?.+/, configuration.partnerUrl) + '?';
    a.fdp = configuration.fdp;
    a.warning = configuration.warning;
    // Si selection de text, nom = selection texte
    let selection = window?.getSelection()?.toString();
    a.name = selection != '' ? selection : a?.name?.replace('"', '');
    return a;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getInfos);


/***/ }),

/***/ "./src/popup.tsx":
/*!***********************!*\
  !*** ./src/popup.tsx ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom/client */ "./node_modules/react-dom/client.js");
/* harmony import */ var _preact_signals_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @preact/signals-react */ "./node_modules/@preact/signals-react/dist/signals.module.js");
/* harmony import */ var _get_infos__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./get-infos */ "./src/get-infos.tsx");
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/material/Button */ "./node_modules/@mui/material/Button/Button.js");
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material/TextField */ "./node_modules/@mui/material/TextField/TextField.js");
/* harmony import */ var _customConfiguration__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./customConfiguration */ "./src/customConfiguration.tsx");
/* harmony import */ var _iconify_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @iconify/react */ "./node_modules/@iconify/react/dist/iconify.mjs");








const article = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)({});
const customConfigurations = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)(_customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration);
function generateExcelClipboardString() {
    let price = Math.round((article.value.price ?? 0) + (article.value.fdp ?? 0));
    let s = `=IMAGE("${article.value.imgUrl}")\t`;
    s += `=HYPERLINK("${article.value.url}";"${article.value.name}")\t`;
    s += `${article.value.vendor}\t`;
    s += `${price} €\t`;
    navigator.clipboard.writeText(s);
}
function generateDiscordClipboardString() {
    let price = Math.round((article.value.price ?? 0) + (article.value.fdp ?? 0));
    let s = `**${article.value.name}** à **${price}€** vendu par **${article.value.vendor}** :`;
    if (article.value.warning)
        s += `\n:warning:${article.value.warning}:warning:`;
    s += `\n${article.value.url}`;
    navigator.clipboard.writeText(s);
}
function generateTwitchClipboardString() {
    let price = Math.round((article.value.price ?? 0) + (article.value.fdp ?? 0));
    let s = `${article.value.name} à ${price}€ vendu par ${article.value.vendor} : ${article.value.url}`;
    navigator.clipboard.writeText(s);
}
const analyzeUrl = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const tab = tabs[0];
        let c;
        Object.values(customConfigurations.value).some((configuration) => {
            if (tab.url.includes(configuration.url ?? '')) {
                console.log(`Configuration found : ${configuration.name} (${configuration.uuid})`);
                chrome.scripting
                    .executeScript({
                    target: { tabId: tab.id },
                    func: _get_infos__WEBPACK_IMPORTED_MODULE_3__["default"],
                    args: [configuration, tab.url],
                })
                    .then((injectionResults) => {
                    for (const { frameId, result } of injectionResults) {
                        article.value = result;
                    }
                });
            }
        });
    });
};
chrome.runtime.onMessage.addListener(function (request) {
    console.log('popu' + request);
});
const handleChange = (event) => {
    if (event.target.id === 'name')
        article.value = { ...article.value, name: event.target.value };
    if (event.target.id === 'url')
        article.value = { ...article.value, url: event.target.value };
    if (event.target.id === 'vendor')
        article.value = { ...article.value, vendor: event.target.value };
    if (event.target.id === 'price')
        article.value = { ...article.value, price: Number(event.target.value) };
    if (event.target.id === 'fdp')
        article.value = { ...article.value, fdp: Number(event.target.value) };
    if (event.target.id === 'imgUrl')
        article.value = { ...article.value, imgUrl: event.target.value };
    if (event.target.id === 'warning')
        article.value = { ...article.value, warning: event.target.value };
};
const Popup = () => {
    // chrome.action.setBadgeText({ text: count.toString() });
    (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.useSignalEffect)(() => {
        chrome.storage.sync.get({
            configurations: _customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration,
        }, (items) => {
            const c = items.configurations;
            Object.keys(_customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration).forEach((key) => {
                if (Object.keys(c).indexOf(key) === -1) {
                    c[key] = _customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration[Number(key)];
                }
            });
            customConfigurations.value = c;
            analyzeUrl();
        });
    });
    const cardContent = {
        display: 'flex',
        'flex-direction': 'column',
        alignItems: 'strech',
        rowGap: '10px',
        minWidth: '800px',
        width: '100%',
    };
    const cardAction = {
        display: 'flex',
        width: '100%',
        columnGap: '5px',
    };
    const inputStyle = {
        width: '100%',
        flex: 1,
    };
    const priceContainerStyle = {
        display: 'flex',
        columnGap: '5px',
    };
    const priceInputStyle = {
        width: '80%',
    };
    const sellerInputStyle = {
        width: '60%',
    };
    const fdpInputStyle = {
        width: '20%',
    };
    const iconStyle = {
        marginRight: '2px',
    };
    const buttonStyle = {
        flex: 1,
    };
    const dividerStyle = {
        marginTop: '20px',
        marginBottom: '20px',
    };
    const priceReplacerStyle = {
        display: 'flex',
    };
    const priceReplacerInputWrapperStyle = {
        display: 'flex',
        'flex-direction': 'column',
        alignItems: 'strech',
        rowGap: '10px',
    };
    const priceReplacerInputStyle = {
        width: '50%',
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardContent },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardContent },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.vendor, id: "vendor", label: "Seller", defaultValue: "Error" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.url, id: "url", multiline: true, label: "URL", defaultValue: "Error" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.name, id: "name", label: "Article", defaultValue: "Error" }),
                !article.value?.price && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, value: article.value?.priceText, id: "name", label: "Price Text", defaultValue: "Error", helperText: "Issue to get a number from the price" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: priceContainerStyle },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: priceInputStyle, onChange: handleChange, value: article.value?.price, id: "price", type: "number", label: "Price", defaultValue: "0" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.fdp, id: "fdp", type: "number", label: "Frais De Port", defaultValue: "0" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.warning, id: "warning", label: "Warning", multiline: true, maxRows: 4, defaultValue: " " }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.imgUrl, id: "imgUrl", label: "Image Url", defaultValue: "Error" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardAction },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_7__["default"], { style: buttonStyle, variant: "contained", onClick: analyzeUrl },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_5__.Icon, { style: iconStyle, icon: "charm:refresh", height: "30" }),
                    "Refresh"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_7__["default"], { variant: "contained", onClick: generateExcelClipboardString },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_5__.Icon, { icon: "simple-icons:googlesheets", height: "36" }),
                    "Share on Excel"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_7__["default"], { variant: "contained", onClick: generateDiscordClipboardString },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_5__.Icon, { style: iconStyle, icon: "ic:baseline-discord", height: "30" }),
                    "Share on Discord"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_7__["default"], { variant: "contained", onClick: generateTwitchClipboardString },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_5__.Icon, { style: iconStyle, icon: "fa6-brands:twitch", height: "30" }),
                    "Share On Twitch")))));
};
const root = (0,react_dom_client__WEBPACK_IMPORTED_MODULE_1__.createRoot)(document.getElementById('root'));
root.render(react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().StrictMode), null,
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Popup, null)));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"popup": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkdeal_sniffer"] = self["webpackChunkdeal_sniffer"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__("./src/popup.tsx")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUM4QjtBQUNFOzs7Ozs7Ozs7Ozs7Ozs7QUM3UWhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpRUFBZSxRQUFRLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCRTtBQUNvQjtBQUNrQjtBQUM3QjtBQUNPO0FBQ007QUFDYztBQUN4QjtBQUN0QyxnQkFBZ0IsNkRBQU0sR0FBRztBQUN6Qiw2QkFBNkIsNkRBQU0sQ0FBQyxzRUFBb0I7QUFDeEQ7QUFDQTtBQUNBLHVCQUF1QixxQkFBcUI7QUFDNUMsd0JBQXdCLGtCQUFrQixFQUFFLEdBQUcsbUJBQW1CO0FBQ2xFLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksT0FBTztBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixtQkFBbUIsU0FBUyxNQUFNLGtCQUFrQixxQkFBcUI7QUFDMUY7QUFDQSwyQkFBMkIsc0JBQXNCO0FBQ2pELGNBQWMsa0JBQWtCO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSxvQkFBb0IsSUFBSSxNQUFNLGNBQWMsc0JBQXNCLElBQUksa0JBQWtCO0FBQ3ZHO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixtQ0FBbUM7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxREFBcUQsb0JBQW9CLEdBQUcsbUJBQW1CO0FBQy9GO0FBQ0E7QUFDQSw4QkFBOEIsZUFBZTtBQUM3QywwQkFBMEIsa0RBQVE7QUFDbEM7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxpQ0FBaUMsa0JBQWtCO0FBQ25EO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQSxvQ0FBb0Msd0JBQXdCO0FBQzVELElBQUksc0VBQWU7QUFDbkI7QUFDQSw0QkFBNEIsc0VBQW9CO0FBQ2hELFNBQVM7QUFDVDtBQUNBLHdCQUF3QixzRUFBb0I7QUFDNUM7QUFDQSw2QkFBNkIsc0VBQW9CO0FBQ2pEO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSwwREFBbUIsQ0FBQyx1REFBYztBQUM5QyxRQUFRLDBEQUFtQixVQUFVLG9CQUFvQjtBQUN6RCxZQUFZLDBEQUFtQixVQUFVLG9CQUFvQjtBQUM3RCxnQkFBZ0IsMERBQW1CLENBQUMsK0RBQVMsSUFBSSwrSEFBK0g7QUFDaEwsZ0JBQWdCLDBEQUFtQixDQUFDLCtEQUFTLElBQUksdUlBQXVJO0FBQ3hMLGdCQUFnQiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLDRIQUE0SDtBQUM3SywwQ0FBMEMsMERBQW1CLENBQUMsK0RBQVMsSUFBSSxnS0FBZ0s7QUFDM08sZ0JBQWdCLDBEQUFtQixVQUFVLDRCQUE0QjtBQUN6RSxvQkFBb0IsMERBQW1CLENBQUMsK0RBQVMsSUFBSSw2SUFBNkk7QUFDbE0sb0JBQW9CLDBEQUFtQixDQUFDLCtEQUFTLElBQUksNElBQTRJO0FBQ2pNLGdCQUFnQiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLDJKQUEySjtBQUM1TSxnQkFBZ0IsMERBQW1CLENBQUMsK0RBQVMsSUFBSSxrSUFBa0k7QUFDbkwsWUFBWSwwREFBbUIsVUFBVSxtQkFBbUI7QUFDNUQsZ0JBQWdCLDBEQUFtQixDQUFDLDREQUFNLElBQUksK0RBQStEO0FBQzdHLG9CQUFvQiwwREFBbUIsQ0FBQyxnREFBSSxJQUFJLHVEQUF1RDtBQUN2RztBQUNBLGdCQUFnQiwwREFBbUIsQ0FBQyw0REFBTSxJQUFJLDZEQUE2RDtBQUMzRyxvQkFBb0IsMERBQW1CLENBQUMsZ0RBQUksSUFBSSxpREFBaUQ7QUFDakc7QUFDQSxnQkFBZ0IsMERBQW1CLENBQUMsNERBQU0sSUFBSSwrREFBK0Q7QUFDN0csb0JBQW9CLDBEQUFtQixDQUFDLGdEQUFJLElBQUksNkRBQTZEO0FBQzdHO0FBQ0EsZ0JBQWdCLDBEQUFtQixDQUFDLDREQUFNLElBQUksOERBQThEO0FBQzVHLG9CQUFvQiwwREFBbUIsQ0FBQyxnREFBSSxJQUFJLDJEQUEyRDtBQUMzRztBQUNBO0FBQ0EsYUFBYSw0REFBVTtBQUN2QixZQUFZLDBEQUFtQixDQUFDLHlEQUFnQjtBQUNoRCxJQUFJLDBEQUFtQjs7Ozs7OztVQ3hLdkI7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOztVQUVBO1VBQ0E7Ozs7O1dDNUJBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsK0JBQStCLHdDQUF3QztXQUN2RTtXQUNBO1dBQ0E7V0FDQTtXQUNBLGlCQUFpQixxQkFBcUI7V0FDdEM7V0FDQTtXQUNBLGtCQUFrQixxQkFBcUI7V0FDdkM7V0FDQTtXQUNBLEtBQUs7V0FDTDtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7Ozs7O1dDM0JBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQ0FBaUMsV0FBVztXQUM1QztXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EseUNBQXlDLHdDQUF3QztXQUNqRjtXQUNBO1dBQ0E7Ozs7O1dDUEE7V0FDQTtXQUNBO1dBQ0E7V0FDQSxHQUFHO1dBQ0g7V0FDQTtXQUNBLENBQUM7Ozs7O1dDUEQ7Ozs7O1dDQUE7V0FDQTtXQUNBO1dBQ0EsdURBQXVELGlCQUFpQjtXQUN4RTtXQUNBLGdEQUFnRCxhQUFhO1dBQzdEOzs7OztXQ05BO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7Ozs7O1dDSkE7O1dBRUE7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLE1BQU0scUJBQXFCO1dBQzNCO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7O1dBRUE7V0FDQTtXQUNBOzs7OztVRWhEQTtVQUNBO1VBQ0E7VUFDQTtVQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZGVhbC1zbmlmZmVyLy4vc3JjL2N1c3RvbUNvbmZpZ3VyYXRpb24udHN4Iiwid2VicGFjazovL2RlYWwtc25pZmZlci8uL3NyYy9nZXQtaW5mb3MudHN4Iiwid2VicGFjazovL2RlYWwtc25pZmZlci8uL3NyYy9wb3B1cC50c3giLCJ3ZWJwYWNrOi8vZGVhbC1zbmlmZmVyL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY2h1bmsgbG9hZGVkIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvZ2xvYmFsIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbm9kZSBtb2R1bGUgZGVjb3JhdG9yIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvanNvbnAgY2h1bmsgbG9hZGluZyIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgaW5pdGlhbENvbmZpZ3VyYXRpb24gPSB7XG4gICAgMToge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIG5hbWU6ICdBbWF6b24gRlInLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcjcHJvZHVjdFRpdGxlJyxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjaW1nVGFnV3JhcHBlcklkIGltZycsXG4gICAgICAgIHByaWNlU2VsZWN0b3I6ICcjY29yZVByaWNlX2ZlYXR1cmVfZGl2IC5hLXByaWNlLXdob2xlJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZXBsYWNlZDogJy4nLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJycsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICB1cmw6ICdhbWF6b24uZnInLFxuICAgICAgICB1dWlkOiAxLFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICAyOiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgbmFtZTogJ0FtYXpvbiBERScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJyNwcm9kdWN0VGl0bGUnLFxuICAgICAgICBpbWdQcmVVcmw6ICcnLFxuICAgICAgICBpbWdTZWxlY3RvcjogJyNpbWdUYWdXcmFwcGVySWQgaW1nJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNjb3JlUHJpY2VfZmVhdHVyZV9kaXYgLmEtcHJpY2Utd2hvbGUnLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJlcGxhY2VkOiAnLicsXG4gICAgICAgICAgICAgICAgcmVwbGFjZUJ5OiAnJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHVybDogJ2FtYXpvbi5kZScsXG4gICAgICAgIHV1aWQ6IDIsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDM6IHtcbiAgICAgICAgZmRwOiAwLFxuICAgICAgICBuYW1lOiAnQW1hem9uIEVTJyxcbiAgICAgICAgbmFtZVNlbGVjdG9yOiAnI3Byb2R1Y3RUaXRsZScsXG4gICAgICAgIGltZ1ByZVVybDogJycsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI2ltZ1RhZ1dyYXBwZXJJZCBpbWcnLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnI2NvcmVQcmljZV9mZWF0dXJlX2RpdiAuYS1wcmljZS13aG9sZScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZWQ6ICcuJyxcbiAgICAgICAgICAgICAgICByZXBsYWNlQnk6ICcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgdXJsOiAnYW1hem9uLmVzJyxcbiAgICAgICAgdXVpZDogMyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG4gICAgNDoge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIG5hbWU6ICdBbWF6b24gSVQnLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcjcHJvZHVjdFRpdGxlJyxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjaW1nVGFnV3JhcHBlcklkIGltZycsXG4gICAgICAgIHByaWNlU2VsZWN0b3I6ICcjY29yZVByaWNlX2ZlYXR1cmVfZGl2IC5hLXByaWNlLXdob2xlJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZXBsYWNlZDogJy4nLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJycsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICB1cmw6ICdhbWF6b24uaXQnLFxuICAgICAgICB1dWlkOiA0LFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICA1OiB7XG4gICAgICAgIGZkcDogMjAsXG4gICAgICAgIGltZ1ByZVVybDogJycsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI21haW5JbWFnZURpdiBpbWcnLFxuICAgICAgICBuYW1lOiAnQlBNLVBvd2VyJyxcbiAgICAgICAgbmFtZVNlbGVjdG9yOiAnLnRpdGxlVGV4dCBoMScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXSxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNkaXZQcm9kdWN0SW5mb0FuZEhlbHAgLnByZXp6b1NjaGVkYScsXG4gICAgICAgIHVybDogJ2JwbS1wb3dlci5jb20nLFxuICAgICAgICB1dWlkOiA1LFxuICAgICAgICB3YXJuaW5nOiBcIkJpZW4gVsOpcmlmaWVyIHNvdXMgNWogcXUnaWwgbid5IGEgcGFzIGRlIGTDqWdhdCBzdXIgbGUgY29saXNcIixcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICA2OiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgdXVpZDogNixcbiAgICAgICAgbmFtZTogJ0Nhc2VLaW5nJyxcbiAgICAgICAgdXJsOiAnY2FzZWtpbmcuZGUnLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcjY2tfZGV0YWlsICAjZGV0YWlsYm94IGgxJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNja19kZXRhaWwgI2J1eWJveCBzdHJvbmcnLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJlcGxhY2VkOiAnLicsXG4gICAgICAgICAgICAgICAgcmVwbGFjZUJ5OiAnJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIGltZ1ByZVVybDogJ2h0dHBzOicsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI2NrX2RldGFpbCAgI2RldGFpbGJveCAjaW1nIGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDc6IHtcbiAgICAgICAgZmRwOiAwLFxuICAgICAgICB1dWlkOiA3LFxuICAgICAgICBuYW1lOiAnQ2Rpc2NvdW50JyxcbiAgICAgICAgdXJsOiAnY2Rpc2NvdW50LmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5mcFRNYWluIC5mcERlc0NvbCBoMScsXG4gICAgICAgIHByaWNlU2VsZWN0b3I6ICcuZlRvcFByaWNlICAuZnBQcmljZScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZWQ6ICfigqwnLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJy4nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjZnBablByZE1haW4gaW1nI3BpY3R1cmUwJyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG4gICAgODoge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIHV1aWQ6IDgsXG4gICAgICAgIG5hbWU6ICdDeWJlcnRlaycsXG4gICAgICAgIHVybDogJ2N5YmVydGVrLmZyJyxcbiAgICAgICAgbmFtZVNlbGVjdG9yOiAnLmZpY2hlLXByb2R1aXRfX2Jsb2MtYWNoYXRfX2NvbnRhaW5lciAudGl0bGVfZmljaGUnLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnLmZpY2hlLXByb2R1aXRfX2Jsb2MtYWNoYXRfX3ByaXggIC5maWNoZV9wcm9kdWN0X3ByaWNlID4gc3BhbicsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZWQ6ICfigqwnLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJy4nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjZmljaGUtcHJvZHVpdF9fY29udGFpbmVyLXBob3RvcyBbZGF0YS1zd2lwZXItc2xpZGUtaW5kZXg9XCIwXCJdIGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDk6IHtcbiAgICAgICAgZmRwOiAwLFxuICAgICAgICB1dWlkOiA5LFxuICAgICAgICBuYW1lOiAnR3Jvc2JpbGwnLFxuICAgICAgICB1cmw6ICdncm9zYmlsbC5jb20nLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcuZ3JiX2ZjaC1wcm9kX19jb250ZW50LXRpdGxlIC5ncmJfZmNoLXByb2RfX3RpdGxlJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJy5maWNoZS1wcm9kdWl0LXIgIC5maWNoZV9wcm9kdWN0X3ByaWNlID4gc3Bhbi5wLTN4JyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZXBsYWNlZDogJ+KCrCcsXG4gICAgICAgICAgICAgICAgcmVwbGFjZUJ5OiAnLicsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBpbWdQcmVVcmw6ICdodHRwczovL3d3dy5ncm9zYmlsbC5jb20nLFxuICAgICAgICBpbWdTZWxlY3RvcjogJyNwcm9kdWN0X2J1eSBbZGF0YS1zd2lwZXItc2xpZGUtaW5kZXg9XCIwXCJdIGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDEwOiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgdXVpZDogMTAsXG4gICAgICAgIG5hbWU6ICcxRm9EaXNjb3VudCcsXG4gICAgICAgIHVybDogJzFmb2Rpc2NvdW50LmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5wcm9kdWN0LXNoZWV0X3RpdGxlJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJy5wcm9kdWN0LXNoZWV0X2J1eWJveCAucHJvZHVjdC1zaGVldF9idXlib3hfb2ZmZXJfcHJpY2UnLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW10sXG4gICAgICAgIGltZ1ByZVVybDogJycsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnLnByb2R1Y3Qtc2hlZXRfc2xpZGVzaG93X3Njcm9sbGFibGUgaW1nLnByb2R1Y3Qtc2hlZXRfc2xpZGVzaG93X3NsaWRlX2ltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDExOiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgdXVpZDogMTEsXG4gICAgICAgIG5hbWU6ICdQY0NvbXBvbmVudGVzIEZSJyxcbiAgICAgICAgdXJsOiAncGNjb21wb25lbnRlcy5mcicsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJyNwZHAtdGl0bGUnLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnI3BkcC1wcmljZS1jdXJyZW50LWludGVnZXInLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW10sXG4gICAgICAgIGltZ1ByZVVybDogJ2h0dHBzOicsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI3BkcC1zZWN0aW9uLWltYWdlcyBpbWcnLFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICAxMjoge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIHV1aWQ6IDEyLFxuICAgICAgICBuYW1lOiAnUGNDb21wb25lbnRlcyAnLFxuICAgICAgICB1cmw6ICdwY2NvbXBvbmVudGVzLmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJyNwZHAtdGl0bGUnLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnI3BkcC1wcmljZS1jdXJyZW50LWludGVnZXInLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW10sXG4gICAgICAgIGltZ1ByZVVybDogJ2h0dHBzOicsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI3BkcC1zZWN0aW9uLWltYWdlcyBpbWcnLFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICAxMzoge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIGltZ1ByZVVybDogJycsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnLmVsZW1lbnRvci1jYXJvdXNlbC1pbWFnZScsXG4gICAgICAgIG5hbWU6ICdQc2sgTWVnYSBTdG9yZScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5jZS1wcm9kdWN0LW5hbWUnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtdLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnLmNlLXByb2R1Y3QtcHJpY2VzIHNwYW4nLFxuICAgICAgICB1cmw6ICdwc2ttZWdhc3RvcmUuY29tJyxcbiAgICAgICAgdXVpZDogMTMsXG4gICAgICAgIHdhcm5pbmc6ICdFbiB0ZXN0JyxcbiAgICB9LFxuICAgIDE0OiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgdXVpZDogMTQsXG4gICAgICAgIG5hbWU6ICdSdWUgZHUgQ29tbWVyY2UnLFxuICAgICAgICB1cmw6ICdydWVkdWNvbW1lcmNlLmZyJyxcbiAgICAgICAgbmFtZVNlbGVjdG9yOiAnLnByb2R1Y3QtbmFtZSA+IHNwYW4nLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnLnByb2R1Y3RfX3ByaWNlIC5keW5fcHJvZF9wcmljZScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXSxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjZ2FsbGVyeSAub3dsLWl0ZW0gaW1nJyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG4gICAgMTU6IHtcbiAgICAgICAgZmRwOiA3LFxuICAgICAgICB1dWlkOiAxNSxcbiAgICAgICAgbmFtZTogJ1JlaWNoZWx0JyxcbiAgICAgICAgdXJsOiAnd3d3LnJlaWNoZWx0LmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5hdl9hcnRpY2xlaGVhZGVyIFtpdGVtcHJvcD1cIm5hbWVcIl0nLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnI2F2X3ByaWNlJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZXBsYWNlZDogJy4nLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJycsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBpbWdQcmVVcmw6ICcnLFxuICAgICAgICBpbWdTZWxlY3RvcjogJyNnYWxsZXJ5IGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDE2OiB7XG4gICAgICAgIGZkcDogNSxcbiAgICAgICAgdXVpZDogMTYsXG4gICAgICAgIG5hbWU6ICdUb3BBY2hhdCcsXG4gICAgICAgIHVybDogJ3RvcGFjaGF0LmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5wcy1tYWluX19wcm9kdWN0LXRpdGxlJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJy5wcy1tYWluX19vZmZlciAgLm9mZmVyLXByaWNlX19wcmljZScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXSxcbiAgICAgICAgaW1nUHJlVXJsOiAnaHR0cHM6JyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcucHJvZHVjdC1tYWluLWltYWdlLnBzLW1haW5fX21haW4taW1hZ2UgaW1nJyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG59O1xuY29uc3QgZW1wdHlDb25maWd1cmF0aW9uID0ge1xuICAgIG5hbWU6ICdOZXcgQ29uZmlndXJhdGlvbicsXG4gICAgZmRwOiAwLFxuICAgIHV1aWQ6IDAsXG4gICAgdXJsOiAnbmV3IHVybCcsXG4gICAgd2FybmluZzogJ0VuIHRlc3QnLFxuICAgIHByaWNlU2VsZWN0b3I6ICcuY2UtcHJvZHVjdC1wcmljZXMgc3BhbicsXG4gICAgcHJpY2VSZXBsYWNlcnM6IFtdLFxuICAgIGltZ1NlbGVjdG9yOiAnLmVsZW1lbnRvci1jYXJvdXNlbC1pbWFnZScsXG4gICAgaW1nUHJlVXJsOiAnJyxcbiAgICBuYW1lU2VsZWN0b3I6ICcuY2UtcHJvZHVjdC1uYW1lJyxcbiAgICBwYXJ0bmVyVXJsOiAnJyxcbn07XG5leHBvcnQgeyBlbXB0eUNvbmZpZ3VyYXRpb24gfTtcbmV4cG9ydCB7IGluaXRpYWxDb25maWd1cmF0aW9uIH07XG4iLCJjb25zdCBnZXRJbmZvcyA9IChjb25maWd1cmF0aW9uLCB1cmwpID0+IHtcbiAgICBsZXQgYSA9IHt9O1xuICAgIGEubmFtZSA9XG4gICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoY29uZmlndXJhdGlvbi5uYW1lU2VsZWN0b3IpXG4gICAgICAgICAgICA/LmlubmVyVGV4dCA/PyAnTm90IEZvdW5kJztcbiAgICBhLnByaWNlVGV4dCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoY29uZmlndXJhdGlvbi5wcmljZVNlbGVjdG9yKS5pbm5lclRleHQ7XG4gICAgY29uZmlndXJhdGlvbi5wcmljZVJlcGxhY2Vycy5mb3JFYWNoKChyKSA9PiB7XG4gICAgICAgIGEucHJpY2VUZXh0ID0gYS5wcmljZVRleHQ/LnJlcGxhY2VBbGwoci5yZXBsYWNlZCwgci5yZXBsYWNlQnkpO1xuICAgIH0pO1xuICAgIGEudmVuZG9yID0gY29uZmlndXJhdGlvbi5uYW1lO1xuICAgIGEuaW1nVXJsID1cbiAgICAgICAgKGNvbmZpZ3VyYXRpb24uaW1nUHJlVXJsID8/ICcnKSArXG4gICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGNvbmZpZ3VyYXRpb24uaW1nU2VsZWN0b3IpPy5nZXRBdHRyaWJ1dGUoJ3NyYycpID8/XG4gICAgICAgICAgICAnTm90IEZvdW5kJztcbiAgICBhLnByaWNlVGV4dCA9IGEucHJpY2VUZXh0Py5yZXBsYWNlQWxsKCcsJywgJy4nKS5yZXBsYWNlKC9bXjAtOVxcLl0vZywgJycpO1xuICAgIGEucHJpY2UgPSBOdW1iZXIoYS5wcmljZVRleHQpO1xuICAgIGEubmFtZSA9IGEubmFtZT8ucmVwbGFjZSgnXFxuJywgJyAnKSA/PyAnTm90IGZvdW5kJztcbiAgICBhLnVybCA9IHVybD8ucmVwbGFjZSgvXFw/LisvLCBjb25maWd1cmF0aW9uLnBhcnRuZXJVcmwpICsgJz8nO1xuICAgIGEuZmRwID0gY29uZmlndXJhdGlvbi5mZHA7XG4gICAgYS53YXJuaW5nID0gY29uZmlndXJhdGlvbi53YXJuaW5nO1xuICAgIC8vIFNpIHNlbGVjdGlvbiBkZSB0ZXh0LCBub20gPSBzZWxlY3Rpb24gdGV4dGVcbiAgICBsZXQgc2VsZWN0aW9uID0gd2luZG93Py5nZXRTZWxlY3Rpb24oKT8udG9TdHJpbmcoKTtcbiAgICBhLm5hbWUgPSBzZWxlY3Rpb24gIT0gJycgPyBzZWxlY3Rpb24gOiBhPy5uYW1lPy5yZXBsYWNlKCdcIicsICcnKTtcbiAgICByZXR1cm4gYTtcbn07XG5leHBvcnQgZGVmYXVsdCBnZXRJbmZvcztcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgeyBzaWduYWwsIHVzZVNpZ25hbEVmZmVjdCB9IGZyb20gJ0BwcmVhY3Qvc2lnbmFscy1yZWFjdCc7XG5pbXBvcnQgZ2V0SW5mb3MgZnJvbSAnLi9nZXQtaW5mb3MnO1xuaW1wb3J0IEJ1dHRvbiBmcm9tICdAbXVpL21hdGVyaWFsL0J1dHRvbic7XG5pbXBvcnQgVGV4dEZpZWxkIGZyb20gJ0BtdWkvbWF0ZXJpYWwvVGV4dEZpZWxkJztcbmltcG9ydCB7IGluaXRpYWxDb25maWd1cmF0aW9uLCB9IGZyb20gJy4vY3VzdG9tQ29uZmlndXJhdGlvbic7XG5pbXBvcnQgeyBJY29uIH0gZnJvbSAnQGljb25pZnkvcmVhY3QnO1xuY29uc3QgYXJ0aWNsZSA9IHNpZ25hbCh7fSk7XG5jb25zdCBjdXN0b21Db25maWd1cmF0aW9ucyA9IHNpZ25hbChpbml0aWFsQ29uZmlndXJhdGlvbik7XG5mdW5jdGlvbiBnZW5lcmF0ZUV4Y2VsQ2xpcGJvYXJkU3RyaW5nKCkge1xuICAgIGxldCBwcmljZSA9IE1hdGgucm91bmQoKGFydGljbGUudmFsdWUucHJpY2UgPz8gMCkgKyAoYXJ0aWNsZS52YWx1ZS5mZHAgPz8gMCkpO1xuICAgIGxldCBzID0gYD1JTUFHRShcIiR7YXJ0aWNsZS52YWx1ZS5pbWdVcmx9XCIpXFx0YDtcbiAgICBzICs9IGA9SFlQRVJMSU5LKFwiJHthcnRpY2xlLnZhbHVlLnVybH1cIjtcIiR7YXJ0aWNsZS52YWx1ZS5uYW1lfVwiKVxcdGA7XG4gICAgcyArPSBgJHthcnRpY2xlLnZhbHVlLnZlbmRvcn1cXHRgO1xuICAgIHMgKz0gYCR7cHJpY2V9IOKCrFxcdGA7XG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQocyk7XG59XG5mdW5jdGlvbiBnZW5lcmF0ZURpc2NvcmRDbGlwYm9hcmRTdHJpbmcoKSB7XG4gICAgbGV0IHByaWNlID0gTWF0aC5yb3VuZCgoYXJ0aWNsZS52YWx1ZS5wcmljZSA/PyAwKSArIChhcnRpY2xlLnZhbHVlLmZkcCA/PyAwKSk7XG4gICAgbGV0IHMgPSBgKioke2FydGljbGUudmFsdWUubmFtZX0qKiDDoCAqKiR7cHJpY2V94oKsKiogdmVuZHUgcGFyICoqJHthcnRpY2xlLnZhbHVlLnZlbmRvcn0qKiA6YDtcbiAgICBpZiAoYXJ0aWNsZS52YWx1ZS53YXJuaW5nKVxuICAgICAgICBzICs9IGBcXG46d2FybmluZzoke2FydGljbGUudmFsdWUud2FybmluZ306d2FybmluZzpgO1xuICAgIHMgKz0gYFxcbiR7YXJ0aWNsZS52YWx1ZS51cmx9YDtcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChzKTtcbn1cbmZ1bmN0aW9uIGdlbmVyYXRlVHdpdGNoQ2xpcGJvYXJkU3RyaW5nKCkge1xuICAgIGxldCBwcmljZSA9IE1hdGgucm91bmQoKGFydGljbGUudmFsdWUucHJpY2UgPz8gMCkgKyAoYXJ0aWNsZS52YWx1ZS5mZHAgPz8gMCkpO1xuICAgIGxldCBzID0gYCR7YXJ0aWNsZS52YWx1ZS5uYW1lfSDDoCAke3ByaWNlfeKCrCB2ZW5kdSBwYXIgJHthcnRpY2xlLnZhbHVlLnZlbmRvcn0gOiAke2FydGljbGUudmFsdWUudXJsfWA7XG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQocyk7XG59XG5jb25zdCBhbmFseXplVXJsID0gKCkgPT4ge1xuICAgIGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0sIGZ1bmN0aW9uICh0YWJzKSB7XG4gICAgICAgIGNvbnN0IHRhYiA9IHRhYnNbMF07XG4gICAgICAgIGxldCBjO1xuICAgICAgICBPYmplY3QudmFsdWVzKGN1c3RvbUNvbmZpZ3VyYXRpb25zLnZhbHVlKS5zb21lKChjb25maWd1cmF0aW9uKSA9PiB7XG4gICAgICAgICAgICBpZiAodGFiLnVybC5pbmNsdWRlcyhjb25maWd1cmF0aW9uLnVybCA/PyAnJykpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgQ29uZmlndXJhdGlvbiBmb3VuZCA6ICR7Y29uZmlndXJhdGlvbi5uYW1lfSAoJHtjb25maWd1cmF0aW9uLnV1aWR9KWApO1xuICAgICAgICAgICAgICAgIGNocm9tZS5zY3JpcHRpbmdcbiAgICAgICAgICAgICAgICAgICAgLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgICAgICAgICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICAgICAgICAgICAgICBmdW5jOiBnZXRJbmZvcyxcbiAgICAgICAgICAgICAgICAgICAgYXJnczogW2NvbmZpZ3VyYXRpb24sIHRhYi51cmxdLFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKChpbmplY3Rpb25SZXN1bHRzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgeyBmcmFtZUlkLCByZXN1bHQgfSBvZiBpbmplY3Rpb25SZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhcnRpY2xlLnZhbHVlID0gcmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xufTtcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihmdW5jdGlvbiAocmVxdWVzdCkge1xuICAgIGNvbnNvbGUubG9nKCdwb3B1JyArIHJlcXVlc3QpO1xufSk7XG5jb25zdCBoYW5kbGVDaGFuZ2UgPSAoZXZlbnQpID0+IHtcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAnbmFtZScpXG4gICAgICAgIGFydGljbGUudmFsdWUgPSB7IC4uLmFydGljbGUudmFsdWUsIG5hbWU6IGV2ZW50LnRhcmdldC52YWx1ZSB9O1xuICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICd1cmwnKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0geyAuLi5hcnRpY2xlLnZhbHVlLCB1cmw6IGV2ZW50LnRhcmdldC52YWx1ZSB9O1xuICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICd2ZW5kb3InKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0geyAuLi5hcnRpY2xlLnZhbHVlLCB2ZW5kb3I6IGV2ZW50LnRhcmdldC52YWx1ZSB9O1xuICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICdwcmljZScpXG4gICAgICAgIGFydGljbGUudmFsdWUgPSB7IC4uLmFydGljbGUudmFsdWUsIHByaWNlOiBOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKSB9O1xuICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICdmZHAnKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0geyAuLi5hcnRpY2xlLnZhbHVlLCBmZHA6IE51bWJlcihldmVudC50YXJnZXQudmFsdWUpIH07XG4gICAgaWYgKGV2ZW50LnRhcmdldC5pZCA9PT0gJ2ltZ1VybCcpXG4gICAgICAgIGFydGljbGUudmFsdWUgPSB7IC4uLmFydGljbGUudmFsdWUsIGltZ1VybDogZXZlbnQudGFyZ2V0LnZhbHVlIH07XG4gICAgaWYgKGV2ZW50LnRhcmdldC5pZCA9PT0gJ3dhcm5pbmcnKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0geyAuLi5hcnRpY2xlLnZhbHVlLCB3YXJuaW5nOiBldmVudC50YXJnZXQudmFsdWUgfTtcbn07XG5jb25zdCBQb3B1cCA9ICgpID0+IHtcbiAgICAvLyBjaHJvbWUuYWN0aW9uLnNldEJhZGdlVGV4dCh7IHRleHQ6IGNvdW50LnRvU3RyaW5nKCkgfSk7XG4gICAgdXNlU2lnbmFsRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoe1xuICAgICAgICAgICAgY29uZmlndXJhdGlvbnM6IGluaXRpYWxDb25maWd1cmF0aW9uLFxuICAgICAgICB9LCAoaXRlbXMpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGMgPSBpdGVtcy5jb25maWd1cmF0aW9ucztcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKGluaXRpYWxDb25maWd1cmF0aW9uKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoT2JqZWN0LmtleXMoYykuaW5kZXhPZihrZXkpID09PSAtMSkge1xuICAgICAgICAgICAgICAgICAgICBjW2tleV0gPSBpbml0aWFsQ29uZmlndXJhdGlvbltOdW1iZXIoa2V5KV07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjdXN0b21Db25maWd1cmF0aW9ucy52YWx1ZSA9IGM7XG4gICAgICAgICAgICBhbmFseXplVXJsKCk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xuICAgIGNvbnN0IGNhcmRDb250ZW50ID0ge1xuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICdmbGV4LWRpcmVjdGlvbic6ICdjb2x1bW4nLFxuICAgICAgICBhbGlnbkl0ZW1zOiAnc3RyZWNoJyxcbiAgICAgICAgcm93R2FwOiAnMTBweCcsXG4gICAgICAgIG1pbldpZHRoOiAnODAwcHgnLFxuICAgICAgICB3aWR0aDogJzEwMCUnLFxuICAgIH07XG4gICAgY29uc3QgY2FyZEFjdGlvbiA9IHtcbiAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgICB3aWR0aDogJzEwMCUnLFxuICAgICAgICBjb2x1bW5HYXA6ICc1cHgnLFxuICAgIH07XG4gICAgY29uc3QgaW5wdXRTdHlsZSA9IHtcbiAgICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICAgICAgZmxleDogMSxcbiAgICB9O1xuICAgIGNvbnN0IHByaWNlQ29udGFpbmVyU3R5bGUgPSB7XG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgY29sdW1uR2FwOiAnNXB4JyxcbiAgICB9O1xuICAgIGNvbnN0IHByaWNlSW5wdXRTdHlsZSA9IHtcbiAgICAgICAgd2lkdGg6ICc4MCUnLFxuICAgIH07XG4gICAgY29uc3Qgc2VsbGVySW5wdXRTdHlsZSA9IHtcbiAgICAgICAgd2lkdGg6ICc2MCUnLFxuICAgIH07XG4gICAgY29uc3QgZmRwSW5wdXRTdHlsZSA9IHtcbiAgICAgICAgd2lkdGg6ICcyMCUnLFxuICAgIH07XG4gICAgY29uc3QgaWNvblN0eWxlID0ge1xuICAgICAgICBtYXJnaW5SaWdodDogJzJweCcsXG4gICAgfTtcbiAgICBjb25zdCBidXR0b25TdHlsZSA9IHtcbiAgICAgICAgZmxleDogMSxcbiAgICB9O1xuICAgIGNvbnN0IGRpdmlkZXJTdHlsZSA9IHtcbiAgICAgICAgbWFyZ2luVG9wOiAnMjBweCcsXG4gICAgICAgIG1hcmdpbkJvdHRvbTogJzIwcHgnLFxuICAgIH07XG4gICAgY29uc3QgcHJpY2VSZXBsYWNlclN0eWxlID0ge1xuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgfTtcbiAgICBjb25zdCBwcmljZVJlcGxhY2VySW5wdXRXcmFwcGVyU3R5bGUgPSB7XG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgJ2ZsZXgtZGlyZWN0aW9uJzogJ2NvbHVtbicsXG4gICAgICAgIGFsaWduSXRlbXM6ICdzdHJlY2gnLFxuICAgICAgICByb3dHYXA6ICcxMHB4JyxcbiAgICB9O1xuICAgIGNvbnN0IHByaWNlUmVwbGFjZXJJbnB1dFN0eWxlID0ge1xuICAgICAgICB3aWR0aDogJzUwJScsXG4gICAgfTtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBzdHlsZTogY2FyZENvbnRlbnQgfSxcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBzdHlsZTogY2FyZENvbnRlbnQgfSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSwgdmFsdWU6IGFydGljbGUudmFsdWU/LnZlbmRvciwgaWQ6IFwidmVuZG9yXCIsIGxhYmVsOiBcIlNlbGxlclwiLCBkZWZhdWx0VmFsdWU6IFwiRXJyb3JcIiB9KSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSwgdmFsdWU6IGFydGljbGUudmFsdWU/LnVybCwgaWQ6IFwidXJsXCIsIG11bHRpbGluZTogdHJ1ZSwgbGFiZWw6IFwiVVJMXCIsIGRlZmF1bHRWYWx1ZTogXCJFcnJvclwiIH0pLFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dEZpZWxkLCB7IHN0eWxlOiBpbnB1dFN0eWxlLCBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLCB2YWx1ZTogYXJ0aWNsZS52YWx1ZT8ubmFtZSwgaWQ6IFwibmFtZVwiLCBsYWJlbDogXCJBcnRpY2xlXCIsIGRlZmF1bHRWYWx1ZTogXCJFcnJvclwiIH0pLFxuICAgICAgICAgICAgICAgICFhcnRpY2xlLnZhbHVlPy5wcmljZSAmJiAoUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIHZhbHVlOiBhcnRpY2xlLnZhbHVlPy5wcmljZVRleHQsIGlkOiBcIm5hbWVcIiwgbGFiZWw6IFwiUHJpY2UgVGV4dFwiLCBkZWZhdWx0VmFsdWU6IFwiRXJyb3JcIiwgaGVscGVyVGV4dDogXCJJc3N1ZSB0byBnZXQgYSBudW1iZXIgZnJvbSB0aGUgcHJpY2VcIiB9KSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IHN0eWxlOiBwcmljZUNvbnRhaW5lclN0eWxlIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dEZpZWxkLCB7IHN0eWxlOiBwcmljZUlucHV0U3R5bGUsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIHZhbHVlOiBhcnRpY2xlLnZhbHVlPy5wcmljZSwgaWQ6IFwicHJpY2VcIiwgdHlwZTogXCJudW1iZXJcIiwgbGFiZWw6IFwiUHJpY2VcIiwgZGVmYXVsdFZhbHVlOiBcIjBcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIHZhbHVlOiBhcnRpY2xlLnZhbHVlPy5mZHAsIGlkOiBcImZkcFwiLCB0eXBlOiBcIm51bWJlclwiLCBsYWJlbDogXCJGcmFpcyBEZSBQb3J0XCIsIGRlZmF1bHRWYWx1ZTogXCIwXCIgfSkpLFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dEZpZWxkLCB7IHN0eWxlOiBpbnB1dFN0eWxlLCBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLCB2YWx1ZTogYXJ0aWNsZS52YWx1ZT8ud2FybmluZywgaWQ6IFwid2FybmluZ1wiLCBsYWJlbDogXCJXYXJuaW5nXCIsIG11bHRpbGluZTogdHJ1ZSwgbWF4Um93czogNCwgZGVmYXVsdFZhbHVlOiBcIiBcIiB9KSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSwgdmFsdWU6IGFydGljbGUudmFsdWU/LmltZ1VybCwgaWQ6IFwiaW1nVXJsXCIsIGxhYmVsOiBcIkltYWdlIFVybFwiLCBkZWZhdWx0VmFsdWU6IFwiRXJyb3JcIiB9KSksXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IGNhcmRBY3Rpb24gfSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgeyBzdHlsZTogYnV0dG9uU3R5bGUsIHZhcmlhbnQ6IFwiY29udGFpbmVkXCIsIG9uQ2xpY2s6IGFuYWx5emVVcmwgfSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJY29uLCB7IHN0eWxlOiBpY29uU3R5bGUsIGljb246IFwiY2hhcm06cmVmcmVzaFwiLCBoZWlnaHQ6IFwiMzBcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgXCJSZWZyZXNoXCIpLFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uLCB7IHZhcmlhbnQ6IFwiY29udGFpbmVkXCIsIG9uQ2xpY2s6IGdlbmVyYXRlRXhjZWxDbGlwYm9hcmRTdHJpbmcgfSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJY29uLCB7IGljb246IFwic2ltcGxlLWljb25zOmdvb2dsZXNoZWV0c1wiLCBoZWlnaHQ6IFwiMzZcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgXCJTaGFyZSBvbiBFeGNlbFwiKSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgeyB2YXJpYW50OiBcImNvbnRhaW5lZFwiLCBvbkNsaWNrOiBnZW5lcmF0ZURpc2NvcmRDbGlwYm9hcmRTdHJpbmcgfSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJY29uLCB7IHN0eWxlOiBpY29uU3R5bGUsIGljb246IFwiaWM6YmFzZWxpbmUtZGlzY29yZFwiLCBoZWlnaHQ6IFwiMzBcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgXCJTaGFyZSBvbiBEaXNjb3JkXCIpLFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uLCB7IHZhcmlhbnQ6IFwiY29udGFpbmVkXCIsIG9uQ2xpY2s6IGdlbmVyYXRlVHdpdGNoQ2xpcGJvYXJkU3RyaW5nIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbiwgeyBzdHlsZTogaWNvblN0eWxlLCBpY29uOiBcImZhNi1icmFuZHM6dHdpdGNoXCIsIGhlaWdodDogXCIzMFwiIH0pLFxuICAgICAgICAgICAgICAgICAgICBcIlNoYXJlIE9uIFR3aXRjaFwiKSkpKSk7XG59O1xuY29uc3Qgcm9vdCA9IGNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSk7XG5yb290LnJlbmRlcihSZWFjdC5jcmVhdGVFbGVtZW50KFJlYWN0LlN0cmljdE1vZGUsIG51bGwsXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChQb3B1cCwgbnVsbCkpKTtcbiIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0aWQ6IG1vZHVsZUlkLFxuXHRcdGxvYWRlZDogZmFsc2UsXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0obW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuXHRtb2R1bGUubG9hZGVkID0gdHJ1ZTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbi8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBfX3dlYnBhY2tfbW9kdWxlc19fO1xuXG4iLCJ2YXIgZGVmZXJyZWQgPSBbXTtcbl9fd2VicGFja19yZXF1aXJlX18uTyA9IChyZXN1bHQsIGNodW5rSWRzLCBmbiwgcHJpb3JpdHkpID0+IHtcblx0aWYoY2h1bmtJZHMpIHtcblx0XHRwcmlvcml0eSA9IHByaW9yaXR5IHx8IDA7XG5cdFx0Zm9yKHZhciBpID0gZGVmZXJyZWQubGVuZ3RoOyBpID4gMCAmJiBkZWZlcnJlZFtpIC0gMV1bMl0gPiBwcmlvcml0eTsgaS0tKSBkZWZlcnJlZFtpXSA9IGRlZmVycmVkW2kgLSAxXTtcblx0XHRkZWZlcnJlZFtpXSA9IFtjaHVua0lkcywgZm4sIHByaW9yaXR5XTtcblx0XHRyZXR1cm47XG5cdH1cblx0dmFyIG5vdEZ1bGZpbGxlZCA9IEluZmluaXR5O1xuXHRmb3IgKHZhciBpID0gMDsgaSA8IGRlZmVycmVkLmxlbmd0aDsgaSsrKSB7XG5cdFx0dmFyIFtjaHVua0lkcywgZm4sIHByaW9yaXR5XSA9IGRlZmVycmVkW2ldO1xuXHRcdHZhciBmdWxmaWxsZWQgPSB0cnVlO1xuXHRcdGZvciAodmFyIGogPSAwOyBqIDwgY2h1bmtJZHMubGVuZ3RoOyBqKyspIHtcblx0XHRcdGlmICgocHJpb3JpdHkgJiAxID09PSAwIHx8IG5vdEZ1bGZpbGxlZCA+PSBwcmlvcml0eSkgJiYgT2JqZWN0LmtleXMoX193ZWJwYWNrX3JlcXVpcmVfXy5PKS5ldmVyeSgoa2V5KSA9PiAoX193ZWJwYWNrX3JlcXVpcmVfXy5PW2tleV0oY2h1bmtJZHNbal0pKSkpIHtcblx0XHRcdFx0Y2h1bmtJZHMuc3BsaWNlKGotLSwgMSk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRmdWxmaWxsZWQgPSBmYWxzZTtcblx0XHRcdFx0aWYocHJpb3JpdHkgPCBub3RGdWxmaWxsZWQpIG5vdEZ1bGZpbGxlZCA9IHByaW9yaXR5O1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZihmdWxmaWxsZWQpIHtcblx0XHRcdGRlZmVycmVkLnNwbGljZShpLS0sIDEpXG5cdFx0XHR2YXIgciA9IGZuKCk7XG5cdFx0XHRpZiAociAhPT0gdW5kZWZpbmVkKSByZXN1bHQgPSByO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufTsiLCIvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuX193ZWJwYWNrX3JlcXVpcmVfXy5uID0gKG1vZHVsZSkgPT4ge1xuXHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cblx0XHQoKSA9PiAobW9kdWxlWydkZWZhdWx0J10pIDpcblx0XHQoKSA9PiAobW9kdWxlKTtcblx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgeyBhOiBnZXR0ZXIgfSk7XG5cdHJldHVybiBnZXR0ZXI7XG59OyIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18uZyA9IChmdW5jdGlvbigpIHtcblx0aWYgKHR5cGVvZiBnbG9iYWxUaGlzID09PSAnb2JqZWN0JykgcmV0dXJuIGdsb2JhbFRoaXM7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIHRoaXMgfHwgbmV3IEZ1bmN0aW9uKCdyZXR1cm4gdGhpcycpKCk7XG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ29iamVjdCcpIHJldHVybiB3aW5kb3c7XG5cdH1cbn0pKCk7IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubm1kID0gKG1vZHVsZSkgPT4ge1xuXHRtb2R1bGUucGF0aHMgPSBbXTtcblx0aWYgKCFtb2R1bGUuY2hpbGRyZW4pIG1vZHVsZS5jaGlsZHJlbiA9IFtdO1xuXHRyZXR1cm4gbW9kdWxlO1xufTsiLCIvLyBubyBiYXNlVVJJXG5cbi8vIG9iamVjdCB0byBzdG9yZSBsb2FkZWQgYW5kIGxvYWRpbmcgY2h1bmtzXG4vLyB1bmRlZmluZWQgPSBjaHVuayBub3QgbG9hZGVkLCBudWxsID0gY2h1bmsgcHJlbG9hZGVkL3ByZWZldGNoZWRcbi8vIFtyZXNvbHZlLCByZWplY3QsIFByb21pc2VdID0gY2h1bmsgbG9hZGluZywgMCA9IGNodW5rIGxvYWRlZFxudmFyIGluc3RhbGxlZENodW5rcyA9IHtcblx0XCJwb3B1cFwiOiAwXG59O1xuXG4vLyBubyBjaHVuayBvbiBkZW1hbmQgbG9hZGluZ1xuXG4vLyBubyBwcmVmZXRjaGluZ1xuXG4vLyBubyBwcmVsb2FkZWRcblxuLy8gbm8gSE1SXG5cbi8vIG5vIEhNUiBtYW5pZmVzdFxuXG5fX3dlYnBhY2tfcmVxdWlyZV9fLk8uaiA9IChjaHVua0lkKSA9PiAoaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdID09PSAwKTtcblxuLy8gaW5zdGFsbCBhIEpTT05QIGNhbGxiYWNrIGZvciBjaHVuayBsb2FkaW5nXG52YXIgd2VicGFja0pzb25wQ2FsbGJhY2sgPSAocGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24sIGRhdGEpID0+IHtcblx0dmFyIFtjaHVua0lkcywgbW9yZU1vZHVsZXMsIHJ1bnRpbWVdID0gZGF0YTtcblx0Ly8gYWRkIFwibW9yZU1vZHVsZXNcIiB0byB0aGUgbW9kdWxlcyBvYmplY3QsXG5cdC8vIHRoZW4gZmxhZyBhbGwgXCJjaHVua0lkc1wiIGFzIGxvYWRlZCBhbmQgZmlyZSBjYWxsYmFja1xuXHR2YXIgbW9kdWxlSWQsIGNodW5rSWQsIGkgPSAwO1xuXHRpZihjaHVua0lkcy5zb21lKChpZCkgPT4gKGluc3RhbGxlZENodW5rc1tpZF0gIT09IDApKSkge1xuXHRcdGZvcihtb2R1bGVJZCBpbiBtb3JlTW9kdWxlcykge1xuXHRcdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKG1vcmVNb2R1bGVzLCBtb2R1bGVJZCkpIHtcblx0XHRcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tW21vZHVsZUlkXSA9IG1vcmVNb2R1bGVzW21vZHVsZUlkXTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYocnVudGltZSkgdmFyIHJlc3VsdCA9IHJ1bnRpbWUoX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cdH1cblx0aWYocGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24pIHBhcmVudENodW5rTG9hZGluZ0Z1bmN0aW9uKGRhdGEpO1xuXHRmb3IoO2kgPCBjaHVua0lkcy5sZW5ndGg7IGkrKykge1xuXHRcdGNodW5rSWQgPSBjaHVua0lkc1tpXTtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oaW5zdGFsbGVkQ2h1bmtzLCBjaHVua0lkKSAmJiBpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0pIHtcblx0XHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXVswXSgpO1xuXHRcdH1cblx0XHRpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0gPSAwO1xuXHR9XG5cdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fLk8ocmVzdWx0KTtcbn1cblxudmFyIGNodW5rTG9hZGluZ0dsb2JhbCA9IHNlbGZbXCJ3ZWJwYWNrQ2h1bmtkZWFsX3NuaWZmZXJcIl0gPSBzZWxmW1wid2VicGFja0NodW5rZGVhbF9zbmlmZmVyXCJdIHx8IFtdO1xuY2h1bmtMb2FkaW5nR2xvYmFsLmZvckVhY2god2VicGFja0pzb25wQ2FsbGJhY2suYmluZChudWxsLCAwKSk7XG5jaHVua0xvYWRpbmdHbG9iYWwucHVzaCA9IHdlYnBhY2tKc29ucENhbGxiYWNrLmJpbmQobnVsbCwgY2h1bmtMb2FkaW5nR2xvYmFsLnB1c2guYmluZChjaHVua0xvYWRpbmdHbG9iYWwpKTsiLCIiLCIvLyBzdGFydHVwXG4vLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbi8vIFRoaXMgZW50cnkgbW9kdWxlIGRlcGVuZHMgb24gb3RoZXIgbG9hZGVkIGNodW5rcyBhbmQgZXhlY3V0aW9uIG5lZWQgdG8gYmUgZGVsYXllZFxudmFyIF9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fLk8odW5kZWZpbmVkLCBbXCJ2ZW5kb3JcIl0sICgpID0+IChfX3dlYnBhY2tfcmVxdWlyZV9fKFwiLi9zcmMvcG9wdXAudHN4XCIpKSlcbl9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fLk8oX193ZWJwYWNrX2V4cG9ydHNfXyk7XG4iLCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=