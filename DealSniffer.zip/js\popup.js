/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/customConfiguration.tsx":
/*!*************************************!*\
  !*** ./src/customConfiguration.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "emptyConfiguration": () => (/* binding */ emptyConfiguration),
/* harmony export */   "initialConfiguration": () => (/* binding */ initialConfiguration)
/* harmony export */ });
const initialConfiguration = {
    1: {
        fdp: 0,
        name: 'Amazon FR',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.fr',
        uuid: 1,
        warning: '',
        partnerUrl: '',
    },
    2: {
        fdp: 0,
        name: 'Amazon DE',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.de',
        uuid: 2,
        warning: '',
        partnerUrl: '',
    },
    3: {
        fdp: 0,
        name: 'Amazon ES',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.es',
        uuid: 3,
        warning: '',
        partnerUrl: '',
    },
    4: {
        fdp: 0,
        name: 'Amazon IT',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.it',
        uuid: 4,
        warning: '',
        partnerUrl: '',
    },
    5: {
        fdp: 20,
        imgPreUrl: '',
        imgSelector: '#mainImageDiv img',
        name: 'BPM-Power',
        nameSelector: '.titleText h1',
        priceReplacers: [],
        priceSelector: '#divProductInfoAndHelp .prezzoScheda',
        url: 'bpm-power.com',
        uuid: 5,
        warning: "Bien Vérifier sous 5j qu'il n'y a pas de dégat sur le colis",
        partnerUrl: '',
    },
    6: {
        fdp: 0,
        uuid: 6,
        name: 'CaseKing',
        url: 'caseking.de',
        nameSelector: '#ck_detail  #detailbox h1',
        priceSelector: '#ck_detail #buybox strong',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        imgPreUrl: 'https:',
        imgSelector: '#ck_detail  #detailbox #img img',
        warning: '',
        partnerUrl: '',
    },
    7: {
        fdp: 0,
        uuid: 7,
        name: 'Cdiscount',
        url: 'cdiscount.com',
        nameSelector: '.fpTMain .fpDesCol h1',
        priceSelector: '.fTopPrice  .fpPrice',
        priceReplacers: [
            {
                replaced: '€',
                replaceBy: '.',
            },
        ],
        imgPreUrl: '',
        imgSelector: '#fpZnPrdMain img#picture0',
        warning: '',
        partnerUrl: '',
    },
    8: {
        fdp: 0,
        uuid: 8,
        name: 'Cybertek',
        url: 'cybertek.fr',
        nameSelector: '.fiche-produit__bloc-achat__container .title_fiche',
        priceSelector: '.fiche-produit__bloc-achat__prix  .fiche_product_price > span',
        priceReplacers: [
            {
                replaced: '€',
                replaceBy: '.',
            },
        ],
        imgPreUrl: '',
        imgSelector: '#fiche-produit__container-photos [data-swiper-slide-index="0"] img',
        warning: '',
        partnerUrl: '',
    },
    9: {
        fdp: 0,
        uuid: 9,
        name: 'Grosbill',
        url: 'grosbill.com',
        nameSelector: '.grb_fch-prod__content-title .grb_fch-prod__title',
        priceSelector: '.fiche-produit-r  .fiche_product_price > span.p-3x',
        priceReplacers: [
            {
                replaced: '€',
                replaceBy: '.',
            },
        ],
        imgPreUrl: 'https://www.grosbill.com',
        imgSelector: '#product_buy [data-swiper-slide-index="0"] img',
        warning: '',
        partnerUrl: '',
    },
    10: {
        fdp: 0,
        uuid: 10,
        name: '1FoDiscount',
        url: '1fodiscount.com',
        nameSelector: '.product-sheet_title',
        priceSelector: '.product-sheet_buybox .product-sheet_buybox_offer_price',
        priceReplacers: [],
        imgPreUrl: 'https://www.1fodiscount.com/',
        imgSelector: '.product-sheet_slideshow_scrollable img.product-sheet_slideshow_slide_img',
        warning: '',
        partnerUrl: '',
    },
    11: {
        fdp: 0,
        uuid: 11,
        name: 'PcComponentes FR',
        url: 'pccomponentes.fr',
        nameSelector: '#pdp-title',
        priceSelector: '#pdp-price-current-integer',
        priceReplacers: [],
        imgPreUrl: 'https:',
        imgSelector: '#pdp-section-images img',
        warning: '',
        partnerUrl: '',
    },
    12: {
        fdp: 0,
        uuid: 12,
        name: 'PcComponentes ',
        url: 'pccomponentes.com',
        nameSelector: '#pdp-title',
        priceSelector: '#pdp-price-current-integer',
        priceReplacers: [],
        imgPreUrl: 'https:',
        imgSelector: '#pdp-section-images img',
        warning: '',
        partnerUrl: '',
    },
    13: {
        fdp: 0,
        imgPreUrl: '',
        imgSelector: '.elementor-carousel-image',
        name: 'Psk Mega Store',
        nameSelector: '.ce-product-name',
        partnerUrl: '',
        priceReplacers: [],
        priceSelector: '.ce-product-prices span',
        url: 'pskmegastore.com',
        uuid: 13,
        warning: 'En test',
    },
    14: {
        fdp: 0,
        uuid: 14,
        name: 'Rue du Commerce',
        url: 'rueducommerce.fr',
        nameSelector: '.product-name > span',
        priceSelector: '.product__price .dyn_prod_price',
        priceReplacers: [],
        imgPreUrl: '',
        imgSelector: '#gallery .owl-item img',
        warning: '',
        partnerUrl: '',
    },
    15: {
        fdp: 7,
        uuid: 15,
        name: 'Reichelt',
        url: 'www.reichelt.com',
        nameSelector: '.av_articleheader [itemprop="name"]',
        priceSelector: '#av_price',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        imgPreUrl: '',
        imgSelector: '#gallery img',
        warning: '',
        partnerUrl: '',
    },
    16: {
        fdp: 5,
        uuid: 16,
        name: 'TopAchat',
        url: 'topachat.com',
        nameSelector: '.ps-main__product-title',
        priceSelector: '.ps-main__offer  .offer-price__price',
        priceReplacers: [],
        imgPreUrl: 'https:',
        imgSelector: '.product-main-image.ps-main__main-image img',
        warning: '',
        partnerUrl: '',
    },
};
const emptyConfiguration = {
    name: 'New Configuration',
    fdp: 0,
    uuid: 0,
    url: 'new url',
    warning: 'En test',
    priceSelector: '.ce-product-prices span',
    priceReplacers: [],
    imgSelector: '.elementor-carousel-image',
    imgPreUrl: '',
    nameSelector: '.ce-product-name',
    partnerUrl: '',
};




/***/ }),

/***/ "./src/get-infos.tsx":
/*!***************************!*\
  !*** ./src/get-infos.tsx ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const getInfos = (configuration, url) => {
    let a = {};
    a.name =
        document.querySelector(configuration.nameSelector)
            ?.innerText ?? 'Not Found';
    a.priceText = document.querySelector(configuration.priceSelector).innerText;
    configuration.priceReplacers.forEach((r) => {
        a.priceText = a.priceText?.replaceAll(r.replaced, r.replaceBy);
    });
    a.vendor = configuration.name;
    a.imgUrl =
        (configuration.imgPreUrl ?? '') +
            document.querySelector(configuration.imgSelector)?.getAttribute('src') ??
            'Not Found';
    a.priceText = a.priceText?.replaceAll(',', '.').replace(/[^0-9\.]/g, '');
    a.price = Number(a.priceText);
    a.name = a.name?.replace('\n', ' ') ?? 'Not found';
    a.url = url?.replace(/\?.+/, '?' + configuration.partnerUrl);
    a.fdp = configuration.fdp;
    a.warning = configuration.warning;
    // Si selection de text, nom = selection texte
    let selection = window?.getSelection()?.toString();
    a.name = selection != '' ? selection : a?.name?.replace('"', '');
    return a;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getInfos);


/***/ }),

/***/ "./src/popup.tsx":
/*!***********************!*\
  !*** ./src/popup.tsx ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom/client */ "./node_modules/react-dom/client.js");
/* harmony import */ var _preact_signals_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @preact/signals-react */ "./node_modules/@preact/signals-react/dist/signals.module.js");
/* harmony import */ var _get_infos__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./get-infos */ "./src/get-infos.tsx");
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/material/Button */ "./node_modules/@mui/material/Button/Button.js");
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material/TextField */ "./node_modules/@mui/material/TextField/TextField.js");
/* harmony import */ var _customConfiguration__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./customConfiguration */ "./src/customConfiguration.tsx");
/* harmony import */ var _iconify_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @iconify/react */ "./node_modules/@iconify/react/dist/iconify.mjs");








const article = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)({});
const customConfigurations = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)(_customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration);
function generateExcelClipboardString() {
    let price = Math.round((article.value.price ?? 0) + (article.value.fdp ?? 0));
    let s = `=IMAGE("${article.value.imgUrl}")\t`;
    s += `=HYPERLINK("${article.value.url}";"${article.value.name}")\t`;
    s += `${article.value.vendor}\t`;
    s += `${price} €\t`;
    navigator.clipboard.writeText(s);
}
function generateDiscordClipboardString() {
    let price = Math.round((article.value.price ?? 0) + (article.value.fdp ?? 0));
    let s = `**${article.value.name}** à **${price}€** vendu par **${article.value.vendor}** :`;
    if (article.value.warning)
        s += `\n:warning:${article.value.warning}:warning:`;
    s += `\n${article.value.url}`;
    navigator.clipboard.writeText(s);
}
function generateTwitchClipboardString() {
    let price = Math.round((article.value.price ?? 0) + (article.value.fdp ?? 0));
    let s = `${article.value.name} à ${price}€ vendu par ${article.value.vendor} : ${article.value.url}`;
    navigator.clipboard.writeText(s);
}
const analyzeUrl = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const tab = tabs[0];
        let c;
        Object.values(customConfigurations.value).some((configuration) => {
            if (tab.url.includes(configuration.url ?? '')) {
                console.log(`Configuration found : ${configuration.name} (${configuration.uuid})`);
                chrome.scripting
                    .executeScript({
                    target: { tabId: tab.id },
                    func: _get_infos__WEBPACK_IMPORTED_MODULE_3__["default"],
                    args: [configuration, tab.url],
                })
                    .then((injectionResults) => {
                    for (const { frameId, result } of injectionResults) {
                        article.value = result;
                    }
                });
            }
        });
    });
};
chrome.runtime.onMessage.addListener(function (request) {
    console.log('popu' + request);
});
const handleChange = (event) => {
    if (event.target.id === 'name')
        article.value = { ...article.value, name: event.target.value };
    if (event.target.id === 'url')
        article.value = { ...article.value, url: event.target.value };
    if (event.target.id === 'vendor')
        article.value = { ...article.value, vendor: event.target.value };
    if (event.target.id === 'price')
        article.value = { ...article.value, price: Number(event.target.value) };
    if (event.target.id === 'fdp')
        article.value = { ...article.value, fdp: Number(event.target.value) };
    if (event.target.id === 'imgUrl')
        article.value = { ...article.value, imgUrl: event.target.value };
    if (event.target.id === 'warning')
        article.value = { ...article.value, warning: event.target.value };
};
const Popup = () => {
    // chrome.action.setBadgeText({ text: count.toString() });
    (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.useSignalEffect)(() => {
        chrome.storage.sync.get({
            configurations: _customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration,
        }, (items) => {
            const c = items.configurations;
            Object.keys(_customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration).forEach((key) => {
                if (Object.keys(c).indexOf(key) === -1) {
                    c[key] = _customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration[Number(key)];
                }
            });
            customConfigurations.value = c;
            analyzeUrl();
        });
    });
    const cardContent = {
        display: 'flex',
        'flex-direction': 'column',
        alignItems: 'strech',
        rowGap: '10px',
        minWidth: '800px',
        width: '100%',
    };
    const cardAction = {
        display: 'flex',
        width: '100%',
        columnGap: '5px',
    };
    const inputStyle = {
        width: '100%',
        flex: 1,
    };
    const priceContainerStyle = {
        display: 'flex',
        columnGap: '5px',
    };
    const priceInputStyle = {
        width: '80%',
    };
    const sellerInputStyle = {
        width: '60%',
    };
    const fdpInputStyle = {
        width: '20%',
    };
    const iconStyle = {
        marginRight: '2px',
    };
    const buttonStyle = {
        flex: 1,
    };
    const dividerStyle = {
        marginTop: '20px',
        marginBottom: '20px',
    };
    const priceReplacerStyle = {
        display: 'flex',
    };
    const priceReplacerInputWrapperStyle = {
        display: 'flex',
        'flex-direction': 'column',
        alignItems: 'strech',
        rowGap: '10px',
    };
    const priceReplacerInputStyle = {
        width: '50%',
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardContent },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardContent },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.vendor, id: "vendor", label: "Seller", defaultValue: "Error" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.url, id: "url", multiline: true, label: "URL", defaultValue: "Error" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.name, id: "name", label: "Article", defaultValue: "Error" }),
                !article.value?.price && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, value: article.value?.priceText, id: "name", label: "Price Text", defaultValue: "Error", helperText: "Issue to get a number from the price" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: priceContainerStyle },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: priceInputStyle, onChange: handleChange, value: article.value?.price, id: "price", type: "number", label: "Price", defaultValue: "0" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.fdp, id: "fdp", type: "number", label: "Frais De Port", defaultValue: "0" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.warning, id: "warning", label: "Warning", multiline: true, maxRows: 4, defaultValue: " " }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__["default"], { style: inputStyle, onChange: handleChange, value: article.value?.imgUrl, id: "imgUrl", label: "Image Url", defaultValue: "Error" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardAction },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_7__["default"], { style: buttonStyle, variant: "contained", onClick: analyzeUrl },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_5__.Icon, { style: iconStyle, icon: "charm:refresh", height: "30" }),
                    "Refresh"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_7__["default"], { variant: "contained", onClick: generateExcelClipboardString },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_5__.Icon, { icon: "simple-icons:googlesheets", height: "36" }),
                    "Share on Excel"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_7__["default"], { variant: "contained", onClick: generateDiscordClipboardString },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_5__.Icon, { style: iconStyle, icon: "ic:baseline-discord", height: "30" }),
                    "Share on Discord"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_7__["default"], { variant: "contained", onClick: generateTwitchClipboardString },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_5__.Icon, { style: iconStyle, icon: "fa6-brands:twitch", height: "30" }),
                    "Share On Twitch")))));
};
const root = (0,react_dom_client__WEBPACK_IMPORTED_MODULE_1__.createRoot)(document.getElementById('root'));
root.render(react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().StrictMode), null,
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Popup, null)));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"popup": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkdeal_sniffer"] = self["webpackChunkdeal_sniffer"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__("./src/popup.tsx")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUM4QjtBQUNFOzs7Ozs7Ozs7Ozs7Ozs7QUM3UWhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpRUFBZSxRQUFRLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCRTtBQUNvQjtBQUNrQjtBQUM3QjtBQUNPO0FBQ007QUFDYztBQUN4QjtBQUN0QyxnQkFBZ0IsNkRBQU0sR0FBRztBQUN6Qiw2QkFBNkIsNkRBQU0sQ0FBQyxzRUFBb0I7QUFDeEQ7QUFDQTtBQUNBLHVCQUF1QixxQkFBcUI7QUFDNUMsd0JBQXdCLGtCQUFrQixFQUFFLEdBQUcsbUJBQW1CO0FBQ2xFLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksT0FBTztBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixtQkFBbUIsU0FBUyxNQUFNLGtCQUFrQixxQkFBcUI7QUFDMUY7QUFDQSwyQkFBMkIsc0JBQXNCO0FBQ2pELGNBQWMsa0JBQWtCO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSxvQkFBb0IsSUFBSSxNQUFNLGNBQWMsc0JBQXNCLElBQUksa0JBQWtCO0FBQ3ZHO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixtQ0FBbUM7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxREFBcUQsb0JBQW9CLEdBQUcsbUJBQW1CO0FBQy9GO0FBQ0E7QUFDQSw4QkFBOEIsZUFBZTtBQUM3QywwQkFBMEIsa0RBQVE7QUFDbEM7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxpQ0FBaUMsa0JBQWtCO0FBQ25EO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQSxvQ0FBb0Msd0JBQXdCO0FBQzVELElBQUksc0VBQWU7QUFDbkI7QUFDQSw0QkFBNEIsc0VBQW9CO0FBQ2hELFNBQVM7QUFDVDtBQUNBLHdCQUF3QixzRUFBb0I7QUFDNUM7QUFDQSw2QkFBNkIsc0VBQW9CO0FBQ2pEO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSwwREFBbUIsQ0FBQyx1REFBYztBQUM5QyxRQUFRLDBEQUFtQixVQUFVLG9CQUFvQjtBQUN6RCxZQUFZLDBEQUFtQixVQUFVLG9CQUFvQjtBQUM3RCxnQkFBZ0IsMERBQW1CLENBQUMsK0RBQVMsSUFBSSwrSEFBK0g7QUFDaEwsZ0JBQWdCLDBEQUFtQixDQUFDLCtEQUFTLElBQUksdUlBQXVJO0FBQ3hMLGdCQUFnQiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLDRIQUE0SDtBQUM3SywwQ0FBMEMsMERBQW1CLENBQUMsK0RBQVMsSUFBSSxnS0FBZ0s7QUFDM08sZ0JBQWdCLDBEQUFtQixVQUFVLDRCQUE0QjtBQUN6RSxvQkFBb0IsMERBQW1CLENBQUMsK0RBQVMsSUFBSSw2SUFBNkk7QUFDbE0sb0JBQW9CLDBEQUFtQixDQUFDLCtEQUFTLElBQUksNElBQTRJO0FBQ2pNLGdCQUFnQiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLDJKQUEySjtBQUM1TSxnQkFBZ0IsMERBQW1CLENBQUMsK0RBQVMsSUFBSSxrSUFBa0k7QUFDbkwsWUFBWSwwREFBbUIsVUFBVSxtQkFBbUI7QUFDNUQsZ0JBQWdCLDBEQUFtQixDQUFDLDREQUFNLElBQUksK0RBQStEO0FBQzdHLG9CQUFvQiwwREFBbUIsQ0FBQyxnREFBSSxJQUFJLHVEQUF1RDtBQUN2RztBQUNBLGdCQUFnQiwwREFBbUIsQ0FBQyw0REFBTSxJQUFJLDZEQUE2RDtBQUMzRyxvQkFBb0IsMERBQW1CLENBQUMsZ0RBQUksSUFBSSxpREFBaUQ7QUFDakc7QUFDQSxnQkFBZ0IsMERBQW1CLENBQUMsNERBQU0sSUFBSSwrREFBK0Q7QUFDN0csb0JBQW9CLDBEQUFtQixDQUFDLGdEQUFJLElBQUksNkRBQTZEO0FBQzdHO0FBQ0EsZ0JBQWdCLDBEQUFtQixDQUFDLDREQUFNLElBQUksOERBQThEO0FBQzVHLG9CQUFvQiwwREFBbUIsQ0FBQyxnREFBSSxJQUFJLDJEQUEyRDtBQUMzRztBQUNBO0FBQ0EsYUFBYSw0REFBVTtBQUN2QixZQUFZLDBEQUFtQixDQUFDLHlEQUFnQjtBQUNoRCxJQUFJLDBEQUFtQjs7Ozs7OztVQ3hLdkI7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOztVQUVBO1VBQ0E7Ozs7O1dDNUJBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsK0JBQStCLHdDQUF3QztXQUN2RTtXQUNBO1dBQ0E7V0FDQTtXQUNBLGlCQUFpQixxQkFBcUI7V0FDdEM7V0FDQTtXQUNBLGtCQUFrQixxQkFBcUI7V0FDdkM7V0FDQTtXQUNBLEtBQUs7V0FDTDtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7Ozs7O1dDM0JBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQ0FBaUMsV0FBVztXQUM1QztXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EseUNBQXlDLHdDQUF3QztXQUNqRjtXQUNBO1dBQ0E7Ozs7O1dDUEE7V0FDQTtXQUNBO1dBQ0E7V0FDQSxHQUFHO1dBQ0g7V0FDQTtXQUNBLENBQUM7Ozs7O1dDUEQ7Ozs7O1dDQUE7V0FDQTtXQUNBO1dBQ0EsdURBQXVELGlCQUFpQjtXQUN4RTtXQUNBLGdEQUFnRCxhQUFhO1dBQzdEOzs7OztXQ05BO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7Ozs7O1dDSkE7O1dBRUE7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLE1BQU0scUJBQXFCO1dBQzNCO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7O1dBRUE7V0FDQTtXQUNBOzs7OztVRWhEQTtVQUNBO1VBQ0E7VUFDQTtVQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZGVhbC1zbmlmZmVyLy4vc3JjL2N1c3RvbUNvbmZpZ3VyYXRpb24udHN4Iiwid2VicGFjazovL2RlYWwtc25pZmZlci8uL3NyYy9nZXQtaW5mb3MudHN4Iiwid2VicGFjazovL2RlYWwtc25pZmZlci8uL3NyYy9wb3B1cC50c3giLCJ3ZWJwYWNrOi8vZGVhbC1zbmlmZmVyL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY2h1bmsgbG9hZGVkIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvZ2xvYmFsIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbm9kZSBtb2R1bGUgZGVjb3JhdG9yIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvanNvbnAgY2h1bmsgbG9hZGluZyIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgaW5pdGlhbENvbmZpZ3VyYXRpb24gPSB7XG4gICAgMToge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIG5hbWU6ICdBbWF6b24gRlInLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcjcHJvZHVjdFRpdGxlJyxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjaW1nVGFnV3JhcHBlcklkIGltZycsXG4gICAgICAgIHByaWNlU2VsZWN0b3I6ICcjY29yZVByaWNlX2ZlYXR1cmVfZGl2IC5hLXByaWNlLXdob2xlJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZXBsYWNlZDogJy4nLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJycsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICB1cmw6ICdhbWF6b24uZnInLFxuICAgICAgICB1dWlkOiAxLFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICAyOiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgbmFtZTogJ0FtYXpvbiBERScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJyNwcm9kdWN0VGl0bGUnLFxuICAgICAgICBpbWdQcmVVcmw6ICcnLFxuICAgICAgICBpbWdTZWxlY3RvcjogJyNpbWdUYWdXcmFwcGVySWQgaW1nJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNjb3JlUHJpY2VfZmVhdHVyZV9kaXYgLmEtcHJpY2Utd2hvbGUnLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJlcGxhY2VkOiAnLicsXG4gICAgICAgICAgICAgICAgcmVwbGFjZUJ5OiAnJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHVybDogJ2FtYXpvbi5kZScsXG4gICAgICAgIHV1aWQ6IDIsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDM6IHtcbiAgICAgICAgZmRwOiAwLFxuICAgICAgICBuYW1lOiAnQW1hem9uIEVTJyxcbiAgICAgICAgbmFtZVNlbGVjdG9yOiAnI3Byb2R1Y3RUaXRsZScsXG4gICAgICAgIGltZ1ByZVVybDogJycsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI2ltZ1RhZ1dyYXBwZXJJZCBpbWcnLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnI2NvcmVQcmljZV9mZWF0dXJlX2RpdiAuYS1wcmljZS13aG9sZScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZWQ6ICcuJyxcbiAgICAgICAgICAgICAgICByZXBsYWNlQnk6ICcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgdXJsOiAnYW1hem9uLmVzJyxcbiAgICAgICAgdXVpZDogMyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG4gICAgNDoge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIG5hbWU6ICdBbWF6b24gSVQnLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcjcHJvZHVjdFRpdGxlJyxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjaW1nVGFnV3JhcHBlcklkIGltZycsXG4gICAgICAgIHByaWNlU2VsZWN0b3I6ICcjY29yZVByaWNlX2ZlYXR1cmVfZGl2IC5hLXByaWNlLXdob2xlJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZXBsYWNlZDogJy4nLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJycsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICB1cmw6ICdhbWF6b24uaXQnLFxuICAgICAgICB1dWlkOiA0LFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICA1OiB7XG4gICAgICAgIGZkcDogMjAsXG4gICAgICAgIGltZ1ByZVVybDogJycsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI21haW5JbWFnZURpdiBpbWcnLFxuICAgICAgICBuYW1lOiAnQlBNLVBvd2VyJyxcbiAgICAgICAgbmFtZVNlbGVjdG9yOiAnLnRpdGxlVGV4dCBoMScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXSxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNkaXZQcm9kdWN0SW5mb0FuZEhlbHAgLnByZXp6b1NjaGVkYScsXG4gICAgICAgIHVybDogJ2JwbS1wb3dlci5jb20nLFxuICAgICAgICB1dWlkOiA1LFxuICAgICAgICB3YXJuaW5nOiBcIkJpZW4gVsOpcmlmaWVyIHNvdXMgNWogcXUnaWwgbid5IGEgcGFzIGRlIGTDqWdhdCBzdXIgbGUgY29saXNcIixcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICA2OiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgdXVpZDogNixcbiAgICAgICAgbmFtZTogJ0Nhc2VLaW5nJyxcbiAgICAgICAgdXJsOiAnY2FzZWtpbmcuZGUnLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcjY2tfZGV0YWlsICAjZGV0YWlsYm94IGgxJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNja19kZXRhaWwgI2J1eWJveCBzdHJvbmcnLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJlcGxhY2VkOiAnLicsXG4gICAgICAgICAgICAgICAgcmVwbGFjZUJ5OiAnJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIGltZ1ByZVVybDogJ2h0dHBzOicsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI2NrX2RldGFpbCAgI2RldGFpbGJveCAjaW1nIGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDc6IHtcbiAgICAgICAgZmRwOiAwLFxuICAgICAgICB1dWlkOiA3LFxuICAgICAgICBuYW1lOiAnQ2Rpc2NvdW50JyxcbiAgICAgICAgdXJsOiAnY2Rpc2NvdW50LmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5mcFRNYWluIC5mcERlc0NvbCBoMScsXG4gICAgICAgIHByaWNlU2VsZWN0b3I6ICcuZlRvcFByaWNlICAuZnBQcmljZScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZWQ6ICfigqwnLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJy4nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjZnBablByZE1haW4gaW1nI3BpY3R1cmUwJyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG4gICAgODoge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIHV1aWQ6IDgsXG4gICAgICAgIG5hbWU6ICdDeWJlcnRlaycsXG4gICAgICAgIHVybDogJ2N5YmVydGVrLmZyJyxcbiAgICAgICAgbmFtZVNlbGVjdG9yOiAnLmZpY2hlLXByb2R1aXRfX2Jsb2MtYWNoYXRfX2NvbnRhaW5lciAudGl0bGVfZmljaGUnLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnLmZpY2hlLXByb2R1aXRfX2Jsb2MtYWNoYXRfX3ByaXggIC5maWNoZV9wcm9kdWN0X3ByaWNlID4gc3BhbicsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZWQ6ICfigqwnLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJy4nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjZmljaGUtcHJvZHVpdF9fY29udGFpbmVyLXBob3RvcyBbZGF0YS1zd2lwZXItc2xpZGUtaW5kZXg9XCIwXCJdIGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDk6IHtcbiAgICAgICAgZmRwOiAwLFxuICAgICAgICB1dWlkOiA5LFxuICAgICAgICBuYW1lOiAnR3Jvc2JpbGwnLFxuICAgICAgICB1cmw6ICdncm9zYmlsbC5jb20nLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcuZ3JiX2ZjaC1wcm9kX19jb250ZW50LXRpdGxlIC5ncmJfZmNoLXByb2RfX3RpdGxlJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJy5maWNoZS1wcm9kdWl0LXIgIC5maWNoZV9wcm9kdWN0X3ByaWNlID4gc3Bhbi5wLTN4JyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZXBsYWNlZDogJ+KCrCcsXG4gICAgICAgICAgICAgICAgcmVwbGFjZUJ5OiAnLicsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBpbWdQcmVVcmw6ICdodHRwczovL3d3dy5ncm9zYmlsbC5jb20nLFxuICAgICAgICBpbWdTZWxlY3RvcjogJyNwcm9kdWN0X2J1eSBbZGF0YS1zd2lwZXItc2xpZGUtaW5kZXg9XCIwXCJdIGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDEwOiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgdXVpZDogMTAsXG4gICAgICAgIG5hbWU6ICcxRm9EaXNjb3VudCcsXG4gICAgICAgIHVybDogJzFmb2Rpc2NvdW50LmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5wcm9kdWN0LXNoZWV0X3RpdGxlJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJy5wcm9kdWN0LXNoZWV0X2J1eWJveCAucHJvZHVjdC1zaGVldF9idXlib3hfb2ZmZXJfcHJpY2UnLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW10sXG4gICAgICAgIGltZ1ByZVVybDogJ2h0dHBzOi8vd3d3LjFmb2Rpc2NvdW50LmNvbS8nLFxuICAgICAgICBpbWdTZWxlY3RvcjogJy5wcm9kdWN0LXNoZWV0X3NsaWRlc2hvd19zY3JvbGxhYmxlIGltZy5wcm9kdWN0LXNoZWV0X3NsaWRlc2hvd19zbGlkZV9pbWcnLFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICAxMToge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIHV1aWQ6IDExLFxuICAgICAgICBuYW1lOiAnUGNDb21wb25lbnRlcyBGUicsXG4gICAgICAgIHVybDogJ3BjY29tcG9uZW50ZXMuZnInLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcjcGRwLXRpdGxlJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNwZHAtcHJpY2UtY3VycmVudC1pbnRlZ2VyJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtdLFxuICAgICAgICBpbWdQcmVVcmw6ICdodHRwczonLFxuICAgICAgICBpbWdTZWxlY3RvcjogJyNwZHAtc2VjdGlvbi1pbWFnZXMgaW1nJyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG4gICAgMTI6IHtcbiAgICAgICAgZmRwOiAwLFxuICAgICAgICB1dWlkOiAxMixcbiAgICAgICAgbmFtZTogJ1BjQ29tcG9uZW50ZXMgJyxcbiAgICAgICAgdXJsOiAncGNjb21wb25lbnRlcy5jb20nLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcjcGRwLXRpdGxlJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNwZHAtcHJpY2UtY3VycmVudC1pbnRlZ2VyJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtdLFxuICAgICAgICBpbWdQcmVVcmw6ICdodHRwczonLFxuICAgICAgICBpbWdTZWxlY3RvcjogJyNwZHAtc2VjdGlvbi1pbWFnZXMgaW1nJyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG4gICAgMTM6IHtcbiAgICAgICAgZmRwOiAwLFxuICAgICAgICBpbWdQcmVVcmw6ICcnLFxuICAgICAgICBpbWdTZWxlY3RvcjogJy5lbGVtZW50b3ItY2Fyb3VzZWwtaW1hZ2UnLFxuICAgICAgICBuYW1lOiAnUHNrIE1lZ2EgU3RvcmUnLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcuY2UtcHJvZHVjdC1uYW1lJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXSxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJy5jZS1wcm9kdWN0LXByaWNlcyBzcGFuJyxcbiAgICAgICAgdXJsOiAncHNrbWVnYXN0b3JlLmNvbScsXG4gICAgICAgIHV1aWQ6IDEzLFxuICAgICAgICB3YXJuaW5nOiAnRW4gdGVzdCcsXG4gICAgfSxcbiAgICAxNDoge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIHV1aWQ6IDE0LFxuICAgICAgICBuYW1lOiAnUnVlIGR1IENvbW1lcmNlJyxcbiAgICAgICAgdXJsOiAncnVlZHVjb21tZXJjZS5mcicsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5wcm9kdWN0LW5hbWUgPiBzcGFuJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJy5wcm9kdWN0X19wcmljZSAuZHluX3Byb2RfcHJpY2UnLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW10sXG4gICAgICAgIGltZ1ByZVVybDogJycsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI2dhbGxlcnkgLm93bC1pdGVtIGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDE1OiB7XG4gICAgICAgIGZkcDogNyxcbiAgICAgICAgdXVpZDogMTUsXG4gICAgICAgIG5hbWU6ICdSZWljaGVsdCcsXG4gICAgICAgIHVybDogJ3d3dy5yZWljaGVsdC5jb20nLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcuYXZfYXJ0aWNsZWhlYWRlciBbaXRlbXByb3A9XCJuYW1lXCJdJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNhdl9wcmljZScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZWQ6ICcuJyxcbiAgICAgICAgICAgICAgICByZXBsYWNlQnk6ICcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjZ2FsbGVyeSBpbWcnLFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICAxNjoge1xuICAgICAgICBmZHA6IDUsXG4gICAgICAgIHV1aWQ6IDE2LFxuICAgICAgICBuYW1lOiAnVG9wQWNoYXQnLFxuICAgICAgICB1cmw6ICd0b3BhY2hhdC5jb20nLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcucHMtbWFpbl9fcHJvZHVjdC10aXRsZScsXG4gICAgICAgIHByaWNlU2VsZWN0b3I6ICcucHMtbWFpbl9fb2ZmZXIgIC5vZmZlci1wcmljZV9fcHJpY2UnLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW10sXG4gICAgICAgIGltZ1ByZVVybDogJ2h0dHBzOicsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnLnByb2R1Y3QtbWFpbi1pbWFnZS5wcy1tYWluX19tYWluLWltYWdlIGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxufTtcbmNvbnN0IGVtcHR5Q29uZmlndXJhdGlvbiA9IHtcbiAgICBuYW1lOiAnTmV3IENvbmZpZ3VyYXRpb24nLFxuICAgIGZkcDogMCxcbiAgICB1dWlkOiAwLFxuICAgIHVybDogJ25ldyB1cmwnLFxuICAgIHdhcm5pbmc6ICdFbiB0ZXN0JyxcbiAgICBwcmljZVNlbGVjdG9yOiAnLmNlLXByb2R1Y3QtcHJpY2VzIHNwYW4nLFxuICAgIHByaWNlUmVwbGFjZXJzOiBbXSxcbiAgICBpbWdTZWxlY3RvcjogJy5lbGVtZW50b3ItY2Fyb3VzZWwtaW1hZ2UnLFxuICAgIGltZ1ByZVVybDogJycsXG4gICAgbmFtZVNlbGVjdG9yOiAnLmNlLXByb2R1Y3QtbmFtZScsXG4gICAgcGFydG5lclVybDogJycsXG59O1xuZXhwb3J0IHsgZW1wdHlDb25maWd1cmF0aW9uIH07XG5leHBvcnQgeyBpbml0aWFsQ29uZmlndXJhdGlvbiB9O1xuIiwiY29uc3QgZ2V0SW5mb3MgPSAoY29uZmlndXJhdGlvbiwgdXJsKSA9PiB7XG4gICAgbGV0IGEgPSB7fTtcbiAgICBhLm5hbWUgPVxuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGNvbmZpZ3VyYXRpb24ubmFtZVNlbGVjdG9yKVxuICAgICAgICAgICAgPy5pbm5lclRleHQgPz8gJ05vdCBGb3VuZCc7XG4gICAgYS5wcmljZVRleHQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGNvbmZpZ3VyYXRpb24ucHJpY2VTZWxlY3RvcikuaW5uZXJUZXh0O1xuICAgIGNvbmZpZ3VyYXRpb24ucHJpY2VSZXBsYWNlcnMuZm9yRWFjaCgocikgPT4ge1xuICAgICAgICBhLnByaWNlVGV4dCA9IGEucHJpY2VUZXh0Py5yZXBsYWNlQWxsKHIucmVwbGFjZWQsIHIucmVwbGFjZUJ5KTtcbiAgICB9KTtcbiAgICBhLnZlbmRvciA9IGNvbmZpZ3VyYXRpb24ubmFtZTtcbiAgICBhLmltZ1VybCA9XG4gICAgICAgIChjb25maWd1cmF0aW9uLmltZ1ByZVVybCA/PyAnJykgK1xuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihjb25maWd1cmF0aW9uLmltZ1NlbGVjdG9yKT8uZ2V0QXR0cmlidXRlKCdzcmMnKSA/P1xuICAgICAgICAgICAgJ05vdCBGb3VuZCc7XG4gICAgYS5wcmljZVRleHQgPSBhLnByaWNlVGV4dD8ucmVwbGFjZUFsbCgnLCcsICcuJykucmVwbGFjZSgvW14wLTlcXC5dL2csICcnKTtcbiAgICBhLnByaWNlID0gTnVtYmVyKGEucHJpY2VUZXh0KTtcbiAgICBhLm5hbWUgPSBhLm5hbWU/LnJlcGxhY2UoJ1xcbicsICcgJykgPz8gJ05vdCBmb3VuZCc7XG4gICAgYS51cmwgPSB1cmw/LnJlcGxhY2UoL1xcPy4rLywgJz8nICsgY29uZmlndXJhdGlvbi5wYXJ0bmVyVXJsKTtcbiAgICBhLmZkcCA9IGNvbmZpZ3VyYXRpb24uZmRwO1xuICAgIGEud2FybmluZyA9IGNvbmZpZ3VyYXRpb24ud2FybmluZztcbiAgICAvLyBTaSBzZWxlY3Rpb24gZGUgdGV4dCwgbm9tID0gc2VsZWN0aW9uIHRleHRlXG4gICAgbGV0IHNlbGVjdGlvbiA9IHdpbmRvdz8uZ2V0U2VsZWN0aW9uKCk/LnRvU3RyaW5nKCk7XG4gICAgYS5uYW1lID0gc2VsZWN0aW9uICE9ICcnID8gc2VsZWN0aW9uIDogYT8ubmFtZT8ucmVwbGFjZSgnXCInLCAnJyk7XG4gICAgcmV0dXJuIGE7XG59O1xuZXhwb3J0IGRlZmF1bHQgZ2V0SW5mb3M7XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnO1xuaW1wb3J0IHsgc2lnbmFsLCB1c2VTaWduYWxFZmZlY3QgfSBmcm9tICdAcHJlYWN0L3NpZ25hbHMtcmVhY3QnO1xuaW1wb3J0IGdldEluZm9zIGZyb20gJy4vZ2V0LWluZm9zJztcbmltcG9ydCBCdXR0b24gZnJvbSAnQG11aS9tYXRlcmlhbC9CdXR0b24nO1xuaW1wb3J0IFRleHRGaWVsZCBmcm9tICdAbXVpL21hdGVyaWFsL1RleHRGaWVsZCc7XG5pbXBvcnQgeyBpbml0aWFsQ29uZmlndXJhdGlvbiwgfSBmcm9tICcuL2N1c3RvbUNvbmZpZ3VyYXRpb24nO1xuaW1wb3J0IHsgSWNvbiB9IGZyb20gJ0BpY29uaWZ5L3JlYWN0JztcbmNvbnN0IGFydGljbGUgPSBzaWduYWwoe30pO1xuY29uc3QgY3VzdG9tQ29uZmlndXJhdGlvbnMgPSBzaWduYWwoaW5pdGlhbENvbmZpZ3VyYXRpb24pO1xuZnVuY3Rpb24gZ2VuZXJhdGVFeGNlbENsaXBib2FyZFN0cmluZygpIHtcbiAgICBsZXQgcHJpY2UgPSBNYXRoLnJvdW5kKChhcnRpY2xlLnZhbHVlLnByaWNlID8/IDApICsgKGFydGljbGUudmFsdWUuZmRwID8/IDApKTtcbiAgICBsZXQgcyA9IGA9SU1BR0UoXCIke2FydGljbGUudmFsdWUuaW1nVXJsfVwiKVxcdGA7XG4gICAgcyArPSBgPUhZUEVSTElOSyhcIiR7YXJ0aWNsZS52YWx1ZS51cmx9XCI7XCIke2FydGljbGUudmFsdWUubmFtZX1cIilcXHRgO1xuICAgIHMgKz0gYCR7YXJ0aWNsZS52YWx1ZS52ZW5kb3J9XFx0YDtcbiAgICBzICs9IGAke3ByaWNlfSDigqxcXHRgO1xuICAgIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHMpO1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVEaXNjb3JkQ2xpcGJvYXJkU3RyaW5nKCkge1xuICAgIGxldCBwcmljZSA9IE1hdGgucm91bmQoKGFydGljbGUudmFsdWUucHJpY2UgPz8gMCkgKyAoYXJ0aWNsZS52YWx1ZS5mZHAgPz8gMCkpO1xuICAgIGxldCBzID0gYCoqJHthcnRpY2xlLnZhbHVlLm5hbWV9Kiogw6AgKioke3ByaWNlfeKCrCoqIHZlbmR1IHBhciAqKiR7YXJ0aWNsZS52YWx1ZS52ZW5kb3J9KiogOmA7XG4gICAgaWYgKGFydGljbGUudmFsdWUud2FybmluZylcbiAgICAgICAgcyArPSBgXFxuOndhcm5pbmc6JHthcnRpY2xlLnZhbHVlLndhcm5pbmd9Ondhcm5pbmc6YDtcbiAgICBzICs9IGBcXG4ke2FydGljbGUudmFsdWUudXJsfWA7XG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQocyk7XG59XG5mdW5jdGlvbiBnZW5lcmF0ZVR3aXRjaENsaXBib2FyZFN0cmluZygpIHtcbiAgICBsZXQgcHJpY2UgPSBNYXRoLnJvdW5kKChhcnRpY2xlLnZhbHVlLnByaWNlID8/IDApICsgKGFydGljbGUudmFsdWUuZmRwID8/IDApKTtcbiAgICBsZXQgcyA9IGAke2FydGljbGUudmFsdWUubmFtZX0gw6AgJHtwcmljZX3igqwgdmVuZHUgcGFyICR7YXJ0aWNsZS52YWx1ZS52ZW5kb3J9IDogJHthcnRpY2xlLnZhbHVlLnVybH1gO1xuICAgIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHMpO1xufVxuY29uc3QgYW5hbHl6ZVVybCA9ICgpID0+IHtcbiAgICBjaHJvbWUudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9LCBmdW5jdGlvbiAodGFicykge1xuICAgICAgICBjb25zdCB0YWIgPSB0YWJzWzBdO1xuICAgICAgICBsZXQgYztcbiAgICAgICAgT2JqZWN0LnZhbHVlcyhjdXN0b21Db25maWd1cmF0aW9ucy52YWx1ZSkuc29tZSgoY29uZmlndXJhdGlvbikgPT4ge1xuICAgICAgICAgICAgaWYgKHRhYi51cmwuaW5jbHVkZXMoY29uZmlndXJhdGlvbi51cmwgPz8gJycpKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYENvbmZpZ3VyYXRpb24gZm91bmQgOiAke2NvbmZpZ3VyYXRpb24ubmFtZX0gKCR7Y29uZmlndXJhdGlvbi51dWlkfSlgKTtcbiAgICAgICAgICAgICAgICBjaHJvbWUuc2NyaXB0aW5nXG4gICAgICAgICAgICAgICAgICAgIC5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgICAgICAgICAgICAgZnVuYzogZ2V0SW5mb3MsXG4gICAgICAgICAgICAgICAgICAgIGFyZ3M6IFtjb25maWd1cmF0aW9uLCB0YWIudXJsXSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAudGhlbigoaW5qZWN0aW9uUmVzdWx0cykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IHsgZnJhbWVJZCwgcmVzdWx0IH0gb2YgaW5qZWN0aW9uUmVzdWx0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgYXJ0aWNsZS52YWx1ZSA9IHJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9KTtcbn07XG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoZnVuY3Rpb24gKHJlcXVlc3QpIHtcbiAgICBjb25zb2xlLmxvZygncG9wdScgKyByZXF1ZXN0KTtcbn0pO1xuY29uc3QgaGFuZGxlQ2hhbmdlID0gKGV2ZW50KSA9PiB7XG4gICAgaWYgKGV2ZW50LnRhcmdldC5pZCA9PT0gJ25hbWUnKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0geyAuLi5hcnRpY2xlLnZhbHVlLCBuYW1lOiBldmVudC50YXJnZXQudmFsdWUgfTtcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAndXJsJylcbiAgICAgICAgYXJ0aWNsZS52YWx1ZSA9IHsgLi4uYXJ0aWNsZS52YWx1ZSwgdXJsOiBldmVudC50YXJnZXQudmFsdWUgfTtcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAndmVuZG9yJylcbiAgICAgICAgYXJ0aWNsZS52YWx1ZSA9IHsgLi4uYXJ0aWNsZS52YWx1ZSwgdmVuZG9yOiBldmVudC50YXJnZXQudmFsdWUgfTtcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAncHJpY2UnKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0geyAuLi5hcnRpY2xlLnZhbHVlLCBwcmljZTogTnVtYmVyKGV2ZW50LnRhcmdldC52YWx1ZSkgfTtcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAnZmRwJylcbiAgICAgICAgYXJ0aWNsZS52YWx1ZSA9IHsgLi4uYXJ0aWNsZS52YWx1ZSwgZmRwOiBOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKSB9O1xuICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICdpbWdVcmwnKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0geyAuLi5hcnRpY2xlLnZhbHVlLCBpbWdVcmw6IGV2ZW50LnRhcmdldC52YWx1ZSB9O1xuICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICd3YXJuaW5nJylcbiAgICAgICAgYXJ0aWNsZS52YWx1ZSA9IHsgLi4uYXJ0aWNsZS52YWx1ZSwgd2FybmluZzogZXZlbnQudGFyZ2V0LnZhbHVlIH07XG59O1xuY29uc3QgUG9wdXAgPSAoKSA9PiB7XG4gICAgLy8gY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0OiBjb3VudC50b1N0cmluZygpIH0pO1xuICAgIHVzZVNpZ25hbEVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuZ2V0KHtcbiAgICAgICAgICAgIGNvbmZpZ3VyYXRpb25zOiBpbml0aWFsQ29uZmlndXJhdGlvbixcbiAgICAgICAgfSwgKGl0ZW1zKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBjID0gaXRlbXMuY29uZmlndXJhdGlvbnM7XG4gICAgICAgICAgICBPYmplY3Qua2V5cyhpbml0aWFsQ29uZmlndXJhdGlvbikuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKE9iamVjdC5rZXlzKGMpLmluZGV4T2Yoa2V5KSA9PT0gLTEpIHtcbiAgICAgICAgICAgICAgICAgICAgY1trZXldID0gaW5pdGlhbENvbmZpZ3VyYXRpb25bTnVtYmVyKGtleSldO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgY3VzdG9tQ29uZmlndXJhdGlvbnMudmFsdWUgPSBjO1xuICAgICAgICAgICAgYW5hbHl6ZVVybCgpO1xuICAgICAgICB9KTtcbiAgICB9KTtcbiAgICBjb25zdCBjYXJkQ29udGVudCA9IHtcbiAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgICAnZmxleC1kaXJlY3Rpb24nOiAnY29sdW1uJyxcbiAgICAgICAgYWxpZ25JdGVtczogJ3N0cmVjaCcsXG4gICAgICAgIHJvd0dhcDogJzEwcHgnLFxuICAgICAgICBtaW5XaWR0aDogJzgwMHB4JyxcbiAgICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICB9O1xuICAgIGNvbnN0IGNhcmRBY3Rpb24gPSB7XG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICAgICAgY29sdW1uR2FwOiAnNXB4JyxcbiAgICB9O1xuICAgIGNvbnN0IGlucHV0U3R5bGUgPSB7XG4gICAgICAgIHdpZHRoOiAnMTAwJScsXG4gICAgICAgIGZsZXg6IDEsXG4gICAgfTtcbiAgICBjb25zdCBwcmljZUNvbnRhaW5lclN0eWxlID0ge1xuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgIGNvbHVtbkdhcDogJzVweCcsXG4gICAgfTtcbiAgICBjb25zdCBwcmljZUlucHV0U3R5bGUgPSB7XG4gICAgICAgIHdpZHRoOiAnODAlJyxcbiAgICB9O1xuICAgIGNvbnN0IHNlbGxlcklucHV0U3R5bGUgPSB7XG4gICAgICAgIHdpZHRoOiAnNjAlJyxcbiAgICB9O1xuICAgIGNvbnN0IGZkcElucHV0U3R5bGUgPSB7XG4gICAgICAgIHdpZHRoOiAnMjAlJyxcbiAgICB9O1xuICAgIGNvbnN0IGljb25TdHlsZSA9IHtcbiAgICAgICAgbWFyZ2luUmlnaHQ6ICcycHgnLFxuICAgIH07XG4gICAgY29uc3QgYnV0dG9uU3R5bGUgPSB7XG4gICAgICAgIGZsZXg6IDEsXG4gICAgfTtcbiAgICBjb25zdCBkaXZpZGVyU3R5bGUgPSB7XG4gICAgICAgIG1hcmdpblRvcDogJzIwcHgnLFxuICAgICAgICBtYXJnaW5Cb3R0b206ICcyMHB4JyxcbiAgICB9O1xuICAgIGNvbnN0IHByaWNlUmVwbGFjZXJTdHlsZSA9IHtcbiAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgIH07XG4gICAgY29uc3QgcHJpY2VSZXBsYWNlcklucHV0V3JhcHBlclN0eWxlID0ge1xuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICdmbGV4LWRpcmVjdGlvbic6ICdjb2x1bW4nLFxuICAgICAgICBhbGlnbkl0ZW1zOiAnc3RyZWNoJyxcbiAgICAgICAgcm93R2FwOiAnMTBweCcsXG4gICAgfTtcbiAgICBjb25zdCBwcmljZVJlcGxhY2VySW5wdXRTdHlsZSA9IHtcbiAgICAgICAgd2lkdGg6ICc1MCUnLFxuICAgIH07XG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KFJlYWN0LkZyYWdtZW50LCBudWxsLFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IGNhcmRDb250ZW50IH0sXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IGNhcmRDb250ZW50IH0sXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIHZhbHVlOiBhcnRpY2xlLnZhbHVlPy52ZW5kb3IsIGlkOiBcInZlbmRvclwiLCBsYWJlbDogXCJTZWxsZXJcIiwgZGVmYXVsdFZhbHVlOiBcIkVycm9yXCIgfSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIHZhbHVlOiBhcnRpY2xlLnZhbHVlPy51cmwsIGlkOiBcInVybFwiLCBtdWx0aWxpbmU6IHRydWUsIGxhYmVsOiBcIlVSTFwiLCBkZWZhdWx0VmFsdWU6IFwiRXJyb3JcIiB9KSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSwgdmFsdWU6IGFydGljbGUudmFsdWU/Lm5hbWUsIGlkOiBcIm5hbWVcIiwgbGFiZWw6IFwiQXJ0aWNsZVwiLCBkZWZhdWx0VmFsdWU6IFwiRXJyb3JcIiB9KSxcbiAgICAgICAgICAgICAgICAhYXJ0aWNsZS52YWx1ZT8ucHJpY2UgJiYgKFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dEZpZWxkLCB7IHN0eWxlOiBpbnB1dFN0eWxlLCB2YWx1ZTogYXJ0aWNsZS52YWx1ZT8ucHJpY2VUZXh0LCBpZDogXCJuYW1lXCIsIGxhYmVsOiBcIlByaWNlIFRleHRcIiwgZGVmYXVsdFZhbHVlOiBcIkVycm9yXCIsIGhlbHBlclRleHQ6IFwiSXNzdWUgdG8gZ2V0IGEgbnVtYmVyIGZyb20gdGhlIHByaWNlXCIgfSkpLFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBzdHlsZTogcHJpY2VDb250YWluZXJTdHlsZSB9LFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogcHJpY2VJbnB1dFN0eWxlLCBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLCB2YWx1ZTogYXJ0aWNsZS52YWx1ZT8ucHJpY2UsIGlkOiBcInByaWNlXCIsIHR5cGU6IFwibnVtYmVyXCIsIGxhYmVsOiBcIlByaWNlXCIsIGRlZmF1bHRWYWx1ZTogXCIwXCIgfSksXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dEZpZWxkLCB7IHN0eWxlOiBpbnB1dFN0eWxlLCBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLCB2YWx1ZTogYXJ0aWNsZS52YWx1ZT8uZmRwLCBpZDogXCJmZHBcIiwgdHlwZTogXCJudW1iZXJcIiwgbGFiZWw6IFwiRnJhaXMgRGUgUG9ydFwiLCBkZWZhdWx0VmFsdWU6IFwiMFwiIH0pKSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSwgdmFsdWU6IGFydGljbGUudmFsdWU/Lndhcm5pbmcsIGlkOiBcIndhcm5pbmdcIiwgbGFiZWw6IFwiV2FybmluZ1wiLCBtdWx0aWxpbmU6IHRydWUsIG1heFJvd3M6IDQsIGRlZmF1bHRWYWx1ZTogXCIgXCIgfSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIHZhbHVlOiBhcnRpY2xlLnZhbHVlPy5pbWdVcmwsIGlkOiBcImltZ1VybFwiLCBsYWJlbDogXCJJbWFnZSBVcmxcIiwgZGVmYXVsdFZhbHVlOiBcIkVycm9yXCIgfSkpLFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IHN0eWxlOiBjYXJkQWN0aW9uIH0sXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCdXR0b24sIHsgc3R5bGU6IGJ1dHRvblN0eWxlLCB2YXJpYW50OiBcImNvbnRhaW5lZFwiLCBvbkNsaWNrOiBhbmFseXplVXJsIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbiwgeyBzdHlsZTogaWNvblN0eWxlLCBpY29uOiBcImNoYXJtOnJlZnJlc2hcIiwgaGVpZ2h0OiBcIjMwXCIgfSksXG4gICAgICAgICAgICAgICAgICAgIFwiUmVmcmVzaFwiKSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgeyB2YXJpYW50OiBcImNvbnRhaW5lZFwiLCBvbkNsaWNrOiBnZW5lcmF0ZUV4Y2VsQ2xpcGJvYXJkU3RyaW5nIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbiwgeyBpY29uOiBcInNpbXBsZS1pY29uczpnb29nbGVzaGVldHNcIiwgaGVpZ2h0OiBcIjM2XCIgfSksXG4gICAgICAgICAgICAgICAgICAgIFwiU2hhcmUgb24gRXhjZWxcIiksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCdXR0b24sIHsgdmFyaWFudDogXCJjb250YWluZWRcIiwgb25DbGljazogZ2VuZXJhdGVEaXNjb3JkQ2xpcGJvYXJkU3RyaW5nIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbiwgeyBzdHlsZTogaWNvblN0eWxlLCBpY29uOiBcImljOmJhc2VsaW5lLWRpc2NvcmRcIiwgaGVpZ2h0OiBcIjMwXCIgfSksXG4gICAgICAgICAgICAgICAgICAgIFwiU2hhcmUgb24gRGlzY29yZFwiKSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgeyB2YXJpYW50OiBcImNvbnRhaW5lZFwiLCBvbkNsaWNrOiBnZW5lcmF0ZVR3aXRjaENsaXBib2FyZFN0cmluZyB9LFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEljb24sIHsgc3R5bGU6IGljb25TdHlsZSwgaWNvbjogXCJmYTYtYnJhbmRzOnR3aXRjaFwiLCBoZWlnaHQ6IFwiMzBcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgXCJTaGFyZSBPbiBUd2l0Y2hcIikpKSkpO1xufTtcbmNvbnN0IHJvb3QgPSBjcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykpO1xucm9vdC5yZW5kZXIoUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5TdHJpY3RNb2RlLCBudWxsLFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUG9wdXAsIG51bGwpKSk7XG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdGlkOiBtb2R1bGVJZCxcblx0XHRsb2FkZWQ6IGZhbHNlLFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcblx0bW9kdWxlLmxvYWRlZCA9IHRydWU7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4vLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuX193ZWJwYWNrX3JlcXVpcmVfXy5tID0gX193ZWJwYWNrX21vZHVsZXNfXztcblxuIiwidmFyIGRlZmVycmVkID0gW107XG5fX3dlYnBhY2tfcmVxdWlyZV9fLk8gPSAocmVzdWx0LCBjaHVua0lkcywgZm4sIHByaW9yaXR5KSA9PiB7XG5cdGlmKGNodW5rSWRzKSB7XG5cdFx0cHJpb3JpdHkgPSBwcmlvcml0eSB8fCAwO1xuXHRcdGZvcih2YXIgaSA9IGRlZmVycmVkLmxlbmd0aDsgaSA+IDAgJiYgZGVmZXJyZWRbaSAtIDFdWzJdID4gcHJpb3JpdHk7IGktLSkgZGVmZXJyZWRbaV0gPSBkZWZlcnJlZFtpIC0gMV07XG5cdFx0ZGVmZXJyZWRbaV0gPSBbY2h1bmtJZHMsIGZuLCBwcmlvcml0eV07XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHZhciBub3RGdWxmaWxsZWQgPSBJbmZpbml0eTtcblx0Zm9yICh2YXIgaSA9IDA7IGkgPCBkZWZlcnJlZC5sZW5ndGg7IGkrKykge1xuXHRcdHZhciBbY2h1bmtJZHMsIGZuLCBwcmlvcml0eV0gPSBkZWZlcnJlZFtpXTtcblx0XHR2YXIgZnVsZmlsbGVkID0gdHJ1ZTtcblx0XHRmb3IgKHZhciBqID0gMDsgaiA8IGNodW5rSWRzLmxlbmd0aDsgaisrKSB7XG5cdFx0XHRpZiAoKHByaW9yaXR5ICYgMSA9PT0gMCB8fCBub3RGdWxmaWxsZWQgPj0gcHJpb3JpdHkpICYmIE9iamVjdC5rZXlzKF9fd2VicGFja19yZXF1aXJlX18uTykuZXZlcnkoKGtleSkgPT4gKF9fd2VicGFja19yZXF1aXJlX18uT1trZXldKGNodW5rSWRzW2pdKSkpKSB7XG5cdFx0XHRcdGNodW5rSWRzLnNwbGljZShqLS0sIDEpO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0ZnVsZmlsbGVkID0gZmFsc2U7XG5cdFx0XHRcdGlmKHByaW9yaXR5IDwgbm90RnVsZmlsbGVkKSBub3RGdWxmaWxsZWQgPSBwcmlvcml0eTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYoZnVsZmlsbGVkKSB7XG5cdFx0XHRkZWZlcnJlZC5zcGxpY2UoaS0tLCAxKVxuXHRcdFx0dmFyIHIgPSBmbigpO1xuXHRcdFx0aWYgKHIgIT09IHVuZGVmaW5lZCkgcmVzdWx0ID0gcjtcblx0XHR9XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn07IiwiLy8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbl9fd2VicGFja19yZXF1aXJlX18ubiA9IChtb2R1bGUpID0+IHtcblx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG5cdFx0KCkgPT4gKG1vZHVsZVsnZGVmYXVsdCddKSA6XG5cdFx0KCkgPT4gKG1vZHVsZSk7XG5cdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsIHsgYTogZ2V0dGVyIH0pO1xuXHRyZXR1cm4gZ2V0dGVyO1xufTsiLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLmcgPSAoZnVuY3Rpb24oKSB7XG5cdGlmICh0eXBlb2YgZ2xvYmFsVGhpcyA9PT0gJ29iamVjdCcpIHJldHVybiBnbG9iYWxUaGlzO1xuXHR0cnkge1xuXHRcdHJldHVybiB0aGlzIHx8IG5ldyBGdW5jdGlvbigncmV0dXJuIHRoaXMnKSgpO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0aWYgKHR5cGVvZiB3aW5kb3cgPT09ICdvYmplY3QnKSByZXR1cm4gd2luZG93O1xuXHR9XG59KSgpOyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm5tZCA9IChtb2R1bGUpID0+IHtcblx0bW9kdWxlLnBhdGhzID0gW107XG5cdGlmICghbW9kdWxlLmNoaWxkcmVuKSBtb2R1bGUuY2hpbGRyZW4gPSBbXTtcblx0cmV0dXJuIG1vZHVsZTtcbn07IiwiLy8gbm8gYmFzZVVSSVxuXG4vLyBvYmplY3QgdG8gc3RvcmUgbG9hZGVkIGFuZCBsb2FkaW5nIGNodW5rc1xuLy8gdW5kZWZpbmVkID0gY2h1bmsgbm90IGxvYWRlZCwgbnVsbCA9IGNodW5rIHByZWxvYWRlZC9wcmVmZXRjaGVkXG4vLyBbcmVzb2x2ZSwgcmVqZWN0LCBQcm9taXNlXSA9IGNodW5rIGxvYWRpbmcsIDAgPSBjaHVuayBsb2FkZWRcbnZhciBpbnN0YWxsZWRDaHVua3MgPSB7XG5cdFwicG9wdXBcIjogMFxufTtcblxuLy8gbm8gY2h1bmsgb24gZGVtYW5kIGxvYWRpbmdcblxuLy8gbm8gcHJlZmV0Y2hpbmdcblxuLy8gbm8gcHJlbG9hZGVkXG5cbi8vIG5vIEhNUlxuXG4vLyBubyBITVIgbWFuaWZlc3RcblxuX193ZWJwYWNrX3JlcXVpcmVfXy5PLmogPSAoY2h1bmtJZCkgPT4gKGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9PT0gMCk7XG5cbi8vIGluc3RhbGwgYSBKU09OUCBjYWxsYmFjayBmb3IgY2h1bmsgbG9hZGluZ1xudmFyIHdlYnBhY2tKc29ucENhbGxiYWNrID0gKHBhcmVudENodW5rTG9hZGluZ0Z1bmN0aW9uLCBkYXRhKSA9PiB7XG5cdHZhciBbY2h1bmtJZHMsIG1vcmVNb2R1bGVzLCBydW50aW1lXSA9IGRhdGE7XG5cdC8vIGFkZCBcIm1vcmVNb2R1bGVzXCIgdG8gdGhlIG1vZHVsZXMgb2JqZWN0LFxuXHQvLyB0aGVuIGZsYWcgYWxsIFwiY2h1bmtJZHNcIiBhcyBsb2FkZWQgYW5kIGZpcmUgY2FsbGJhY2tcblx0dmFyIG1vZHVsZUlkLCBjaHVua0lkLCBpID0gMDtcblx0aWYoY2h1bmtJZHMuc29tZSgoaWQpID0+IChpbnN0YWxsZWRDaHVua3NbaWRdICE9PSAwKSkpIHtcblx0XHRmb3IobW9kdWxlSWQgaW4gbW9yZU1vZHVsZXMpIHtcblx0XHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhtb3JlTW9kdWxlcywgbW9kdWxlSWQpKSB7XG5cdFx0XHRcdF9fd2VicGFja19yZXF1aXJlX18ubVttb2R1bGVJZF0gPSBtb3JlTW9kdWxlc1ttb2R1bGVJZF07XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmKHJ1bnRpbWUpIHZhciByZXN1bHQgPSBydW50aW1lKF9fd2VicGFja19yZXF1aXJlX18pO1xuXHR9XG5cdGlmKHBhcmVudENodW5rTG9hZGluZ0Z1bmN0aW9uKSBwYXJlbnRDaHVua0xvYWRpbmdGdW5jdGlvbihkYXRhKTtcblx0Zm9yKDtpIDwgY2h1bmtJZHMubGVuZ3RoOyBpKyspIHtcblx0XHRjaHVua0lkID0gY2h1bmtJZHNbaV07XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGluc3RhbGxlZENodW5rcywgY2h1bmtJZCkgJiYgaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdKSB7XG5cdFx0XHRpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF1bMF0oKTtcblx0XHR9XG5cdFx0aW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdID0gMDtcblx0fVxuXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXy5PKHJlc3VsdCk7XG59XG5cbnZhciBjaHVua0xvYWRpbmdHbG9iYWwgPSBzZWxmW1wid2VicGFja0NodW5rZGVhbF9zbmlmZmVyXCJdID0gc2VsZltcIndlYnBhY2tDaHVua2RlYWxfc25pZmZlclwiXSB8fCBbXTtcbmNodW5rTG9hZGluZ0dsb2JhbC5mb3JFYWNoKHdlYnBhY2tKc29ucENhbGxiYWNrLmJpbmQobnVsbCwgMCkpO1xuY2h1bmtMb2FkaW5nR2xvYmFsLnB1c2ggPSB3ZWJwYWNrSnNvbnBDYWxsYmFjay5iaW5kKG51bGwsIGNodW5rTG9hZGluZ0dsb2JhbC5wdXNoLmJpbmQoY2h1bmtMb2FkaW5nR2xvYmFsKSk7IiwiIiwiLy8gc3RhcnR1cFxuLy8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4vLyBUaGlzIGVudHJ5IG1vZHVsZSBkZXBlbmRzIG9uIG90aGVyIGxvYWRlZCBjaHVua3MgYW5kIGV4ZWN1dGlvbiBuZWVkIHRvIGJlIGRlbGF5ZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXy5PKHVuZGVmaW5lZCwgW1widmVuZG9yXCJdLCAoKSA9PiAoX193ZWJwYWNrX3JlcXVpcmVfXyhcIi4vc3JjL3BvcHVwLnRzeFwiKSkpXG5fX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXy5PKF9fd2VicGFja19leHBvcnRzX18pO1xuIiwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9