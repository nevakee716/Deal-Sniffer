/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/get-infos.tsx":
/*!***************************!*\
  !*** ./src/get-infos.tsx ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const getInfos = (url) => {
    var _a, _b;
    function getAmazonInfo() {
        var _a, _b, _c, _d, _e, _f;
        const a = {};
        a.name = (_b = (_a = document.getElementById('productTitle')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = Number((_d = (_c = document
            .querySelector('#corePrice_feature_div .a-price-whole')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) === null || _d === void 0 ? void 0 : _d.replace(',', '.'));
        a.imgUrl =
            (_f = (_e = document.querySelector('#imgTagWrapperId img')) === null || _e === void 0 ? void 0 : _e.getAttribute('src')) !== null && _f !== void 0 ? _f : 'Not Found';
        return a;
    }
    function getPcComponentesInfo() {
        var _a, _b, _c, _d, _e, _f;
        const a = {};
        a.name = (_b = (_a = document.getElementById('pdp-title')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = Number((_d = (_c = document
            .getElementById('pdp-price-current-integer')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) === null || _d === void 0 ? void 0 : _d.replace(',', '.'));
        a.imgUrl =
            (_f = (_e = document.querySelector('#pdp-section-images img')) === null || _e === void 0 ? void 0 : _e.getAttribute('src')) !== null && _f !== void 0 ? _f : 'Not Found';
        return a;
    }
    function getCdiscountInfo() {
        var _a, _b, _c, _d, _e, _f;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.fpTMain .fpDesCol h1')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = Number((_d = (_c = document
            .querySelector('.fTopPrice  .fpPrice')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) === null || _d === void 0 ? void 0 : _d.replace(',', '.'));
        a.imgUrl =
            (_f = (_e = document
                .querySelector('#fpZnPrdMain img#picture0')) === null || _e === void 0 ? void 0 : _e.getAttribute('src')) !== null && _f !== void 0 ? _f : 'Not Found';
        return a;
    }
    function getGrosBillInfo() {
        var _a, _b, _c, _d, _e, _f;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.grb_fch-prod__content-title .grb_fch-prod__title')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = Number((_d = (_c = document
            .querySelector('.fiche-produit-r  .fiche_product_price > span')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) === null || _d === void 0 ? void 0 : _d.replace('€', '').replace(',', '.'));
        a.imgUrl =
            (_f = 'https://www.grosbill.com' +
                ((_e = document
                    .querySelector('#product_buy [data-swiper-slide-index="0"] img')) === null || _e === void 0 ? void 0 : _e.getAttribute('src'))) !== null && _f !== void 0 ? _f : 'Not Found';
        return a;
    }
    function getCybertekInfo() {
        var _a, _b, _c, _d, _e, _f;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.fiche-produit__bloc-achat__container .title_fiche')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = Number((_d = (_c = document
            .querySelector('.fiche-produit__bloc-achat__prix  .fiche_product_price > span')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) === null || _d === void 0 ? void 0 : _d.replace('€', '').replace(',', '.'));
        a.imgUrl =
            (_f = (_e = document
                .querySelector('#fiche-produit__container-photos [data-swiper-slide-index="0"] img')) === null || _e === void 0 ? void 0 : _e.getAttribute('src')) !== null && _f !== void 0 ? _f : 'Not Found';
        return a;
    }
    function getTopAchatInfo() {
        var _a, _b, _c, _d, _e, _f;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.ps-main__product-title')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = Number((_d = (_c = document
            .querySelector('.ps-main__offer  .offer-price__price')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) === null || _d === void 0 ? void 0 : _d.replace(' €', '').replace(',', '.'));
        a.imgUrl =
            (_f = (_e = document
                .querySelector('.product-main-image.ps-main__main-image img')) === null || _e === void 0 ? void 0 : _e.getAttribute('src')) !== null && _f !== void 0 ? _f : 'Not Found';
        return a;
    }
    function getInfoDiscountInfo() {
        var _a, _b, _c, _d, _e;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.product-sheet_title')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = Number((_c = document.querySelector('.product-sheet_buybox .product-sheet_buybox_offer_price').innerText) === null || _c === void 0 ? void 0 : _c.replace('\n', '').replace(' €', '').replace(',', '.'));
        a.imgUrl =
            (_e = 'https://www.1fodiscount.com/' +
                ((_d = document
                    .querySelector('.product-sheet_slideshow_scrollable img.product-sheet_slideshow_slide_img')) === null || _d === void 0 ? void 0 : _d.getAttribute('src'))) !== null && _e !== void 0 ? _e : 'Not Found';
        return a;
    }
    function getReicheltInfo() {
        var _a, _b, _c, _d, _e;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.av_articleheader [itemprop="name"]')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = Number((_c = document.querySelector('#av_price').innerText) === null || _c === void 0 ? void 0 : _c.replace(',', '.'));
        a.imgUrl =
            (_e = (_d = document.querySelector('#gallery img')) === null || _d === void 0 ? void 0 : _d.getAttribute('src')) !== null && _e !== void 0 ? _e : 'Not Found';
        return a;
    }
    function getBPMPowerInfo() {
        var _a, _b, _c, _d;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.titleText h1')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = Number(document.querySelector('#divProductInfoAndHelp .prezzoScheda').innerText
            .replace(' € ', '')
            .replace(',', '.'));
        a.imgUrl =
            (_d = (_c = document.querySelector('#mainImageDiv img')) === null || _c === void 0 ? void 0 : _c.getAttribute('src')) !== null && _d !== void 0 ? _d : 'Not Found';
        return a;
    }
    function getRDCInfo() {
        var _a, _b, _c, _d;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.product-name span')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = Number(document.querySelector('.product__price .dyn_prod_price').innerText
            .replace(' € ', '')
            .replace(',', '.'));
        a.imgUrl =
            (_d = 'https://www.rueducommerce.fr' +
                ((_c = document.querySelector('#gallery .owl-item img')) === null || _c === void 0 ? void 0 : _c.getAttribute('src'))) !== null && _d !== void 0 ? _d : 'Not Found';
        return a;
    }
    let a = {};
    if (url.includes('pccomponentes.fr')) {
        a = getPcComponentesInfo();
        a.vendor = 'PC Componentes';
    }
    else if (url.includes('pccomponentes.com')) {
        a = getPcComponentesInfo();
        a.vendor = 'PC Componentes ES';
    }
    else if (url.includes('amazon.fr')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon FR';
    }
    else if (url.includes('amazon.de')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon DE';
    }
    else if (url.includes('amazon.it')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon IT';
    }
    else if (url.includes('amazon.es')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon ES';
    }
    else if (url.includes('cdiscount.com')) {
        a = getCdiscountInfo();
        a.vendor = 'CDiscount';
    }
    else if (url.includes('grosbill.com')) {
        a = getGrosBillInfo();
        a.vendor = 'GrosBill';
    }
    else if (url.includes('cybertek.fr')) {
        a = getCybertekInfo();
        a.vendor = 'Cybertek';
    }
    else if (url.includes('topachat.com')) {
        a = getTopAchatInfo();
        a.vendor = 'TopAchat';
    }
    else if (url.includes('1fodiscount.com')) {
        a = getInfoDiscountInfo();
        a.vendor = '1foDiscount';
    }
    else if (url.includes('reichelt.com')) {
        a = getReicheltInfo();
        a.vendor = 'Reichelt';
    }
    else if (url.includes('bpm-power.com')) {
        a = getBPMPowerInfo();
        a.vendor = 'BPM-Power';
        a.warning = "Bien Vérifier sous 5j qu'il n'y a pas de dégat sur le colis";
    }
    else if (url.includes('rueducommerce.fr')) {
        a = getRDCInfo();
        a.vendor = 'Rue du Commerce';
    }
    let selection = (_a = window === null || window === void 0 ? void 0 : window.getSelection()) === null || _a === void 0 ? void 0 : _a.toString();
    a.name = selection != '' ? selection : (_b = a === null || a === void 0 ? void 0 : a.name) === null || _b === void 0 ? void 0 : _b.replace('"', '');
    return a;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getInfos);


/***/ }),

/***/ "./src/popup.tsx":
/*!***********************!*\
  !*** ./src/popup.tsx ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom/client */ "./node_modules/react-dom/client.js");
/* harmony import */ var _preact_signals_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @preact/signals-react */ "./node_modules/@preact/signals-react/dist/signals.module.js");
/* harmony import */ var _get_infos__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./get-infos */ "./src/get-infos.tsx");
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material/Button */ "./node_modules/@mui/material/Button/Button.js");
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/material/TextField */ "./node_modules/@mui/material/TextField/TextField.js");
/* harmony import */ var _iconify_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @iconify/react */ "./node_modules/@iconify/react/dist/iconify.mjs");







const seller = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)('');
const article = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)({});
function generateExcelClipboardString() {
    var _a, _b;
    let price = Math.round(((_a = article.value.price) !== null && _a !== void 0 ? _a : 0) + ((_b = article.value.fdp) !== null && _b !== void 0 ? _b : 0));
    let s = `=IMAGE("${article.value.imgUrl}")\t`;
    s += `=HYPERLINK("${article.value.url}";"${article.value.name}")\t`;
    s += `${article.value.vendor}\t`;
    s += `${price} €\t`;
    navigator.clipboard.writeText(s);
}
function generateDiscordClipboardString() {
    var _a, _b;
    let price = Math.round(((_a = article.value.price) !== null && _a !== void 0 ? _a : 0) + ((_b = article.value.fdp) !== null && _b !== void 0 ? _b : 0));
    let s = `**${article.value.name}** à **${price}€** vendu par **${article.value.vendor}** :`;
    if (article.value.warning)
        s += `\n:warning:${article.value.warning}:warning:`;
    s += `\n${article.value.url}`;
    navigator.clipboard.writeText(s);
}
const analyzeUrl = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const tab = tabs[0];
        chrome.scripting
            .executeScript({
            target: { tabId: tab.id },
            func: _get_infos__WEBPACK_IMPORTED_MODULE_3__["default"],
            args: [tab.url],
        })
            .then((injectionResults) => {
            for (const { frameId, result } of injectionResults) {
                article.value = result;
                article.value.url = tab.url;
            }
        });
    });
};
chrome.runtime.onMessage.addListener(function (request) {
    console.log('popu' + request);
});
const cardContent = {
    display: 'flex',
    'flex-direction': 'column',
    alignItems: 'strech',
    rowGap: '10px',
    minWidth: '800px',
};
const cardAction = {
    display: 'flex',
    columnGap: '5px',
};
const inputStyle = {
    width: '100%',
};
const priceContainerStyle = {
    display: 'flex',
    columnGap: '5px',
};
const priceInputStyle = {
    width: '80%',
};
const fdpInputStyle = {
    width: '20%',
};
const iconStyle = {
    marginRight: '2px',
};
const handleChange = (event) => {
    if (event.target.id === 'name')
        article.value = Object.assign(Object.assign({}, article.value), { name: event.target.value });
    if (event.target.id === 'url')
        article.value = Object.assign(Object.assign({}, article.value), { url: event.target.value });
    if (event.target.id === 'vendor')
        article.value = Object.assign(Object.assign({}, article.value), { vendor: event.target.value });
    if (event.target.id === 'price')
        article.value = Object.assign(Object.assign({}, article.value), { price: Number(event.target.value) });
    if (event.target.id === 'fdp')
        article.value = Object.assign(Object.assign({}, article.value), { fdp: Number(event.target.value) });
    if (event.target.id === 'imgUrl')
        article.value = Object.assign(Object.assign({}, article.value), { imgUrl: event.target.value });
    if (event.target.id === 'warning')
        article.value = Object.assign(Object.assign({}, article.value), { warning: event.target.value });
};
const Popup = () => {
    // chrome.action.setBadgeText({ text: count.toString() });
    (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.useSignalEffect)(analyzeUrl);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardContent },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardContent },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: inputStyle, onChange: handleChange, value: article.value.url, id: "url", multiline: true, label: "URL", defaultValue: "Error" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: inputStyle, onChange: handleChange, value: article.value.vendor, id: "vendor", label: "Seller", defaultValue: "Error" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: inputStyle, onChange: handleChange, value: article.value.name, id: "name", label: "Article", defaultValue: "Error" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: priceContainerStyle },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: priceInputStyle, onChange: handleChange, value: article.value.price, id: "price", type: "number", label: "Price", defaultValue: "404" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: fdpInputStyle, onChange: handleChange, value: article.value.fdp, id: "fdp", type: "number", label: "Frais De Port", defaultValue: "0" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: inputStyle, onChange: handleChange, value: article.value.warning, id: "warning", label: "Warning", multiline: true, maxRows: 4, defaultValue: " " }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__["default"], { style: inputStyle, onChange: handleChange, value: article.value.imgUrl, id: "imgUrl", label: "Image Url", defaultValue: "Error" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardAction },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_6__["default"], { variant: "contained", onClick: analyzeUrl },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_4__.Icon, { style: iconStyle, icon: "charm:refresh", height: "30" }),
                    "Refresh"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_6__["default"], { variant: "contained", onClick: generateExcelClipboardString },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_4__.Icon, { icon: "simple-icons:googlesheets", height: "36" }),
                    "Generate Excel String"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_6__["default"], { variant: "contained", onClick: generateDiscordClipboardString },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_4__.Icon, { style: iconStyle, icon: "ic:baseline-discord", height: "30" }),
                    "Generate Discord String")))));
};
const root = (0,react_dom_client__WEBPACK_IMPORTED_MODULE_1__.createRoot)(document.getElementById('root'));
root.render(react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().StrictMode), null,
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Popup, null)));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"popup": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkDeal_Sniffer"] = self["webpackChunkDeal_Sniffer"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__("./src/popup.tsx")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpRUFBZSxRQUFRLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcExFO0FBQ29CO0FBQ2tCO0FBQzdCO0FBQ087QUFDTTtBQUNWO0FBQ3RDLGVBQWUsNkRBQU07QUFDckIsZ0JBQWdCLDZEQUFNLEdBQUc7QUFDekI7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLHFCQUFxQjtBQUM1Qyx3QkFBd0Isa0JBQWtCLEVBQUUsR0FBRyxtQkFBbUI7QUFDbEUsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxPQUFPO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsbUJBQW1CLFNBQVMsTUFBTSxrQkFBa0IscUJBQXFCO0FBQzFGO0FBQ0EsMkJBQTJCLHNCQUFzQjtBQUNqRCxjQUFjLGtCQUFrQjtBQUNoQztBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsbUNBQW1DO0FBQzNEO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixlQUFlO0FBQ3JDLGtCQUFrQixrREFBUTtBQUMxQjtBQUNBLFNBQVM7QUFDVDtBQUNBLHlCQUF5QixrQkFBa0I7QUFDM0M7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNEQUFzRCxvQkFBb0IsMEJBQTBCO0FBQ3BHO0FBQ0Esc0RBQXNELG9CQUFvQix5QkFBeUI7QUFDbkc7QUFDQSxzREFBc0Qsb0JBQW9CLDRCQUE0QjtBQUN0RztBQUNBLHNEQUFzRCxvQkFBb0IsbUNBQW1DO0FBQzdHO0FBQ0Esc0RBQXNELG9CQUFvQixpQ0FBaUM7QUFDM0c7QUFDQSxzREFBc0Qsb0JBQW9CLDRCQUE0QjtBQUN0RztBQUNBLHNEQUFzRCxvQkFBb0IsNkJBQTZCO0FBQ3ZHO0FBQ0E7QUFDQSxvQ0FBb0Msd0JBQXdCO0FBQzVELElBQUksc0VBQWU7QUFDbkIsWUFBWSwwREFBbUIsQ0FBQyx1REFBYztBQUM5QyxRQUFRLDBEQUFtQixVQUFVLG9CQUFvQjtBQUN6RCxZQUFZLDBEQUFtQixVQUFVLG9CQUFvQjtBQUM3RCxnQkFBZ0IsMERBQW1CLENBQUMsK0RBQVMsSUFBSSxzSUFBc0k7QUFDdkwsZ0JBQWdCLDBEQUFtQixDQUFDLCtEQUFTLElBQUksOEhBQThIO0FBQy9LLGdCQUFnQiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLDJIQUEySDtBQUM1SyxnQkFBZ0IsMERBQW1CLFVBQVUsNEJBQTRCO0FBQ3pFLG9CQUFvQiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLDhJQUE4STtBQUNuTSxvQkFBb0IsMERBQW1CLENBQUMsK0RBQVMsSUFBSSw4SUFBOEk7QUFDbk0sZ0JBQWdCLDBEQUFtQixDQUFDLCtEQUFTLElBQUksMEpBQTBKO0FBQzNNLGdCQUFnQiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLGlJQUFpSTtBQUNsTCxZQUFZLDBEQUFtQixVQUFVLG1CQUFtQjtBQUM1RCxnQkFBZ0IsMERBQW1CLENBQUMsNERBQU0sSUFBSSwyQ0FBMkM7QUFDekYsb0JBQW9CLDBEQUFtQixDQUFDLGdEQUFJLElBQUksdURBQXVEO0FBQ3ZHO0FBQ0EsZ0JBQWdCLDBEQUFtQixDQUFDLDREQUFNLElBQUksNkRBQTZEO0FBQzNHLG9CQUFvQiwwREFBbUIsQ0FBQyxnREFBSSxJQUFJLGlEQUFpRDtBQUNqRztBQUNBLGdCQUFnQiwwREFBbUIsQ0FBQyw0REFBTSxJQUFJLCtEQUErRDtBQUM3RyxvQkFBb0IsMERBQW1CLENBQUMsZ0RBQUksSUFBSSw2REFBNkQ7QUFDN0c7QUFDQTtBQUNBLGFBQWEsNERBQVU7QUFDdkIsWUFBWSwwREFBbUIsQ0FBQyx5REFBZ0I7QUFDaEQsSUFBSSwwREFBbUI7Ozs7Ozs7VUNySHZCO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOzs7OztXQzVCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLCtCQUErQix3Q0FBd0M7V0FDdkU7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQkFBaUIscUJBQXFCO1dBQ3RDO1dBQ0E7V0FDQSxrQkFBa0IscUJBQXFCO1dBQ3ZDO1dBQ0E7V0FDQSxLQUFLO1dBQ0w7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOzs7OztXQzNCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsaUNBQWlDLFdBQVc7V0FDNUM7V0FDQTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsR0FBRztXQUNIO1dBQ0E7V0FDQSxDQUFDOzs7OztXQ1BEOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7V0NOQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOzs7OztXQ0pBOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxNQUFNLHFCQUFxQjtXQUMzQjtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBO1dBQ0E7V0FDQTs7Ozs7VUVoREE7VUFDQTtVQUNBO1VBQ0E7VUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL0RlYWwgU25pZmZlci8uL3NyYy9nZXQtaW5mb3MudHN4Iiwid2VicGFjazovL0RlYWwgU25pZmZlci8uL3NyYy9wb3B1cC50c3giLCJ3ZWJwYWNrOi8vRGVhbCBTbmlmZmVyL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY2h1bmsgbG9hZGVkIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly9EZWFsIFNuaWZmZXIvd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvZ2xvYmFsIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbm9kZSBtb2R1bGUgZGVjb3JhdG9yIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvanNvbnAgY2h1bmsgbG9hZGluZyIsIndlYnBhY2s6Ly9EZWFsIFNuaWZmZXIvd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly9EZWFsIFNuaWZmZXIvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgZ2V0SW5mb3MgPSAodXJsKSA9PiB7XG4gICAgdmFyIF9hLCBfYjtcbiAgICBmdW5jdGlvbiBnZXRBbWF6b25JbmZvKCkge1xuICAgICAgICB2YXIgX2EsIF9iLCBfYywgX2QsIF9lLCBfZjtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPSAoX2IgPSAoX2EgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncHJvZHVjdFRpdGxlJykpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pbm5lclRleHQpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICdOb3QgRm91bmQnO1xuICAgICAgICBhLnByaWNlID0gTnVtYmVyKChfZCA9IChfYyA9IGRvY3VtZW50XG4gICAgICAgICAgICAucXVlcnlTZWxlY3RvcignI2NvcmVQcmljZV9mZWF0dXJlX2RpdiAuYS1wcmljZS13aG9sZScpKSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2MuY2hpbGROb2Rlc1swXS5ub2RlVmFsdWUpID09PSBudWxsIHx8IF9kID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZC5yZXBsYWNlKCcsJywgJy4nKSk7XG4gICAgICAgIGEuaW1nVXJsID1cbiAgICAgICAgICAgIChfZiA9IChfZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNpbWdUYWdXcmFwcGVySWQgaW1nJykpID09PSBudWxsIHx8IF9lID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZS5nZXRBdHRyaWJ1dGUoJ3NyYycpKSAhPT0gbnVsbCAmJiBfZiAhPT0gdm9pZCAwID8gX2YgOiAnTm90IEZvdW5kJztcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldFBjQ29tcG9uZW50ZXNJbmZvKCkge1xuICAgICAgICB2YXIgX2EsIF9iLCBfYywgX2QsIF9lLCBfZjtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPSAoX2IgPSAoX2EgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncGRwLXRpdGxlJykpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pbm5lclRleHQpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICdOb3QgRm91bmQnO1xuICAgICAgICBhLnByaWNlID0gTnVtYmVyKChfZCA9IChfYyA9IGRvY3VtZW50XG4gICAgICAgICAgICAuZ2V0RWxlbWVudEJ5SWQoJ3BkcC1wcmljZS1jdXJyZW50LWludGVnZXInKSkgPT09IG51bGwgfHwgX2MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jLmNoaWxkTm9kZXNbMF0ubm9kZVZhbHVlKSA9PT0gbnVsbCB8fCBfZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2QucmVwbGFjZSgnLCcsICcuJykpO1xuICAgICAgICBhLmltZ1VybCA9XG4gICAgICAgICAgICAoX2YgPSAoX2UgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjcGRwLXNlY3Rpb24taW1hZ2VzIGltZycpKSA9PT0gbnVsbCB8fCBfZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2UuZ2V0QXR0cmlidXRlKCdzcmMnKSkgIT09IG51bGwgJiYgX2YgIT09IHZvaWQgMCA/IF9mIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIHJldHVybiBhO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRDZGlzY291bnRJbmZvKCkge1xuICAgICAgICB2YXIgX2EsIF9iLCBfYywgX2QsIF9lLCBfZjtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPVxuICAgICAgICAgICAgKF9iID0gKF9hID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmZwVE1haW4gLmZwRGVzQ29sIGgxJykpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pbm5lclRleHQpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICdOb3QgRm91bmQnO1xuICAgICAgICBhLnByaWNlID0gTnVtYmVyKChfZCA9IChfYyA9IGRvY3VtZW50XG4gICAgICAgICAgICAucXVlcnlTZWxlY3RvcignLmZUb3BQcmljZSAgLmZwUHJpY2UnKSkgPT09IG51bGwgfHwgX2MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jLmNoaWxkTm9kZXNbMF0ubm9kZVZhbHVlKSA9PT0gbnVsbCB8fCBfZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2QucmVwbGFjZSgnLCcsICcuJykpO1xuICAgICAgICBhLmltZ1VybCA9XG4gICAgICAgICAgICAoX2YgPSAoX2UgPSBkb2N1bWVudFxuICAgICAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcjZnBablByZE1haW4gaW1nI3BpY3R1cmUwJykpID09PSBudWxsIHx8IF9lID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZS5nZXRBdHRyaWJ1dGUoJ3NyYycpKSAhPT0gbnVsbCAmJiBfZiAhPT0gdm9pZCAwID8gX2YgOiAnTm90IEZvdW5kJztcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldEdyb3NCaWxsSW5mbygpIHtcbiAgICAgICAgdmFyIF9hLCBfYiwgX2MsIF9kLCBfZSwgX2Y7XG4gICAgICAgIGNvbnN0IGEgPSB7fTtcbiAgICAgICAgYS5uYW1lID1cbiAgICAgICAgICAgIChfYiA9IChfYSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5ncmJfZmNoLXByb2RfX2NvbnRlbnQtdGl0bGUgLmdyYl9mY2gtcHJvZF9fdGl0bGUnKSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmlubmVyVGV4dCkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIGEucHJpY2UgPSBOdW1iZXIoKF9kID0gKF9jID0gZG9jdW1lbnRcbiAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcuZmljaGUtcHJvZHVpdC1yICAuZmljaGVfcHJvZHVjdF9wcmljZSA+IHNwYW4nKSkgPT09IG51bGwgfHwgX2MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jLmNoaWxkTm9kZXNbMF0ubm9kZVZhbHVlKSA9PT0gbnVsbCB8fCBfZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2QucmVwbGFjZSgn4oKsJywgJycpLnJlcGxhY2UoJywnLCAnLicpKTtcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgKF9mID0gJ2h0dHBzOi8vd3d3Lmdyb3NiaWxsLmNvbScgK1xuICAgICAgICAgICAgICAgICgoX2UgPSBkb2N1bWVudFxuICAgICAgICAgICAgICAgICAgICAucXVlcnlTZWxlY3RvcignI3Byb2R1Y3RfYnV5IFtkYXRhLXN3aXBlci1zbGlkZS1pbmRleD1cIjBcIl0gaW1nJykpID09PSBudWxsIHx8IF9lID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZS5nZXRBdHRyaWJ1dGUoJ3NyYycpKSkgIT09IG51bGwgJiYgX2YgIT09IHZvaWQgMCA/IF9mIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIHJldHVybiBhO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRDeWJlcnRla0luZm8oKSB7XG4gICAgICAgIHZhciBfYSwgX2IsIF9jLCBfZCwgX2UsIF9mO1xuICAgICAgICBjb25zdCBhID0ge307XG4gICAgICAgIGEubmFtZSA9XG4gICAgICAgICAgICAoX2IgPSAoX2EgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZmljaGUtcHJvZHVpdF9fYmxvYy1hY2hhdF9fY29udGFpbmVyIC50aXRsZV9maWNoZScpKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuaW5uZXJUZXh0KSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiAnTm90IEZvdW5kJztcbiAgICAgICAgYS5wcmljZSA9IE51bWJlcigoX2QgPSAoX2MgPSBkb2N1bWVudFxuICAgICAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoJy5maWNoZS1wcm9kdWl0X19ibG9jLWFjaGF0X19wcml4ICAuZmljaGVfcHJvZHVjdF9wcmljZSA+IHNwYW4nKSkgPT09IG51bGwgfHwgX2MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jLmNoaWxkTm9kZXNbMF0ubm9kZVZhbHVlKSA9PT0gbnVsbCB8fCBfZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2QucmVwbGFjZSgn4oKsJywgJycpLnJlcGxhY2UoJywnLCAnLicpKTtcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgKF9mID0gKF9lID0gZG9jdW1lbnRcbiAgICAgICAgICAgICAgICAucXVlcnlTZWxlY3RvcignI2ZpY2hlLXByb2R1aXRfX2NvbnRhaW5lci1waG90b3MgW2RhdGEtc3dpcGVyLXNsaWRlLWluZGV4PVwiMFwiXSBpbWcnKSkgPT09IG51bGwgfHwgX2UgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9lLmdldEF0dHJpYnV0ZSgnc3JjJykpICE9PSBudWxsICYmIF9mICE9PSB2b2lkIDAgPyBfZiA6ICdOb3QgRm91bmQnO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0VG9wQWNoYXRJbmZvKCkge1xuICAgICAgICB2YXIgX2EsIF9iLCBfYywgX2QsIF9lLCBfZjtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPVxuICAgICAgICAgICAgKF9iID0gKF9hID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLnBzLW1haW5fX3Byb2R1Y3QtdGl0bGUnKSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmlubmVyVGV4dCkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIGEucHJpY2UgPSBOdW1iZXIoKF9kID0gKF9jID0gZG9jdW1lbnRcbiAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcucHMtbWFpbl9fb2ZmZXIgIC5vZmZlci1wcmljZV9fcHJpY2UnKSkgPT09IG51bGwgfHwgX2MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jLmNoaWxkTm9kZXNbMF0ubm9kZVZhbHVlKSA9PT0gbnVsbCB8fCBfZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2QucmVwbGFjZSgnwqDigqwnLCAnJykucmVwbGFjZSgnLCcsICcuJykpO1xuICAgICAgICBhLmltZ1VybCA9XG4gICAgICAgICAgICAoX2YgPSAoX2UgPSBkb2N1bWVudFxuICAgICAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcucHJvZHVjdC1tYWluLWltYWdlLnBzLW1haW5fX21haW4taW1hZ2UgaW1nJykpID09PSBudWxsIHx8IF9lID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZS5nZXRBdHRyaWJ1dGUoJ3NyYycpKSAhPT0gbnVsbCAmJiBfZiAhPT0gdm9pZCAwID8gX2YgOiAnTm90IEZvdW5kJztcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldEluZm9EaXNjb3VudEluZm8oKSB7XG4gICAgICAgIHZhciBfYSwgX2IsIF9jLCBfZCwgX2U7XG4gICAgICAgIGNvbnN0IGEgPSB7fTtcbiAgICAgICAgYS5uYW1lID1cbiAgICAgICAgICAgIChfYiA9IChfYSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5wcm9kdWN0LXNoZWV0X3RpdGxlJykpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pbm5lclRleHQpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICdOb3QgRm91bmQnO1xuICAgICAgICBhLnByaWNlID0gTnVtYmVyKChfYyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5wcm9kdWN0LXNoZWV0X2J1eWJveCAucHJvZHVjdC1zaGVldF9idXlib3hfb2ZmZXJfcHJpY2UnKS5pbm5lclRleHQpID09PSBudWxsIHx8IF9jID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYy5yZXBsYWNlKCdcXG4nLCAnJykucmVwbGFjZSgnIOKCrCcsICcnKS5yZXBsYWNlKCcsJywgJy4nKSk7XG4gICAgICAgIGEuaW1nVXJsID1cbiAgICAgICAgICAgIChfZSA9ICdodHRwczovL3d3dy4xZm9kaXNjb3VudC5jb20vJyArXG4gICAgICAgICAgICAgICAgKChfZCA9IGRvY3VtZW50XG4gICAgICAgICAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcucHJvZHVjdC1zaGVldF9zbGlkZXNob3dfc2Nyb2xsYWJsZSBpbWcucHJvZHVjdC1zaGVldF9zbGlkZXNob3dfc2xpZGVfaW1nJykpID09PSBudWxsIHx8IF9kID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZC5nZXRBdHRyaWJ1dGUoJ3NyYycpKSkgIT09IG51bGwgJiYgX2UgIT09IHZvaWQgMCA/IF9lIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIHJldHVybiBhO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRSZWljaGVsdEluZm8oKSB7XG4gICAgICAgIHZhciBfYSwgX2IsIF9jLCBfZCwgX2U7XG4gICAgICAgIGNvbnN0IGEgPSB7fTtcbiAgICAgICAgYS5uYW1lID1cbiAgICAgICAgICAgIChfYiA9IChfYSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5hdl9hcnRpY2xlaGVhZGVyIFtpdGVtcHJvcD1cIm5hbWVcIl0nKSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmlubmVyVGV4dCkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIGEucHJpY2UgPSBOdW1iZXIoKF9jID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2F2X3ByaWNlJykuaW5uZXJUZXh0KSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2MucmVwbGFjZSgnLCcsICcuJykpO1xuICAgICAgICBhLmltZ1VybCA9XG4gICAgICAgICAgICAoX2UgPSAoX2QgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjZ2FsbGVyeSBpbWcnKSkgPT09IG51bGwgfHwgX2QgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9kLmdldEF0dHJpYnV0ZSgnc3JjJykpICE9PSBudWxsICYmIF9lICE9PSB2b2lkIDAgPyBfZSA6ICdOb3QgRm91bmQnO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0QlBNUG93ZXJJbmZvKCkge1xuICAgICAgICB2YXIgX2EsIF9iLCBfYywgX2Q7XG4gICAgICAgIGNvbnN0IGEgPSB7fTtcbiAgICAgICAgYS5uYW1lID1cbiAgICAgICAgICAgIChfYiA9IChfYSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy50aXRsZVRleHQgaDEnKSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmlubmVyVGV4dCkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIGEucHJpY2UgPSBOdW1iZXIoZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2RpdlByb2R1Y3RJbmZvQW5kSGVscCAucHJlenpvU2NoZWRhJykuaW5uZXJUZXh0XG4gICAgICAgICAgICAucmVwbGFjZSgnIOKCrCAnLCAnJylcbiAgICAgICAgICAgIC5yZXBsYWNlKCcsJywgJy4nKSk7XG4gICAgICAgIGEuaW1nVXJsID1cbiAgICAgICAgICAgIChfZCA9IChfYyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNtYWluSW1hZ2VEaXYgaW1nJykpID09PSBudWxsIHx8IF9jID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYy5nZXRBdHRyaWJ1dGUoJ3NyYycpKSAhPT0gbnVsbCAmJiBfZCAhPT0gdm9pZCAwID8gX2QgOiAnTm90IEZvdW5kJztcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldFJEQ0luZm8oKSB7XG4gICAgICAgIHZhciBfYSwgX2IsIF9jLCBfZDtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPVxuICAgICAgICAgICAgKF9iID0gKF9hID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLnByb2R1Y3QtbmFtZSBzcGFuJykpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pbm5lclRleHQpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICdOb3QgRm91bmQnO1xuICAgICAgICBhLnByaWNlID0gTnVtYmVyKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5wcm9kdWN0X19wcmljZSAuZHluX3Byb2RfcHJpY2UnKS5pbm5lclRleHRcbiAgICAgICAgICAgIC5yZXBsYWNlKCcg4oKsICcsICcnKVxuICAgICAgICAgICAgLnJlcGxhY2UoJywnLCAnLicpKTtcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgKF9kID0gJ2h0dHBzOi8vd3d3LnJ1ZWR1Y29tbWVyY2UuZnInICtcbiAgICAgICAgICAgICAgICAoKF9jID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2dhbGxlcnkgLm93bC1pdGVtIGltZycpKSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2MuZ2V0QXR0cmlidXRlKCdzcmMnKSkpICE9PSBudWxsICYmIF9kICE9PSB2b2lkIDAgPyBfZCA6ICdOb3QgRm91bmQnO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG4gICAgbGV0IGEgPSB7fTtcbiAgICBpZiAodXJsLmluY2x1ZGVzKCdwY2NvbXBvbmVudGVzLmZyJykpIHtcbiAgICAgICAgYSA9IGdldFBjQ29tcG9uZW50ZXNJbmZvKCk7XG4gICAgICAgIGEudmVuZG9yID0gJ1BDIENvbXBvbmVudGVzJztcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdwY2NvbXBvbmVudGVzLmNvbScpKSB7XG4gICAgICAgIGEgPSBnZXRQY0NvbXBvbmVudGVzSW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdQQyBDb21wb25lbnRlcyBFUyc7XG4gICAgfVxuICAgIGVsc2UgaWYgKHVybC5pbmNsdWRlcygnYW1hem9uLmZyJykpIHtcbiAgICAgICAgYSA9IGdldEFtYXpvbkluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnQW1hem9uIEZSJztcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdhbWF6b24uZGUnKSkge1xuICAgICAgICBhID0gZ2V0QW1hem9uSW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdBbWF6b24gREUnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2FtYXpvbi5pdCcpKSB7XG4gICAgICAgIGEgPSBnZXRBbWF6b25JbmZvKCk7XG4gICAgICAgIGEudmVuZG9yID0gJ0FtYXpvbiBJVCc7XG4gICAgfVxuICAgIGVsc2UgaWYgKHVybC5pbmNsdWRlcygnYW1hem9uLmVzJykpIHtcbiAgICAgICAgYSA9IGdldEFtYXpvbkluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnQW1hem9uIEVTJztcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdjZGlzY291bnQuY29tJykpIHtcbiAgICAgICAgYSA9IGdldENkaXNjb3VudEluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnQ0Rpc2NvdW50JztcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdncm9zYmlsbC5jb20nKSkge1xuICAgICAgICBhID0gZ2V0R3Jvc0JpbGxJbmZvKCk7XG4gICAgICAgIGEudmVuZG9yID0gJ0dyb3NCaWxsJztcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdjeWJlcnRlay5mcicpKSB7XG4gICAgICAgIGEgPSBnZXRDeWJlcnRla0luZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnQ3liZXJ0ZWsnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ3RvcGFjaGF0LmNvbScpKSB7XG4gICAgICAgIGEgPSBnZXRUb3BBY2hhdEluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnVG9wQWNoYXQnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJzFmb2Rpc2NvdW50LmNvbScpKSB7XG4gICAgICAgIGEgPSBnZXRJbmZvRGlzY291bnRJbmZvKCk7XG4gICAgICAgIGEudmVuZG9yID0gJzFmb0Rpc2NvdW50JztcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdyZWljaGVsdC5jb20nKSkge1xuICAgICAgICBhID0gZ2V0UmVpY2hlbHRJbmZvKCk7XG4gICAgICAgIGEudmVuZG9yID0gJ1JlaWNoZWx0JztcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdicG0tcG93ZXIuY29tJykpIHtcbiAgICAgICAgYSA9IGdldEJQTVBvd2VySW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdCUE0tUG93ZXInO1xuICAgICAgICBhLndhcm5pbmcgPSBcIkJpZW4gVsOpcmlmaWVyIHNvdXMgNWogcXUnaWwgbid5IGEgcGFzIGRlIGTDqWdhdCBzdXIgbGUgY29saXNcIjtcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdydWVkdWNvbW1lcmNlLmZyJykpIHtcbiAgICAgICAgYSA9IGdldFJEQ0luZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnUnVlIGR1IENvbW1lcmNlJztcbiAgICB9XG4gICAgbGV0IHNlbGVjdGlvbiA9IChfYSA9IHdpbmRvdyA9PT0gbnVsbCB8fCB3aW5kb3cgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHdpbmRvdy5nZXRTZWxlY3Rpb24oKSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLnRvU3RyaW5nKCk7XG4gICAgYS5uYW1lID0gc2VsZWN0aW9uICE9ICcnID8gc2VsZWN0aW9uIDogKF9iID0gYSA9PT0gbnVsbCB8fCBhID09PSB2b2lkIDAgPyB2b2lkIDAgOiBhLm5hbWUpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYi5yZXBsYWNlKCdcIicsICcnKTtcbiAgICByZXR1cm4gYTtcbn07XG5leHBvcnQgZGVmYXVsdCBnZXRJbmZvcztcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgeyBzaWduYWwsIHVzZVNpZ25hbEVmZmVjdCB9IGZyb20gJ0BwcmVhY3Qvc2lnbmFscy1yZWFjdCc7XG5pbXBvcnQgZ2V0SW5mb3MgZnJvbSAnLi9nZXQtaW5mb3MnO1xuaW1wb3J0IEJ1dHRvbiBmcm9tICdAbXVpL21hdGVyaWFsL0J1dHRvbic7XG5pbXBvcnQgVGV4dEZpZWxkIGZyb20gJ0BtdWkvbWF0ZXJpYWwvVGV4dEZpZWxkJztcbmltcG9ydCB7IEljb24gfSBmcm9tICdAaWNvbmlmeS9yZWFjdCc7XG5jb25zdCBzZWxsZXIgPSBzaWduYWwoJycpO1xuY29uc3QgYXJ0aWNsZSA9IHNpZ25hbCh7fSk7XG5mdW5jdGlvbiBnZW5lcmF0ZUV4Y2VsQ2xpcGJvYXJkU3RyaW5nKCkge1xuICAgIHZhciBfYSwgX2I7XG4gICAgbGV0IHByaWNlID0gTWF0aC5yb3VuZCgoKF9hID0gYXJ0aWNsZS52YWx1ZS5wcmljZSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogMCkgKyAoKF9iID0gYXJ0aWNsZS52YWx1ZS5mZHApICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6IDApKTtcbiAgICBsZXQgcyA9IGA9SU1BR0UoXCIke2FydGljbGUudmFsdWUuaW1nVXJsfVwiKVxcdGA7XG4gICAgcyArPSBgPUhZUEVSTElOSyhcIiR7YXJ0aWNsZS52YWx1ZS51cmx9XCI7XCIke2FydGljbGUudmFsdWUubmFtZX1cIilcXHRgO1xuICAgIHMgKz0gYCR7YXJ0aWNsZS52YWx1ZS52ZW5kb3J9XFx0YDtcbiAgICBzICs9IGAke3ByaWNlfSDigqxcXHRgO1xuICAgIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHMpO1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVEaXNjb3JkQ2xpcGJvYXJkU3RyaW5nKCkge1xuICAgIHZhciBfYSwgX2I7XG4gICAgbGV0IHByaWNlID0gTWF0aC5yb3VuZCgoKF9hID0gYXJ0aWNsZS52YWx1ZS5wcmljZSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogMCkgKyAoKF9iID0gYXJ0aWNsZS52YWx1ZS5mZHApICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6IDApKTtcbiAgICBsZXQgcyA9IGAqKiR7YXJ0aWNsZS52YWx1ZS5uYW1lfSoqIMOgICoqJHtwcmljZX3igqwqKiB2ZW5kdSBwYXIgKioke2FydGljbGUudmFsdWUudmVuZG9yfSoqIDpgO1xuICAgIGlmIChhcnRpY2xlLnZhbHVlLndhcm5pbmcpXG4gICAgICAgIHMgKz0gYFxcbjp3YXJuaW5nOiR7YXJ0aWNsZS52YWx1ZS53YXJuaW5nfTp3YXJuaW5nOmA7XG4gICAgcyArPSBgXFxuJHthcnRpY2xlLnZhbHVlLnVybH1gO1xuICAgIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHMpO1xufVxuY29uc3QgYW5hbHl6ZVVybCA9ICgpID0+IHtcbiAgICBjaHJvbWUudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9LCBmdW5jdGlvbiAodGFicykge1xuICAgICAgICBjb25zdCB0YWIgPSB0YWJzWzBdO1xuICAgICAgICBjaHJvbWUuc2NyaXB0aW5nXG4gICAgICAgICAgICAuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICAgICAgZnVuYzogZ2V0SW5mb3MsXG4gICAgICAgICAgICBhcmdzOiBbdGFiLnVybF0sXG4gICAgICAgIH0pXG4gICAgICAgICAgICAudGhlbigoaW5qZWN0aW9uUmVzdWx0cykgPT4ge1xuICAgICAgICAgICAgZm9yIChjb25zdCB7IGZyYW1lSWQsIHJlc3VsdCB9IG9mIGluamVjdGlvblJlc3VsdHMpIHtcbiAgICAgICAgICAgICAgICBhcnRpY2xlLnZhbHVlID0gcmVzdWx0O1xuICAgICAgICAgICAgICAgIGFydGljbGUudmFsdWUudXJsID0gdGFiLnVybDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSk7XG59O1xuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKGZ1bmN0aW9uIChyZXF1ZXN0KSB7XG4gICAgY29uc29sZS5sb2coJ3BvcHUnICsgcmVxdWVzdCk7XG59KTtcbmNvbnN0IGNhcmRDb250ZW50ID0ge1xuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAnZmxleC1kaXJlY3Rpb24nOiAnY29sdW1uJyxcbiAgICBhbGlnbkl0ZW1zOiAnc3RyZWNoJyxcbiAgICByb3dHYXA6ICcxMHB4JyxcbiAgICBtaW5XaWR0aDogJzgwMHB4Jyxcbn07XG5jb25zdCBjYXJkQWN0aW9uID0ge1xuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBjb2x1bW5HYXA6ICc1cHgnLFxufTtcbmNvbnN0IGlucHV0U3R5bGUgPSB7XG4gICAgd2lkdGg6ICcxMDAlJyxcbn07XG5jb25zdCBwcmljZUNvbnRhaW5lclN0eWxlID0ge1xuICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICBjb2x1bW5HYXA6ICc1cHgnLFxufTtcbmNvbnN0IHByaWNlSW5wdXRTdHlsZSA9IHtcbiAgICB3aWR0aDogJzgwJScsXG59O1xuY29uc3QgZmRwSW5wdXRTdHlsZSA9IHtcbiAgICB3aWR0aDogJzIwJScsXG59O1xuY29uc3QgaWNvblN0eWxlID0ge1xuICAgIG1hcmdpblJpZ2h0OiAnMnB4Jyxcbn07XG5jb25zdCBoYW5kbGVDaGFuZ2UgPSAoZXZlbnQpID0+IHtcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAnbmFtZScpXG4gICAgICAgIGFydGljbGUudmFsdWUgPSBPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIGFydGljbGUudmFsdWUpLCB7IG5hbWU6IGV2ZW50LnRhcmdldC52YWx1ZSB9KTtcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAndXJsJylcbiAgICAgICAgYXJ0aWNsZS52YWx1ZSA9IE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgYXJ0aWNsZS52YWx1ZSksIHsgdXJsOiBldmVudC50YXJnZXQudmFsdWUgfSk7XG4gICAgaWYgKGV2ZW50LnRhcmdldC5pZCA9PT0gJ3ZlbmRvcicpXG4gICAgICAgIGFydGljbGUudmFsdWUgPSBPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIGFydGljbGUudmFsdWUpLCB7IHZlbmRvcjogZXZlbnQudGFyZ2V0LnZhbHVlIH0pO1xuICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICdwcmljZScpXG4gICAgICAgIGFydGljbGUudmFsdWUgPSBPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIGFydGljbGUudmFsdWUpLCB7IHByaWNlOiBOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKSB9KTtcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAnZmRwJylcbiAgICAgICAgYXJ0aWNsZS52YWx1ZSA9IE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgYXJ0aWNsZS52YWx1ZSksIHsgZmRwOiBOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKSB9KTtcbiAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAnaW1nVXJsJylcbiAgICAgICAgYXJ0aWNsZS52YWx1ZSA9IE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgYXJ0aWNsZS52YWx1ZSksIHsgaW1nVXJsOiBldmVudC50YXJnZXQudmFsdWUgfSk7XG4gICAgaWYgKGV2ZW50LnRhcmdldC5pZCA9PT0gJ3dhcm5pbmcnKVxuICAgICAgICBhcnRpY2xlLnZhbHVlID0gT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LCBhcnRpY2xlLnZhbHVlKSwgeyB3YXJuaW5nOiBldmVudC50YXJnZXQudmFsdWUgfSk7XG59O1xuY29uc3QgUG9wdXAgPSAoKSA9PiB7XG4gICAgLy8gY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0OiBjb3VudC50b1N0cmluZygpIH0pO1xuICAgIHVzZVNpZ25hbEVmZmVjdChhbmFseXplVXJsKTtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBzdHlsZTogY2FyZENvbnRlbnQgfSxcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBzdHlsZTogY2FyZENvbnRlbnQgfSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSwgdmFsdWU6IGFydGljbGUudmFsdWUudXJsLCBpZDogXCJ1cmxcIiwgbXVsdGlsaW5lOiB0cnVlLCBsYWJlbDogXCJVUkxcIiwgZGVmYXVsdFZhbHVlOiBcIkVycm9yXCIgfSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIHZhbHVlOiBhcnRpY2xlLnZhbHVlLnZlbmRvciwgaWQ6IFwidmVuZG9yXCIsIGxhYmVsOiBcIlNlbGxlclwiLCBkZWZhdWx0VmFsdWU6IFwiRXJyb3JcIiB9KSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSwgdmFsdWU6IGFydGljbGUudmFsdWUubmFtZSwgaWQ6IFwibmFtZVwiLCBsYWJlbDogXCJBcnRpY2xlXCIsIGRlZmF1bHRWYWx1ZTogXCJFcnJvclwiIH0pLFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBzdHlsZTogcHJpY2VDb250YWluZXJTdHlsZSB9LFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogcHJpY2VJbnB1dFN0eWxlLCBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLCB2YWx1ZTogYXJ0aWNsZS52YWx1ZS5wcmljZSwgaWQ6IFwicHJpY2VcIiwgdHlwZTogXCJudW1iZXJcIiwgbGFiZWw6IFwiUHJpY2VcIiwgZGVmYXVsdFZhbHVlOiBcIjQwNFwiIH0pLFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogZmRwSW5wdXRTdHlsZSwgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSwgdmFsdWU6IGFydGljbGUudmFsdWUuZmRwLCBpZDogXCJmZHBcIiwgdHlwZTogXCJudW1iZXJcIiwgbGFiZWw6IFwiRnJhaXMgRGUgUG9ydFwiLCBkZWZhdWx0VmFsdWU6IFwiMFwiIH0pKSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSwgdmFsdWU6IGFydGljbGUudmFsdWUud2FybmluZywgaWQ6IFwid2FybmluZ1wiLCBsYWJlbDogXCJXYXJuaW5nXCIsIG11bHRpbGluZTogdHJ1ZSwgbWF4Um93czogNCwgZGVmYXVsdFZhbHVlOiBcIiBcIiB9KSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSwgdmFsdWU6IGFydGljbGUudmFsdWUuaW1nVXJsLCBpZDogXCJpbWdVcmxcIiwgbGFiZWw6IFwiSW1hZ2UgVXJsXCIsIGRlZmF1bHRWYWx1ZTogXCJFcnJvclwiIH0pKSxcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBzdHlsZTogY2FyZEFjdGlvbiB9LFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uLCB7IHZhcmlhbnQ6IFwiY29udGFpbmVkXCIsIG9uQ2xpY2s6IGFuYWx5emVVcmwgfSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJY29uLCB7IHN0eWxlOiBpY29uU3R5bGUsIGljb246IFwiY2hhcm06cmVmcmVzaFwiLCBoZWlnaHQ6IFwiMzBcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgXCJSZWZyZXNoXCIpLFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uLCB7IHZhcmlhbnQ6IFwiY29udGFpbmVkXCIsIG9uQ2xpY2s6IGdlbmVyYXRlRXhjZWxDbGlwYm9hcmRTdHJpbmcgfSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJY29uLCB7IGljb246IFwic2ltcGxlLWljb25zOmdvb2dsZXNoZWV0c1wiLCBoZWlnaHQ6IFwiMzZcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgXCJHZW5lcmF0ZSBFeGNlbCBTdHJpbmdcIiksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCdXR0b24sIHsgdmFyaWFudDogXCJjb250YWluZWRcIiwgb25DbGljazogZ2VuZXJhdGVEaXNjb3JkQ2xpcGJvYXJkU3RyaW5nIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbiwgeyBzdHlsZTogaWNvblN0eWxlLCBpY29uOiBcImljOmJhc2VsaW5lLWRpc2NvcmRcIiwgaGVpZ2h0OiBcIjMwXCIgfSksXG4gICAgICAgICAgICAgICAgICAgIFwiR2VuZXJhdGUgRGlzY29yZCBTdHJpbmdcIikpKSkpO1xufTtcbmNvbnN0IHJvb3QgPSBjcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykpO1xucm9vdC5yZW5kZXIoUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5TdHJpY3RNb2RlLCBudWxsLFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUG9wdXAsIG51bGwpKSk7XG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdGlkOiBtb2R1bGVJZCxcblx0XHRsb2FkZWQ6IGZhbHNlLFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcblx0bW9kdWxlLmxvYWRlZCA9IHRydWU7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4vLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuX193ZWJwYWNrX3JlcXVpcmVfXy5tID0gX193ZWJwYWNrX21vZHVsZXNfXztcblxuIiwidmFyIGRlZmVycmVkID0gW107XG5fX3dlYnBhY2tfcmVxdWlyZV9fLk8gPSAocmVzdWx0LCBjaHVua0lkcywgZm4sIHByaW9yaXR5KSA9PiB7XG5cdGlmKGNodW5rSWRzKSB7XG5cdFx0cHJpb3JpdHkgPSBwcmlvcml0eSB8fCAwO1xuXHRcdGZvcih2YXIgaSA9IGRlZmVycmVkLmxlbmd0aDsgaSA+IDAgJiYgZGVmZXJyZWRbaSAtIDFdWzJdID4gcHJpb3JpdHk7IGktLSkgZGVmZXJyZWRbaV0gPSBkZWZlcnJlZFtpIC0gMV07XG5cdFx0ZGVmZXJyZWRbaV0gPSBbY2h1bmtJZHMsIGZuLCBwcmlvcml0eV07XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHZhciBub3RGdWxmaWxsZWQgPSBJbmZpbml0eTtcblx0Zm9yICh2YXIgaSA9IDA7IGkgPCBkZWZlcnJlZC5sZW5ndGg7IGkrKykge1xuXHRcdHZhciBbY2h1bmtJZHMsIGZuLCBwcmlvcml0eV0gPSBkZWZlcnJlZFtpXTtcblx0XHR2YXIgZnVsZmlsbGVkID0gdHJ1ZTtcblx0XHRmb3IgKHZhciBqID0gMDsgaiA8IGNodW5rSWRzLmxlbmd0aDsgaisrKSB7XG5cdFx0XHRpZiAoKHByaW9yaXR5ICYgMSA9PT0gMCB8fCBub3RGdWxmaWxsZWQgPj0gcHJpb3JpdHkpICYmIE9iamVjdC5rZXlzKF9fd2VicGFja19yZXF1aXJlX18uTykuZXZlcnkoKGtleSkgPT4gKF9fd2VicGFja19yZXF1aXJlX18uT1trZXldKGNodW5rSWRzW2pdKSkpKSB7XG5cdFx0XHRcdGNodW5rSWRzLnNwbGljZShqLS0sIDEpO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0ZnVsZmlsbGVkID0gZmFsc2U7XG5cdFx0XHRcdGlmKHByaW9yaXR5IDwgbm90RnVsZmlsbGVkKSBub3RGdWxmaWxsZWQgPSBwcmlvcml0eTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYoZnVsZmlsbGVkKSB7XG5cdFx0XHRkZWZlcnJlZC5zcGxpY2UoaS0tLCAxKVxuXHRcdFx0dmFyIHIgPSBmbigpO1xuXHRcdFx0aWYgKHIgIT09IHVuZGVmaW5lZCkgcmVzdWx0ID0gcjtcblx0XHR9XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn07IiwiLy8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbl9fd2VicGFja19yZXF1aXJlX18ubiA9IChtb2R1bGUpID0+IHtcblx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG5cdFx0KCkgPT4gKG1vZHVsZVsnZGVmYXVsdCddKSA6XG5cdFx0KCkgPT4gKG1vZHVsZSk7XG5cdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsIHsgYTogZ2V0dGVyIH0pO1xuXHRyZXR1cm4gZ2V0dGVyO1xufTsiLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLmcgPSAoZnVuY3Rpb24oKSB7XG5cdGlmICh0eXBlb2YgZ2xvYmFsVGhpcyA9PT0gJ29iamVjdCcpIHJldHVybiBnbG9iYWxUaGlzO1xuXHR0cnkge1xuXHRcdHJldHVybiB0aGlzIHx8IG5ldyBGdW5jdGlvbigncmV0dXJuIHRoaXMnKSgpO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0aWYgKHR5cGVvZiB3aW5kb3cgPT09ICdvYmplY3QnKSByZXR1cm4gd2luZG93O1xuXHR9XG59KSgpOyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm5tZCA9IChtb2R1bGUpID0+IHtcblx0bW9kdWxlLnBhdGhzID0gW107XG5cdGlmICghbW9kdWxlLmNoaWxkcmVuKSBtb2R1bGUuY2hpbGRyZW4gPSBbXTtcblx0cmV0dXJuIG1vZHVsZTtcbn07IiwiLy8gbm8gYmFzZVVSSVxuXG4vLyBvYmplY3QgdG8gc3RvcmUgbG9hZGVkIGFuZCBsb2FkaW5nIGNodW5rc1xuLy8gdW5kZWZpbmVkID0gY2h1bmsgbm90IGxvYWRlZCwgbnVsbCA9IGNodW5rIHByZWxvYWRlZC9wcmVmZXRjaGVkXG4vLyBbcmVzb2x2ZSwgcmVqZWN0LCBQcm9taXNlXSA9IGNodW5rIGxvYWRpbmcsIDAgPSBjaHVuayBsb2FkZWRcbnZhciBpbnN0YWxsZWRDaHVua3MgPSB7XG5cdFwicG9wdXBcIjogMFxufTtcblxuLy8gbm8gY2h1bmsgb24gZGVtYW5kIGxvYWRpbmdcblxuLy8gbm8gcHJlZmV0Y2hpbmdcblxuLy8gbm8gcHJlbG9hZGVkXG5cbi8vIG5vIEhNUlxuXG4vLyBubyBITVIgbWFuaWZlc3RcblxuX193ZWJwYWNrX3JlcXVpcmVfXy5PLmogPSAoY2h1bmtJZCkgPT4gKGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9PT0gMCk7XG5cbi8vIGluc3RhbGwgYSBKU09OUCBjYWxsYmFjayBmb3IgY2h1bmsgbG9hZGluZ1xudmFyIHdlYnBhY2tKc29ucENhbGxiYWNrID0gKHBhcmVudENodW5rTG9hZGluZ0Z1bmN0aW9uLCBkYXRhKSA9PiB7XG5cdHZhciBbY2h1bmtJZHMsIG1vcmVNb2R1bGVzLCBydW50aW1lXSA9IGRhdGE7XG5cdC8vIGFkZCBcIm1vcmVNb2R1bGVzXCIgdG8gdGhlIG1vZHVsZXMgb2JqZWN0LFxuXHQvLyB0aGVuIGZsYWcgYWxsIFwiY2h1bmtJZHNcIiBhcyBsb2FkZWQgYW5kIGZpcmUgY2FsbGJhY2tcblx0dmFyIG1vZHVsZUlkLCBjaHVua0lkLCBpID0gMDtcblx0aWYoY2h1bmtJZHMuc29tZSgoaWQpID0+IChpbnN0YWxsZWRDaHVua3NbaWRdICE9PSAwKSkpIHtcblx0XHRmb3IobW9kdWxlSWQgaW4gbW9yZU1vZHVsZXMpIHtcblx0XHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhtb3JlTW9kdWxlcywgbW9kdWxlSWQpKSB7XG5cdFx0XHRcdF9fd2VicGFja19yZXF1aXJlX18ubVttb2R1bGVJZF0gPSBtb3JlTW9kdWxlc1ttb2R1bGVJZF07XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmKHJ1bnRpbWUpIHZhciByZXN1bHQgPSBydW50aW1lKF9fd2VicGFja19yZXF1aXJlX18pO1xuXHR9XG5cdGlmKHBhcmVudENodW5rTG9hZGluZ0Z1bmN0aW9uKSBwYXJlbnRDaHVua0xvYWRpbmdGdW5jdGlvbihkYXRhKTtcblx0Zm9yKDtpIDwgY2h1bmtJZHMubGVuZ3RoOyBpKyspIHtcblx0XHRjaHVua0lkID0gY2h1bmtJZHNbaV07XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGluc3RhbGxlZENodW5rcywgY2h1bmtJZCkgJiYgaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdKSB7XG5cdFx0XHRpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF1bMF0oKTtcblx0XHR9XG5cdFx0aW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdID0gMDtcblx0fVxuXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXy5PKHJlc3VsdCk7XG59XG5cbnZhciBjaHVua0xvYWRpbmdHbG9iYWwgPSBzZWxmW1wid2VicGFja0NodW5rRGVhbF9TbmlmZmVyXCJdID0gc2VsZltcIndlYnBhY2tDaHVua0RlYWxfU25pZmZlclwiXSB8fCBbXTtcbmNodW5rTG9hZGluZ0dsb2JhbC5mb3JFYWNoKHdlYnBhY2tKc29ucENhbGxiYWNrLmJpbmQobnVsbCwgMCkpO1xuY2h1bmtMb2FkaW5nR2xvYmFsLnB1c2ggPSB3ZWJwYWNrSnNvbnBDYWxsYmFjay5iaW5kKG51bGwsIGNodW5rTG9hZGluZ0dsb2JhbC5wdXNoLmJpbmQoY2h1bmtMb2FkaW5nR2xvYmFsKSk7IiwiIiwiLy8gc3RhcnR1cFxuLy8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4vLyBUaGlzIGVudHJ5IG1vZHVsZSBkZXBlbmRzIG9uIG90aGVyIGxvYWRlZCBjaHVua3MgYW5kIGV4ZWN1dGlvbiBuZWVkIHRvIGJlIGRlbGF5ZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXy5PKHVuZGVmaW5lZCwgW1widmVuZG9yXCJdLCAoKSA9PiAoX193ZWJwYWNrX3JlcXVpcmVfXyhcIi4vc3JjL3BvcHVwLnRzeFwiKSkpXG5fX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXy5PKF9fd2VicGFja19leHBvcnRzX18pO1xuIiwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9