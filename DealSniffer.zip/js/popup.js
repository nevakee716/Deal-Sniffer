/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/get-infos.tsx":
/*!***************************!*\
  !*** ./src/get-infos.tsx ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const getInfos = (url) => {
    var _a, _b;
    function getAmazonInfo() {
        var _a, _b, _c, _d, _e, _f;
        const a = {};
        a.name = (_b = (_a = document.getElementById('productTitle')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price =
            (_d = (_c = document.querySelector('#corePrice_feature_div .a-price-whole')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) !== null && _d !== void 0 ? _d : 'Not Found';
        a.imgUrl =
            (_f = (_e = document.querySelector('#imgTagWrapperId img')) === null || _e === void 0 ? void 0 : _e.getAttribute('src')) !== null && _f !== void 0 ? _f : 'Not Found';
        return a;
    }
    function getPcComponentesInfo() {
        var _a, _b, _c, _d, _e, _f;
        const a = {};
        a.name = (_b = (_a = document.getElementById('pdp-title')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price =
            (_d = (_c = document.getElementById('pdp-price-current-integer')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) !== null && _d !== void 0 ? _d : 'Not Found';
        a.imgUrl =
            (_f = (_e = document.querySelector('#pdp-section-images img')) === null || _e === void 0 ? void 0 : _e.getAttribute('src')) !== null && _f !== void 0 ? _f : 'Not Found';
        return a;
    }
    function getCdiscountInfo() {
        var _a, _b, _c, _d, _e, _f;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.fpTMain .fpDesCol h1')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price =
            (_d = (_c = document.querySelector('.fTopPrice  .fpPrice')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) !== null && _d !== void 0 ? _d : 'Not Found';
        a.imgUrl =
            (_f = (_e = document
                .querySelector('#fpZnPrdMain img#picture0')) === null || _e === void 0 ? void 0 : _e.getAttribute('src')) !== null && _f !== void 0 ? _f : 'Not Found';
        return a;
    }
    function getGrosBillInfo() {
        var _a, _b, _c, _d, _e, _f, _g;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.grb_fch-prod__content-title .grb_fch-prod__title')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price =
            (_e = (_d = (_c = document
                .querySelector('.fiche-produit-r  .fiche_product_price > span')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) === null || _d === void 0 ? void 0 : _d.replace('€', '')) !== null && _e !== void 0 ? _e : 'Not Found';
        a.imgUrl =
            (_g = 'https://www.grosbill.com' +
                ((_f = document
                    .querySelector('#product_buy [data-swiper-slide-index="0"] img')) === null || _f === void 0 ? void 0 : _f.getAttribute('src'))) !== null && _g !== void 0 ? _g : 'Not Found';
        return a;
    }
    function getCybertekInfo() {
        var _a, _b, _c, _d, _e, _f, _g;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.fiche-produit__bloc-achat__container .title_fiche')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price =
            (_e = (_d = (_c = document
                .querySelector('.fiche-produit__bloc-achat__prix  .fiche_product_price > span')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) === null || _d === void 0 ? void 0 : _d.replace('€', '')) !== null && _e !== void 0 ? _e : 'Not Found';
        a.imgUrl =
            (_g = (_f = document
                .querySelector('#fiche-produit__container-photos [data-swiper-slide-index="0"] img')) === null || _f === void 0 ? void 0 : _f.getAttribute('src')) !== null && _g !== void 0 ? _g : 'Not Found';
        return a;
    }
    function getTopAchatInfo() {
        var _a, _b, _c, _d, _e, _f;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.ps-main__product-title')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = (_d = (_c = document
            .querySelector('.ps-main__offer  .offer-price__price')) === null || _c === void 0 ? void 0 : _c.childNodes[0].nodeValue) === null || _d === void 0 ? void 0 : _d.replace(' €', '').replace('.', ',');
        a.imgUrl =
            (_f = (_e = document
                .querySelector('.product-main-image.ps-main__main-image img')) === null || _e === void 0 ? void 0 : _e.getAttribute('src')) !== null && _f !== void 0 ? _f : 'Not Found';
        return a;
    }
    function getInfoDiscountInfo() {
        var _a, _b, _c, _d, _e;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.product-sheet_title')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = (_c = document.querySelector('.product-sheet_buybox .product-sheet_buybox_offer_price').innerText) === null || _c === void 0 ? void 0 : _c.replace('\n', '').replace(' €', '');
        a.imgUrl =
            (_e = 'https://www.1fodiscount.com/' +
                ((_d = document
                    .querySelector('.product-sheet_slideshow_scrollable img.product-sheet_slideshow_slide_img')) === null || _d === void 0 ? void 0 : _d.getAttribute('src'))) !== null && _e !== void 0 ? _e : 'Not Found';
        return a;
    }
    function getReicheltInfo() {
        var _a, _b, _c, _d;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.av_articleheader [itemprop="name"]')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = document.querySelector('#av_price').innerText;
        a.imgUrl =
            (_d = (_c = document.querySelector('#gallery img')) === null || _c === void 0 ? void 0 : _c.getAttribute('src')) !== null && _d !== void 0 ? _d : 'Not Found';
        return a;
    }
    function getBPMPowerInfo() {
        var _a, _b, _c, _d;
        const a = {};
        a.name =
            (_b = (_a = document.querySelector('.titleText h1')) === null || _a === void 0 ? void 0 : _a.innerText) !== null && _b !== void 0 ? _b : 'Not Found';
        a.price = document.querySelector('#divProductInfoAndHelp .prezzoScheda').innerText.replace(' € ', '');
        a.imgUrl =
            (_d = (_c = document.querySelector('#mainImageDiv img')) === null || _c === void 0 ? void 0 : _c.getAttribute('src')) !== null && _d !== void 0 ? _d : 'Not Found';
        return a;
    }
    let a = {};
    if (url.includes('pccomponentes.fr')) {
        a = getPcComponentesInfo();
        a.vendor = 'PC Componentes';
    }
    else if (url.includes('pccomponentes.com')) {
        a = getPcComponentesInfo();
        a.vendor = 'PC Componentes ES';
    }
    else if (url.includes('amazon.fr')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon FR';
    }
    else if (url.includes('amazon.de')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon DE';
    }
    else if (url.includes('amazon.it')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon IT';
    }
    else if (url.includes('amazon.es')) {
        a = getAmazonInfo();
        a.vendor = 'Amazon ES';
    }
    else if (url.includes('cdiscount.com')) {
        a = getCdiscountInfo();
        a.vendor = 'CDiscount';
    }
    else if (url.includes('grosbill.com')) {
        a = getGrosBillInfo();
        a.vendor = 'GrosBill';
    }
    else if (url.includes('cybertek.fr')) {
        a = getCybertekInfo();
        a.vendor = 'Cybertek';
    }
    else if (url.includes('topachat.com')) {
        a = getTopAchatInfo();
        a.vendor = 'TopAchat';
    }
    else if (url.includes('1fodiscount.com')) {
        a = getInfoDiscountInfo();
        a.vendor = '1foDiscount';
    }
    else if (url.includes('reichelt.com')) {
        a = getReicheltInfo();
        a.vendor = 'Reichelt';
    }
    else if (url.includes('bpm-power.com')) {
        a = getBPMPowerInfo();
        a.vendor = 'BPM-Power';
        a.warning = "Bien Vérifier sous 5j qu'il n'y a pas de dégat sur le colis";
    }
    let selection = (_a = window === null || window === void 0 ? void 0 : window.getSelection()) === null || _a === void 0 ? void 0 : _a.toString();
    a.name = selection != '' ? selection : (_b = a === null || a === void 0 ? void 0 : a.name) === null || _b === void 0 ? void 0 : _b.replace('"', '');
    return a;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getInfos);


/***/ }),

/***/ "./src/popup.tsx":
/*!***********************!*\
  !*** ./src/popup.tsx ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom/client */ "./node_modules/react-dom/client.js");
/* harmony import */ var _preact_signals_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @preact/signals-react */ "./node_modules/@preact/signals-react/dist/signals.module.js");
/* harmony import */ var _get_infos__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./get-infos */ "./src/get-infos.tsx");




const seller = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)('');
const article = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)({});
const url = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)('');
function generateExcelClipboardString() {
    let s = `=IMAGE("${article.value.imgUrl}")\t`;
    s += `=HYPERLINK("${article.value.url}";"${article.value.name}")\t`;
    s += `${article.value.vendor}\t`;
    s += `${article.value.price} €\t`;
    navigator.clipboard.writeText(s);
}
function generateDiscordClipboardString() {
    let s = `**${article.value.name}** à **${article.value.price}€** vendu par ${article.value.vendor} :`;
    if (article.value.warning)
        s += `\n:warning:${article.value.warning}:warning:`;
    s += `\n${article.value.url}`;
    navigator.clipboard.writeText(s);
}
const analyzeUrl = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const tab = tabs[0];
        url.value = tabs[0].url;
        chrome.scripting
            .executeScript({
            target: { tabId: tab.id },
            func: _get_infos__WEBPACK_IMPORTED_MODULE_3__["default"],
            args: [url.value],
        })
            .then((injectionResults) => {
            for (const { frameId, result } of injectionResults) {
                article.value = result;
                article.value.url = url.value;
            }
        });
    });
};
chrome.runtime.onMessage.addListener(function (request) {
    console.log('popu' + request);
});
const Popup = () => {
    // chrome.action.setBadgeText({ text: count.toString() });
    (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.useSignalEffect)(analyzeUrl);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", { style: { minWidth: '700px' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null,
                "Current URL: ",
                url.value),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null,
                "Current Time: ",
                new Date().toLocaleTimeString()),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null,
                "Seller : ",
                article.value.vendor),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null,
                "Article : ",
                article.value.name),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null,
                "Price : ",
                article.value.price),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null,
                "Image Url : ",
                article.value.imgUrl)),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: analyzeUrl }, " Update"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: generateExcelClipboardString },
            ' ',
            "Generate Excel String"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: generateDiscordClipboardString },
            ' ',
            "Generate Discord String")));
};
const root = (0,react_dom_client__WEBPACK_IMPORTED_MODULE_1__.createRoot)(document.getElementById('root'));
root.render(react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().StrictMode), null,
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Popup, null)));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"popup": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkDeal_Sniffer"] = self["webpackChunkDeal_Sniffer"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__("./src/popup.tsx")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlFQUFlLFFBQVEsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuS0U7QUFDb0I7QUFDa0I7QUFDN0I7QUFDbkMsZUFBZSw2REFBTTtBQUNyQixnQkFBZ0IsNkRBQU0sR0FBRztBQUN6QixZQUFZLDZEQUFNO0FBQ2xCO0FBQ0EsdUJBQXVCLHFCQUFxQjtBQUM1Qyx3QkFBd0Isa0JBQWtCLEVBQUUsR0FBRyxtQkFBbUI7QUFDbEUsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxxQkFBcUI7QUFDakM7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLG1CQUFtQixTQUFTLG9CQUFvQixnQkFBZ0Isc0JBQXNCO0FBQ3ZHO0FBQ0EsMkJBQTJCLHNCQUFzQjtBQUNqRCxjQUFjLGtCQUFrQjtBQUNoQztBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsbUNBQW1DO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLGVBQWU7QUFDckMsa0JBQWtCLGtEQUFRO0FBQzFCO0FBQ0EsU0FBUztBQUNUO0FBQ0EseUJBQXlCLGtCQUFrQjtBQUMzQztBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBLG9DQUFvQyx3QkFBd0I7QUFDNUQsSUFBSSxzRUFBZTtBQUNuQixZQUFZLDBEQUFtQixDQUFDLHVEQUFjO0FBQzlDLFFBQVEsMERBQW1CLFNBQVMsU0FBUyxxQkFBcUI7QUFDbEUsWUFBWSwwREFBbUI7QUFDL0I7QUFDQTtBQUNBLFlBQVksMERBQW1CO0FBQy9CO0FBQ0E7QUFDQSxZQUFZLDBEQUFtQjtBQUMvQjtBQUNBO0FBQ0EsWUFBWSwwREFBbUI7QUFDL0I7QUFDQTtBQUNBLFlBQVksMERBQW1CO0FBQy9CO0FBQ0E7QUFDQSxZQUFZLDBEQUFtQjtBQUMvQjtBQUNBO0FBQ0EsUUFBUSwwREFBbUIsYUFBYSxxQkFBcUI7QUFDN0QsUUFBUSwwREFBbUIsYUFBYSx1Q0FBdUM7QUFDL0U7QUFDQTtBQUNBLFFBQVEsMERBQW1CLGFBQWEseUNBQXlDO0FBQ2pGO0FBQ0E7QUFDQTtBQUNBLGFBQWEsNERBQVU7QUFDdkIsWUFBWSwwREFBbUIsQ0FBQyx5REFBZ0I7QUFDaEQsSUFBSSwwREFBbUI7Ozs7Ozs7VUMzRXZCO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOzs7OztXQzVCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLCtCQUErQix3Q0FBd0M7V0FDdkU7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQkFBaUIscUJBQXFCO1dBQ3RDO1dBQ0E7V0FDQSxrQkFBa0IscUJBQXFCO1dBQ3ZDO1dBQ0E7V0FDQSxLQUFLO1dBQ0w7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOzs7OztXQzNCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsaUNBQWlDLFdBQVc7V0FDNUM7V0FDQTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBOzs7OztXQ1BBOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7V0NOQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOzs7OztXQ0pBOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxNQUFNLHFCQUFxQjtXQUMzQjtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBO1dBQ0E7V0FDQTs7Ozs7VUVoREE7VUFDQTtVQUNBO1VBQ0E7VUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL0RlYWwgU25pZmZlci8uL3NyYy9nZXQtaW5mb3MudHN4Iiwid2VicGFjazovL0RlYWwgU25pZmZlci8uL3NyYy9wb3B1cC50c3giLCJ3ZWJwYWNrOi8vRGVhbCBTbmlmZmVyL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY2h1bmsgbG9hZGVkIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly9EZWFsIFNuaWZmZXIvd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbm9kZSBtb2R1bGUgZGVjb3JhdG9yIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL3J1bnRpbWUvanNvbnAgY2h1bmsgbG9hZGluZyIsIndlYnBhY2s6Ly9EZWFsIFNuaWZmZXIvd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly9EZWFsIFNuaWZmZXIvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL0RlYWwgU25pZmZlci93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgZ2V0SW5mb3MgPSAodXJsKSA9PiB7XG4gICAgdmFyIF9hLCBfYjtcbiAgICBmdW5jdGlvbiBnZXRBbWF6b25JbmZvKCkge1xuICAgICAgICB2YXIgX2EsIF9iLCBfYywgX2QsIF9lLCBfZjtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPSAoX2IgPSAoX2EgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncHJvZHVjdFRpdGxlJykpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pbm5lclRleHQpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICdOb3QgRm91bmQnO1xuICAgICAgICBhLnByaWNlID1cbiAgICAgICAgICAgIChfZCA9IChfYyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNjb3JlUHJpY2VfZmVhdHVyZV9kaXYgLmEtcHJpY2Utd2hvbGUnKSkgPT09IG51bGwgfHwgX2MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jLmNoaWxkTm9kZXNbMF0ubm9kZVZhbHVlKSAhPT0gbnVsbCAmJiBfZCAhPT0gdm9pZCAwID8gX2QgOiAnTm90IEZvdW5kJztcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgKF9mID0gKF9lID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2ltZ1RhZ1dyYXBwZXJJZCBpbWcnKSkgPT09IG51bGwgfHwgX2UgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9lLmdldEF0dHJpYnV0ZSgnc3JjJykpICE9PSBudWxsICYmIF9mICE9PSB2b2lkIDAgPyBfZiA6ICdOb3QgRm91bmQnO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0UGNDb21wb25lbnRlc0luZm8oKSB7XG4gICAgICAgIHZhciBfYSwgX2IsIF9jLCBfZCwgX2UsIF9mO1xuICAgICAgICBjb25zdCBhID0ge307XG4gICAgICAgIGEubmFtZSA9IChfYiA9IChfYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwZHAtdGl0bGUnKSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmlubmVyVGV4dCkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIGEucHJpY2UgPVxuICAgICAgICAgICAgKF9kID0gKF9jID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3BkcC1wcmljZS1jdXJyZW50LWludGVnZXInKSkgPT09IG51bGwgfHwgX2MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jLmNoaWxkTm9kZXNbMF0ubm9kZVZhbHVlKSAhPT0gbnVsbCAmJiBfZCAhPT0gdm9pZCAwID8gX2QgOiAnTm90IEZvdW5kJztcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgKF9mID0gKF9lID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI3BkcC1zZWN0aW9uLWltYWdlcyBpbWcnKSkgPT09IG51bGwgfHwgX2UgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9lLmdldEF0dHJpYnV0ZSgnc3JjJykpICE9PSBudWxsICYmIF9mICE9PSB2b2lkIDAgPyBfZiA6ICdOb3QgRm91bmQnO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0Q2Rpc2NvdW50SW5mbygpIHtcbiAgICAgICAgdmFyIF9hLCBfYiwgX2MsIF9kLCBfZSwgX2Y7XG4gICAgICAgIGNvbnN0IGEgPSB7fTtcbiAgICAgICAgYS5uYW1lID1cbiAgICAgICAgICAgIChfYiA9IChfYSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5mcFRNYWluIC5mcERlc0NvbCBoMScpKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuaW5uZXJUZXh0KSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiAnTm90IEZvdW5kJztcbiAgICAgICAgYS5wcmljZSA9XG4gICAgICAgICAgICAoX2QgPSAoX2MgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZlRvcFByaWNlICAuZnBQcmljZScpKSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2MuY2hpbGROb2Rlc1swXS5ub2RlVmFsdWUpICE9PSBudWxsICYmIF9kICE9PSB2b2lkIDAgPyBfZCA6ICdOb3QgRm91bmQnO1xuICAgICAgICBhLmltZ1VybCA9XG4gICAgICAgICAgICAoX2YgPSAoX2UgPSBkb2N1bWVudFxuICAgICAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcjZnBablByZE1haW4gaW1nI3BpY3R1cmUwJykpID09PSBudWxsIHx8IF9lID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZS5nZXRBdHRyaWJ1dGUoJ3NyYycpKSAhPT0gbnVsbCAmJiBfZiAhPT0gdm9pZCAwID8gX2YgOiAnTm90IEZvdW5kJztcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldEdyb3NCaWxsSW5mbygpIHtcbiAgICAgICAgdmFyIF9hLCBfYiwgX2MsIF9kLCBfZSwgX2YsIF9nO1xuICAgICAgICBjb25zdCBhID0ge307XG4gICAgICAgIGEubmFtZSA9XG4gICAgICAgICAgICAoX2IgPSAoX2EgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZ3JiX2ZjaC1wcm9kX19jb250ZW50LXRpdGxlIC5ncmJfZmNoLXByb2RfX3RpdGxlJykpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pbm5lclRleHQpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICdOb3QgRm91bmQnO1xuICAgICAgICBhLnByaWNlID1cbiAgICAgICAgICAgIChfZSA9IChfZCA9IChfYyA9IGRvY3VtZW50XG4gICAgICAgICAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoJy5maWNoZS1wcm9kdWl0LXIgIC5maWNoZV9wcm9kdWN0X3ByaWNlID4gc3BhbicpKSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2MuY2hpbGROb2Rlc1swXS5ub2RlVmFsdWUpID09PSBudWxsIHx8IF9kID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZC5yZXBsYWNlKCfigqwnLCAnJykpICE9PSBudWxsICYmIF9lICE9PSB2b2lkIDAgPyBfZSA6ICdOb3QgRm91bmQnO1xuICAgICAgICBhLmltZ1VybCA9XG4gICAgICAgICAgICAoX2cgPSAnaHR0cHM6Ly93d3cuZ3Jvc2JpbGwuY29tJyArXG4gICAgICAgICAgICAgICAgKChfZiA9IGRvY3VtZW50XG4gICAgICAgICAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcjcHJvZHVjdF9idXkgW2RhdGEtc3dpcGVyLXNsaWRlLWluZGV4PVwiMFwiXSBpbWcnKSkgPT09IG51bGwgfHwgX2YgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9mLmdldEF0dHJpYnV0ZSgnc3JjJykpKSAhPT0gbnVsbCAmJiBfZyAhPT0gdm9pZCAwID8gX2cgOiAnTm90IEZvdW5kJztcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldEN5YmVydGVrSW5mbygpIHtcbiAgICAgICAgdmFyIF9hLCBfYiwgX2MsIF9kLCBfZSwgX2YsIF9nO1xuICAgICAgICBjb25zdCBhID0ge307XG4gICAgICAgIGEubmFtZSA9XG4gICAgICAgICAgICAoX2IgPSAoX2EgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZmljaGUtcHJvZHVpdF9fYmxvYy1hY2hhdF9fY29udGFpbmVyIC50aXRsZV9maWNoZScpKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuaW5uZXJUZXh0KSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiAnTm90IEZvdW5kJztcbiAgICAgICAgYS5wcmljZSA9XG4gICAgICAgICAgICAoX2UgPSAoX2QgPSAoX2MgPSBkb2N1bWVudFxuICAgICAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcuZmljaGUtcHJvZHVpdF9fYmxvYy1hY2hhdF9fcHJpeCAgLmZpY2hlX3Byb2R1Y3RfcHJpY2UgPiBzcGFuJykpID09PSBudWxsIHx8IF9jID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYy5jaGlsZE5vZGVzWzBdLm5vZGVWYWx1ZSkgPT09IG51bGwgfHwgX2QgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9kLnJlcGxhY2UoJ+KCrCcsICcnKSkgIT09IG51bGwgJiYgX2UgIT09IHZvaWQgMCA/IF9lIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIGEuaW1nVXJsID1cbiAgICAgICAgICAgIChfZyA9IChfZiA9IGRvY3VtZW50XG4gICAgICAgICAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoJyNmaWNoZS1wcm9kdWl0X19jb250YWluZXItcGhvdG9zIFtkYXRhLXN3aXBlci1zbGlkZS1pbmRleD1cIjBcIl0gaW1nJykpID09PSBudWxsIHx8IF9mID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZi5nZXRBdHRyaWJ1dGUoJ3NyYycpKSAhPT0gbnVsbCAmJiBfZyAhPT0gdm9pZCAwID8gX2cgOiAnTm90IEZvdW5kJztcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldFRvcEFjaGF0SW5mbygpIHtcbiAgICAgICAgdmFyIF9hLCBfYiwgX2MsIF9kLCBfZSwgX2Y7XG4gICAgICAgIGNvbnN0IGEgPSB7fTtcbiAgICAgICAgYS5uYW1lID1cbiAgICAgICAgICAgIChfYiA9IChfYSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5wcy1tYWluX19wcm9kdWN0LXRpdGxlJykpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pbm5lclRleHQpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICdOb3QgRm91bmQnO1xuICAgICAgICBhLnByaWNlID0gKF9kID0gKF9jID0gZG9jdW1lbnRcbiAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcucHMtbWFpbl9fb2ZmZXIgIC5vZmZlci1wcmljZV9fcHJpY2UnKSkgPT09IG51bGwgfHwgX2MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jLmNoaWxkTm9kZXNbMF0ubm9kZVZhbHVlKSA9PT0gbnVsbCB8fCBfZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2QucmVwbGFjZSgnwqDigqwnLCAnJykucmVwbGFjZSgnLicsICcsJyk7XG4gICAgICAgIGEuaW1nVXJsID1cbiAgICAgICAgICAgIChfZiA9IChfZSA9IGRvY3VtZW50XG4gICAgICAgICAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoJy5wcm9kdWN0LW1haW4taW1hZ2UucHMtbWFpbl9fbWFpbi1pbWFnZSBpbWcnKSkgPT09IG51bGwgfHwgX2UgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9lLmdldEF0dHJpYnV0ZSgnc3JjJykpICE9PSBudWxsICYmIF9mICE9PSB2b2lkIDAgPyBfZiA6ICdOb3QgRm91bmQnO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0SW5mb0Rpc2NvdW50SW5mbygpIHtcbiAgICAgICAgdmFyIF9hLCBfYiwgX2MsIF9kLCBfZTtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPVxuICAgICAgICAgICAgKF9iID0gKF9hID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLnByb2R1Y3Qtc2hlZXRfdGl0bGUnKSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmlubmVyVGV4dCkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIGEucHJpY2UgPSAoX2MgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcucHJvZHVjdC1zaGVldF9idXlib3ggLnByb2R1Y3Qtc2hlZXRfYnV5Ym94X29mZmVyX3ByaWNlJykuaW5uZXJUZXh0KSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2MucmVwbGFjZSgnXFxuJywgJycpLnJlcGxhY2UoJyDigqwnLCAnJyk7XG4gICAgICAgIGEuaW1nVXJsID1cbiAgICAgICAgICAgIChfZSA9ICdodHRwczovL3d3dy4xZm9kaXNjb3VudC5jb20vJyArXG4gICAgICAgICAgICAgICAgKChfZCA9IGRvY3VtZW50XG4gICAgICAgICAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKCcucHJvZHVjdC1zaGVldF9zbGlkZXNob3dfc2Nyb2xsYWJsZSBpbWcucHJvZHVjdC1zaGVldF9zbGlkZXNob3dfc2xpZGVfaW1nJykpID09PSBudWxsIHx8IF9kID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZC5nZXRBdHRyaWJ1dGUoJ3NyYycpKSkgIT09IG51bGwgJiYgX2UgIT09IHZvaWQgMCA/IF9lIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIHJldHVybiBhO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRSZWljaGVsdEluZm8oKSB7XG4gICAgICAgIHZhciBfYSwgX2IsIF9jLCBfZDtcbiAgICAgICAgY29uc3QgYSA9IHt9O1xuICAgICAgICBhLm5hbWUgPVxuICAgICAgICAgICAgKF9iID0gKF9hID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmF2X2FydGljbGVoZWFkZXIgW2l0ZW1wcm9wPVwibmFtZVwiXScpKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuaW5uZXJUZXh0KSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiAnTm90IEZvdW5kJztcbiAgICAgICAgYS5wcmljZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNhdl9wcmljZScpLmlubmVyVGV4dDtcbiAgICAgICAgYS5pbWdVcmwgPVxuICAgICAgICAgICAgKF9kID0gKF9jID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2dhbGxlcnkgaW1nJykpID09PSBudWxsIHx8IF9jID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYy5nZXRBdHRyaWJ1dGUoJ3NyYycpKSAhPT0gbnVsbCAmJiBfZCAhPT0gdm9pZCAwID8gX2QgOiAnTm90IEZvdW5kJztcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldEJQTVBvd2VySW5mbygpIHtcbiAgICAgICAgdmFyIF9hLCBfYiwgX2MsIF9kO1xuICAgICAgICBjb25zdCBhID0ge307XG4gICAgICAgIGEubmFtZSA9XG4gICAgICAgICAgICAoX2IgPSAoX2EgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcudGl0bGVUZXh0IGgxJykpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pbm5lclRleHQpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICdOb3QgRm91bmQnO1xuICAgICAgICBhLnByaWNlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2RpdlByb2R1Y3RJbmZvQW5kSGVscCAucHJlenpvU2NoZWRhJykuaW5uZXJUZXh0LnJlcGxhY2UoJyDigqwgJywgJycpO1xuICAgICAgICBhLmltZ1VybCA9XG4gICAgICAgICAgICAoX2QgPSAoX2MgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjbWFpbkltYWdlRGl2IGltZycpKSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2MuZ2V0QXR0cmlidXRlKCdzcmMnKSkgIT09IG51bGwgJiYgX2QgIT09IHZvaWQgMCA/IF9kIDogJ05vdCBGb3VuZCc7XG4gICAgICAgIHJldHVybiBhO1xuICAgIH1cbiAgICBsZXQgYSA9IHt9O1xuICAgIGlmICh1cmwuaW5jbHVkZXMoJ3BjY29tcG9uZW50ZXMuZnInKSkge1xuICAgICAgICBhID0gZ2V0UGNDb21wb25lbnRlc0luZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnUEMgQ29tcG9uZW50ZXMnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ3BjY29tcG9uZW50ZXMuY29tJykpIHtcbiAgICAgICAgYSA9IGdldFBjQ29tcG9uZW50ZXNJbmZvKCk7XG4gICAgICAgIGEudmVuZG9yID0gJ1BDIENvbXBvbmVudGVzIEVTJztcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdhbWF6b24uZnInKSkge1xuICAgICAgICBhID0gZ2V0QW1hem9uSW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdBbWF6b24gRlInO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2FtYXpvbi5kZScpKSB7XG4gICAgICAgIGEgPSBnZXRBbWF6b25JbmZvKCk7XG4gICAgICAgIGEudmVuZG9yID0gJ0FtYXpvbiBERSc7XG4gICAgfVxuICAgIGVsc2UgaWYgKHVybC5pbmNsdWRlcygnYW1hem9uLml0JykpIHtcbiAgICAgICAgYSA9IGdldEFtYXpvbkluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnQW1hem9uIElUJztcbiAgICB9XG4gICAgZWxzZSBpZiAodXJsLmluY2x1ZGVzKCdhbWF6b24uZXMnKSkge1xuICAgICAgICBhID0gZ2V0QW1hem9uSW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdBbWF6b24gRVMnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2NkaXNjb3VudC5jb20nKSkge1xuICAgICAgICBhID0gZ2V0Q2Rpc2NvdW50SW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdDRGlzY291bnQnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2dyb3NiaWxsLmNvbScpKSB7XG4gICAgICAgIGEgPSBnZXRHcm9zQmlsbEluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnR3Jvc0JpbGwnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2N5YmVydGVrLmZyJykpIHtcbiAgICAgICAgYSA9IGdldEN5YmVydGVrSW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdDeWJlcnRlayc7XG4gICAgfVxuICAgIGVsc2UgaWYgKHVybC5pbmNsdWRlcygndG9wYWNoYXQuY29tJykpIHtcbiAgICAgICAgYSA9IGdldFRvcEFjaGF0SW5mbygpO1xuICAgICAgICBhLnZlbmRvciA9ICdUb3BBY2hhdCc7XG4gICAgfVxuICAgIGVsc2UgaWYgKHVybC5pbmNsdWRlcygnMWZvZGlzY291bnQuY29tJykpIHtcbiAgICAgICAgYSA9IGdldEluZm9EaXNjb3VudEluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnMWZvRGlzY291bnQnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ3JlaWNoZWx0LmNvbScpKSB7XG4gICAgICAgIGEgPSBnZXRSZWljaGVsdEluZm8oKTtcbiAgICAgICAgYS52ZW5kb3IgPSAnUmVpY2hlbHQnO1xuICAgIH1cbiAgICBlbHNlIGlmICh1cmwuaW5jbHVkZXMoJ2JwbS1wb3dlci5jb20nKSkge1xuICAgICAgICBhID0gZ2V0QlBNUG93ZXJJbmZvKCk7XG4gICAgICAgIGEudmVuZG9yID0gJ0JQTS1Qb3dlcic7XG4gICAgICAgIGEud2FybmluZyA9IFwiQmllbiBWw6lyaWZpZXIgc291cyA1aiBxdSdpbCBuJ3kgYSBwYXMgZGUgZMOpZ2F0IHN1ciBsZSBjb2xpc1wiO1xuICAgIH1cbiAgICBsZXQgc2VsZWN0aW9uID0gKF9hID0gd2luZG93ID09PSBudWxsIHx8IHdpbmRvdyA9PT0gdm9pZCAwID8gdm9pZCAwIDogd2luZG93LmdldFNlbGVjdGlvbigpKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EudG9TdHJpbmcoKTtcbiAgICBhLm5hbWUgPSBzZWxlY3Rpb24gIT0gJycgPyBzZWxlY3Rpb24gOiAoX2IgPSBhID09PSBudWxsIHx8IGEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGEubmFtZSkgPT09IG51bGwgfHwgX2IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9iLnJlcGxhY2UoJ1wiJywgJycpO1xuICAgIHJldHVybiBhO1xufTtcbmV4cG9ydCBkZWZhdWx0IGdldEluZm9zO1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNyZWF0ZVJvb3QgfSBmcm9tICdyZWFjdC1kb20vY2xpZW50JztcbmltcG9ydCB7IHNpZ25hbCwgdXNlU2lnbmFsRWZmZWN0IH0gZnJvbSAnQHByZWFjdC9zaWduYWxzLXJlYWN0JztcbmltcG9ydCBnZXRJbmZvcyBmcm9tICcuL2dldC1pbmZvcyc7XG5jb25zdCBzZWxsZXIgPSBzaWduYWwoJycpO1xuY29uc3QgYXJ0aWNsZSA9IHNpZ25hbCh7fSk7XG5jb25zdCB1cmwgPSBzaWduYWwoJycpO1xuZnVuY3Rpb24gZ2VuZXJhdGVFeGNlbENsaXBib2FyZFN0cmluZygpIHtcbiAgICBsZXQgcyA9IGA9SU1BR0UoXCIke2FydGljbGUudmFsdWUuaW1nVXJsfVwiKVxcdGA7XG4gICAgcyArPSBgPUhZUEVSTElOSyhcIiR7YXJ0aWNsZS52YWx1ZS51cmx9XCI7XCIke2FydGljbGUudmFsdWUubmFtZX1cIilcXHRgO1xuICAgIHMgKz0gYCR7YXJ0aWNsZS52YWx1ZS52ZW5kb3J9XFx0YDtcbiAgICBzICs9IGAke2FydGljbGUudmFsdWUucHJpY2V9IOKCrFxcdGA7XG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQocyk7XG59XG5mdW5jdGlvbiBnZW5lcmF0ZURpc2NvcmRDbGlwYm9hcmRTdHJpbmcoKSB7XG4gICAgbGV0IHMgPSBgKioke2FydGljbGUudmFsdWUubmFtZX0qKiDDoCAqKiR7YXJ0aWNsZS52YWx1ZS5wcmljZX3igqwqKiB2ZW5kdSBwYXIgJHthcnRpY2xlLnZhbHVlLnZlbmRvcn0gOmA7XG4gICAgaWYgKGFydGljbGUudmFsdWUud2FybmluZylcbiAgICAgICAgcyArPSBgXFxuOndhcm5pbmc6JHthcnRpY2xlLnZhbHVlLndhcm5pbmd9Ondhcm5pbmc6YDtcbiAgICBzICs9IGBcXG4ke2FydGljbGUudmFsdWUudXJsfWA7XG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQocyk7XG59XG5jb25zdCBhbmFseXplVXJsID0gKCkgPT4ge1xuICAgIGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0sIGZ1bmN0aW9uICh0YWJzKSB7XG4gICAgICAgIGNvbnN0IHRhYiA9IHRhYnNbMF07XG4gICAgICAgIHVybC52YWx1ZSA9IHRhYnNbMF0udXJsO1xuICAgICAgICBjaHJvbWUuc2NyaXB0aW5nXG4gICAgICAgICAgICAuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICAgICAgZnVuYzogZ2V0SW5mb3MsXG4gICAgICAgICAgICBhcmdzOiBbdXJsLnZhbHVlXSxcbiAgICAgICAgfSlcbiAgICAgICAgICAgIC50aGVuKChpbmplY3Rpb25SZXN1bHRzKSA9PiB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHsgZnJhbWVJZCwgcmVzdWx0IH0gb2YgaW5qZWN0aW9uUmVzdWx0cykge1xuICAgICAgICAgICAgICAgIGFydGljbGUudmFsdWUgPSByZXN1bHQ7XG4gICAgICAgICAgICAgICAgYXJ0aWNsZS52YWx1ZS51cmwgPSB1cmwudmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xufTtcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihmdW5jdGlvbiAocmVxdWVzdCkge1xuICAgIGNvbnNvbGUubG9nKCdwb3B1JyArIHJlcXVlc3QpO1xufSk7XG5jb25zdCBQb3B1cCA9ICgpID0+IHtcbiAgICAvLyBjaHJvbWUuYWN0aW9uLnNldEJhZGdlVGV4dCh7IHRleHQ6IGNvdW50LnRvU3RyaW5nKCkgfSk7XG4gICAgdXNlU2lnbmFsRWZmZWN0KGFuYWx5emVVcmwpO1xuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbCxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcInVsXCIsIHsgc3R5bGU6IHsgbWluV2lkdGg6ICc3MDBweCcgfSB9LFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImxpXCIsIG51bGwsXG4gICAgICAgICAgICAgICAgXCJDdXJyZW50IFVSTDogXCIsXG4gICAgICAgICAgICAgICAgdXJsLnZhbHVlKSxcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJsaVwiLCBudWxsLFxuICAgICAgICAgICAgICAgIFwiQ3VycmVudCBUaW1lOiBcIixcbiAgICAgICAgICAgICAgICBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygpKSxcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJsaVwiLCBudWxsLFxuICAgICAgICAgICAgICAgIFwiU2VsbGVyIDogXCIsXG4gICAgICAgICAgICAgICAgYXJ0aWNsZS52YWx1ZS52ZW5kb3IpLFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImxpXCIsIG51bGwsXG4gICAgICAgICAgICAgICAgXCJBcnRpY2xlIDogXCIsXG4gICAgICAgICAgICAgICAgYXJ0aWNsZS52YWx1ZS5uYW1lKSxcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJsaVwiLCBudWxsLFxuICAgICAgICAgICAgICAgIFwiUHJpY2UgOiBcIixcbiAgICAgICAgICAgICAgICBhcnRpY2xlLnZhbHVlLnByaWNlKSxcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJsaVwiLCBudWxsLFxuICAgICAgICAgICAgICAgIFwiSW1hZ2UgVXJsIDogXCIsXG4gICAgICAgICAgICAgICAgYXJ0aWNsZS52YWx1ZS5pbWdVcmwpKSxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiLCB7IG9uQ2xpY2s6IGFuYWx5emVVcmwgfSwgXCIgVXBkYXRlXCIpLFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIsIHsgb25DbGljazogZ2VuZXJhdGVFeGNlbENsaXBib2FyZFN0cmluZyB9LFxuICAgICAgICAgICAgJyAnLFxuICAgICAgICAgICAgXCJHZW5lcmF0ZSBFeGNlbCBTdHJpbmdcIiksXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIiwgeyBvbkNsaWNrOiBnZW5lcmF0ZURpc2NvcmRDbGlwYm9hcmRTdHJpbmcgfSxcbiAgICAgICAgICAgICcgJyxcbiAgICAgICAgICAgIFwiR2VuZXJhdGUgRGlzY29yZCBTdHJpbmdcIikpKTtcbn07XG5jb25zdCByb290ID0gY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpKTtcbnJvb3QucmVuZGVyKFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuU3RyaWN0TW9kZSwgbnVsbCxcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFBvcHVwLCBudWxsKSkpO1xuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHRpZDogbW9kdWxlSWQsXG5cdFx0bG9hZGVkOiBmYWxzZSxcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG5cdG1vZHVsZS5sb2FkZWQgPSB0cnVlO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuLy8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbl9fd2VicGFja19yZXF1aXJlX18ubSA9IF9fd2VicGFja19tb2R1bGVzX187XG5cbiIsInZhciBkZWZlcnJlZCA9IFtdO1xuX193ZWJwYWNrX3JlcXVpcmVfXy5PID0gKHJlc3VsdCwgY2h1bmtJZHMsIGZuLCBwcmlvcml0eSkgPT4ge1xuXHRpZihjaHVua0lkcykge1xuXHRcdHByaW9yaXR5ID0gcHJpb3JpdHkgfHwgMDtcblx0XHRmb3IodmFyIGkgPSBkZWZlcnJlZC5sZW5ndGg7IGkgPiAwICYmIGRlZmVycmVkW2kgLSAxXVsyXSA+IHByaW9yaXR5OyBpLS0pIGRlZmVycmVkW2ldID0gZGVmZXJyZWRbaSAtIDFdO1xuXHRcdGRlZmVycmVkW2ldID0gW2NodW5rSWRzLCBmbiwgcHJpb3JpdHldO1xuXHRcdHJldHVybjtcblx0fVxuXHR2YXIgbm90RnVsZmlsbGVkID0gSW5maW5pdHk7XG5cdGZvciAodmFyIGkgPSAwOyBpIDwgZGVmZXJyZWQubGVuZ3RoOyBpKyspIHtcblx0XHR2YXIgW2NodW5rSWRzLCBmbiwgcHJpb3JpdHldID0gZGVmZXJyZWRbaV07XG5cdFx0dmFyIGZ1bGZpbGxlZCA9IHRydWU7XG5cdFx0Zm9yICh2YXIgaiA9IDA7IGogPCBjaHVua0lkcy5sZW5ndGg7IGorKykge1xuXHRcdFx0aWYgKChwcmlvcml0eSAmIDEgPT09IDAgfHwgbm90RnVsZmlsbGVkID49IHByaW9yaXR5KSAmJiBPYmplY3Qua2V5cyhfX3dlYnBhY2tfcmVxdWlyZV9fLk8pLmV2ZXJ5KChrZXkpID0+IChfX3dlYnBhY2tfcmVxdWlyZV9fLk9ba2V5XShjaHVua0lkc1tqXSkpKSkge1xuXHRcdFx0XHRjaHVua0lkcy5zcGxpY2Uoai0tLCAxKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGZ1bGZpbGxlZCA9IGZhbHNlO1xuXHRcdFx0XHRpZihwcmlvcml0eSA8IG5vdEZ1bGZpbGxlZCkgbm90RnVsZmlsbGVkID0gcHJpb3JpdHk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmKGZ1bGZpbGxlZCkge1xuXHRcdFx0ZGVmZXJyZWQuc3BsaWNlKGktLSwgMSlcblx0XHRcdHZhciByID0gZm4oKTtcblx0XHRcdGlmIChyICE9PSB1bmRlZmluZWQpIHJlc3VsdCA9IHI7XG5cdFx0fVxuXHR9XG5cdHJldHVybiByZXN1bHQ7XG59OyIsIi8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSAobW9kdWxlKSA9PiB7XG5cdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuXHRcdCgpID0+IChtb2R1bGVbJ2RlZmF1bHQnXSkgOlxuXHRcdCgpID0+IChtb2R1bGUpO1xuXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCB7IGE6IGdldHRlciB9KTtcblx0cmV0dXJuIGdldHRlcjtcbn07IiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubm1kID0gKG1vZHVsZSkgPT4ge1xuXHRtb2R1bGUucGF0aHMgPSBbXTtcblx0aWYgKCFtb2R1bGUuY2hpbGRyZW4pIG1vZHVsZS5jaGlsZHJlbiA9IFtdO1xuXHRyZXR1cm4gbW9kdWxlO1xufTsiLCIvLyBubyBiYXNlVVJJXG5cbi8vIG9iamVjdCB0byBzdG9yZSBsb2FkZWQgYW5kIGxvYWRpbmcgY2h1bmtzXG4vLyB1bmRlZmluZWQgPSBjaHVuayBub3QgbG9hZGVkLCBudWxsID0gY2h1bmsgcHJlbG9hZGVkL3ByZWZldGNoZWRcbi8vIFtyZXNvbHZlLCByZWplY3QsIFByb21pc2VdID0gY2h1bmsgbG9hZGluZywgMCA9IGNodW5rIGxvYWRlZFxudmFyIGluc3RhbGxlZENodW5rcyA9IHtcblx0XCJwb3B1cFwiOiAwXG59O1xuXG4vLyBubyBjaHVuayBvbiBkZW1hbmQgbG9hZGluZ1xuXG4vLyBubyBwcmVmZXRjaGluZ1xuXG4vLyBubyBwcmVsb2FkZWRcblxuLy8gbm8gSE1SXG5cbi8vIG5vIEhNUiBtYW5pZmVzdFxuXG5fX3dlYnBhY2tfcmVxdWlyZV9fLk8uaiA9IChjaHVua0lkKSA9PiAoaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdID09PSAwKTtcblxuLy8gaW5zdGFsbCBhIEpTT05QIGNhbGxiYWNrIGZvciBjaHVuayBsb2FkaW5nXG52YXIgd2VicGFja0pzb25wQ2FsbGJhY2sgPSAocGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24sIGRhdGEpID0+IHtcblx0dmFyIFtjaHVua0lkcywgbW9yZU1vZHVsZXMsIHJ1bnRpbWVdID0gZGF0YTtcblx0Ly8gYWRkIFwibW9yZU1vZHVsZXNcIiB0byB0aGUgbW9kdWxlcyBvYmplY3QsXG5cdC8vIHRoZW4gZmxhZyBhbGwgXCJjaHVua0lkc1wiIGFzIGxvYWRlZCBhbmQgZmlyZSBjYWxsYmFja1xuXHR2YXIgbW9kdWxlSWQsIGNodW5rSWQsIGkgPSAwO1xuXHRpZihjaHVua0lkcy5zb21lKChpZCkgPT4gKGluc3RhbGxlZENodW5rc1tpZF0gIT09IDApKSkge1xuXHRcdGZvcihtb2R1bGVJZCBpbiBtb3JlTW9kdWxlcykge1xuXHRcdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKG1vcmVNb2R1bGVzLCBtb2R1bGVJZCkpIHtcblx0XHRcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tW21vZHVsZUlkXSA9IG1vcmVNb2R1bGVzW21vZHVsZUlkXTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYocnVudGltZSkgdmFyIHJlc3VsdCA9IHJ1bnRpbWUoX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cdH1cblx0aWYocGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24pIHBhcmVudENodW5rTG9hZGluZ0Z1bmN0aW9uKGRhdGEpO1xuXHRmb3IoO2kgPCBjaHVua0lkcy5sZW5ndGg7IGkrKykge1xuXHRcdGNodW5rSWQgPSBjaHVua0lkc1tpXTtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oaW5zdGFsbGVkQ2h1bmtzLCBjaHVua0lkKSAmJiBpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0pIHtcblx0XHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXVswXSgpO1xuXHRcdH1cblx0XHRpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0gPSAwO1xuXHR9XG5cdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fLk8ocmVzdWx0KTtcbn1cblxudmFyIGNodW5rTG9hZGluZ0dsb2JhbCA9IHNlbGZbXCJ3ZWJwYWNrQ2h1bmtEZWFsX1NuaWZmZXJcIl0gPSBzZWxmW1wid2VicGFja0NodW5rRGVhbF9TbmlmZmVyXCJdIHx8IFtdO1xuY2h1bmtMb2FkaW5nR2xvYmFsLmZvckVhY2god2VicGFja0pzb25wQ2FsbGJhY2suYmluZChudWxsLCAwKSk7XG5jaHVua0xvYWRpbmdHbG9iYWwucHVzaCA9IHdlYnBhY2tKc29ucENhbGxiYWNrLmJpbmQobnVsbCwgY2h1bmtMb2FkaW5nR2xvYmFsLnB1c2guYmluZChjaHVua0xvYWRpbmdHbG9iYWwpKTsiLCIiLCIvLyBzdGFydHVwXG4vLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbi8vIFRoaXMgZW50cnkgbW9kdWxlIGRlcGVuZHMgb24gb3RoZXIgbG9hZGVkIGNodW5rcyBhbmQgZXhlY3V0aW9uIG5lZWQgdG8gYmUgZGVsYXllZFxudmFyIF9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fLk8odW5kZWZpbmVkLCBbXCJ2ZW5kb3JcIl0sICgpID0+IChfX3dlYnBhY2tfcmVxdWlyZV9fKFwiLi9zcmMvcG9wdXAudHN4XCIpKSlcbl9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fLk8oX193ZWJwYWNrX2V4cG9ydHNfXyk7XG4iLCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=