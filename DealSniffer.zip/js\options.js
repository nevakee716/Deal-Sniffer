/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/customConfiguration.tsx":
/*!*************************************!*\
  !*** ./src/customConfiguration.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "emptyConfiguration": () => (/* binding */ emptyConfiguration),
/* harmony export */   "initialConfiguration": () => (/* binding */ initialConfiguration)
/* harmony export */ });
const initialConfiguration = {
    1: {
        fdp: 0,
        name: 'Amazon FR',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.fr',
        uuid: 1,
        warning: '',
        partnerUrl: '',
    },
    2: {
        fdp: 0,
        name: 'Amazon DE',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.de',
        uuid: 2,
        warning: '',
        partnerUrl: '',
    },
    3: {
        fdp: 0,
        name: 'Amazon ES',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.es',
        uuid: 3,
        warning: '',
        partnerUrl: '',
    },
    4: {
        fdp: 0,
        name: 'Amazon IT',
        nameSelector: '#productTitle',
        imgPreUrl: '',
        imgSelector: '#imgTagWrapperId img',
        priceSelector: '#corePrice_feature_div .a-price-whole',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        url: 'amazon.it',
        uuid: 4,
        warning: '',
        partnerUrl: '',
    },
    5: {
        fdp: 20,
        imgPreUrl: '',
        imgSelector: '#mainImageDiv img',
        name: 'BPM-Power',
        nameSelector: '.titleText h1',
        priceReplacers: [],
        priceSelector: '#divProductInfoAndHelp .prezzoScheda',
        url: 'bpm-power.com',
        uuid: 5,
        warning: "Bien Vérifier sous 5j qu'il n'y a pas de dégat sur le colis",
        partnerUrl: '',
    },
    6: {
        fdp: 0,
        uuid: 6,
        name: 'CaseKing',
        url: 'caseking.de',
        nameSelector: '#ck_detail  #detailbox h1',
        priceSelector: '#ck_detail #buybox strong',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        imgPreUrl: 'https:',
        imgSelector: '#ck_detail  #detailbox #img img',
        warning: '',
        partnerUrl: '',
    },
    7: {
        fdp: 0,
        uuid: 7,
        name: 'Cdiscount',
        url: 'cdiscount.com',
        nameSelector: '.fpTMain .fpDesCol h1',
        priceSelector: '.fTopPrice  .fpPrice',
        priceReplacers: [
            {
                replaced: '€',
                replaceBy: '.',
            },
        ],
        imgPreUrl: '',
        imgSelector: '#fpZnPrdMain img#picture0',
        warning: '',
        partnerUrl: '',
    },
    8: {
        fdp: 0,
        uuid: 8,
        name: 'Cybertek',
        url: 'cybertek.fr',
        nameSelector: '.fiche-produit__bloc-achat__container .title_fiche',
        priceSelector: '.fiche-produit__bloc-achat__prix  .fiche_product_price > span',
        priceReplacers: [
            {
                replaced: '€',
                replaceBy: '.',
            },
        ],
        imgPreUrl: '',
        imgSelector: '#fiche-produit__container-photos [data-swiper-slide-index="0"] img',
        warning: '',
        partnerUrl: '',
    },
    9: {
        fdp: 0,
        uuid: 9,
        name: 'Grosbill',
        url: 'grosbill.com',
        nameSelector: '.grb_fch-prod__content-title .grb_fch-prod__title',
        priceSelector: '.fiche-produit-r  .fiche_product_price > span.p-3x',
        priceReplacers: [
            {
                replaced: '€',
                replaceBy: '.',
            },
        ],
        imgPreUrl: 'https://www.grosbill.com',
        imgSelector: '#product_buy [data-swiper-slide-index="0"] img',
        warning: '',
        partnerUrl: '',
    },
    10: {
        fdp: 0,
        uuid: 10,
        name: '1FoDiscount',
        url: '1fodiscount.com',
        nameSelector: '.product-sheet_title',
        priceSelector: '.product-sheet_buybox .product-sheet_buybox_offer_price',
        priceReplacers: [],
        imgPreUrl: '',
        imgSelector: '.product-sheet_slideshow_scrollable img.product-sheet_slideshow_slide_img',
        warning: '',
        partnerUrl: '',
    },
    11: {
        fdp: 0,
        uuid: 11,
        name: 'PcComponentes FR',
        url: 'pccomponentes.fr',
        nameSelector: '#pdp-title',
        priceSelector: '#pdp-price-current-integer',
        priceReplacers: [],
        imgPreUrl: 'https:',
        imgSelector: '#pdp-section-images img',
        warning: '',
        partnerUrl: '',
    },
    12: {
        fdp: 0,
        uuid: 12,
        name: 'PcComponentes ',
        url: 'pccomponentes.com',
        nameSelector: '#pdp-title',
        priceSelector: '#pdp-price-current-integer',
        priceReplacers: [],
        imgPreUrl: 'https:',
        imgSelector: '#pdp-section-images img',
        warning: '',
        partnerUrl: '',
    },
    13: {
        fdp: 0,
        imgPreUrl: '',
        imgSelector: '.elementor-carousel-image',
        name: 'Psk Mega Store',
        nameSelector: '.ce-product-name',
        partnerUrl: '',
        priceReplacers: [],
        priceSelector: '.ce-product-prices span',
        url: 'pskmegastore.com',
        uuid: 13,
        warning: 'En test',
    },
    14: {
        fdp: 0,
        uuid: 14,
        name: 'Rue du Commerce',
        url: 'rueducommerce.fr',
        nameSelector: '.product-name > span',
        priceSelector: '.product__price .dyn_prod_price',
        priceReplacers: [],
        imgPreUrl: '',
        imgSelector: '#gallery .owl-item img',
        warning: '',
        partnerUrl: '',
    },
    15: {
        fdp: 7,
        uuid: 15,
        name: 'Reichelt',
        url: 'www.reichelt.com',
        nameSelector: '.av_articleheader [itemprop="name"]',
        priceSelector: '#av_price',
        priceReplacers: [
            {
                replaced: '.',
                replaceBy: '',
            },
        ],
        imgPreUrl: '',
        imgSelector: '#gallery img',
        warning: '',
        partnerUrl: '',
    },
    16: {
        fdp: 5,
        uuid: 16,
        name: 'TopAchat',
        url: 'topachat.com',
        nameSelector: '.ps-main__product-title',
        priceSelector: '.ps-main__offer  .offer-price__price',
        priceReplacers: [],
        imgPreUrl: 'https:',
        imgSelector: '.product-main-image.ps-main__main-image img',
        warning: '',
        partnerUrl: '',
    },
};
const emptyConfiguration = {
    name: 'New Configuration',
    fdp: 0,
    uuid: 0,
    url: 'new url',
    warning: 'En test',
    priceSelector: '.ce-product-prices span',
    priceReplacers: [],
    imgSelector: '.elementor-carousel-image',
    imgPreUrl: '',
    nameSelector: '.ce-product-name',
    partnerUrl: '',
};




/***/ }),

/***/ "./src/options.tsx":
/*!*************************!*\
  !*** ./src/options.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom/client */ "./node_modules/react-dom/client.js");
/* harmony import */ var _preact_signals_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @preact/signals-react */ "./node_modules/@preact/signals-react/dist/signals.module.js");
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @mui/material/Button */ "./node_modules/@mui/material/Button/Button.js");
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/material/TextField */ "./node_modules/@mui/material/TextField/TextField.js");
/* harmony import */ var _iconify_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @iconify/react */ "./node_modules/@iconify/react/dist/iconify.mjs");
/* harmony import */ var _mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @mui/material/Snackbar */ "./node_modules/@mui/material/Snackbar/Snackbar.js");
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @mui/material/Divider */ "./node_modules/@mui/material/Divider/Divider.js");
/* harmony import */ var _customConfiguration__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./customConfiguration */ "./src/customConfiguration.tsx");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @mui/material */ "./node_modules/@mui/material/InputLabel/InputLabel.js");
/* harmony import */ var _mui_material_Accordion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/material/Accordion */ "./node_modules/@mui/material/Accordion/Accordion.js");
/* harmony import */ var _mui_material_AccordionDetails__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/material/AccordionDetails */ "./node_modules/@mui/material/AccordionDetails/AccordionDetails.js");
/* harmony import */ var _mui_material_AccordionSummary__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material/AccordionSummary */ "./node_modules/@mui/material/AccordionSummary/AccordionSummary.js");
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/material/Typography */ "./node_modules/@mui/material/Typography/Typography.js");














const status = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)(false);
const customConfigurations = (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.signal)(_customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration);
const Options = () => {
    (0,_preact_signals_react__WEBPACK_IMPORTED_MODULE_2__.useSignalEffect)(() => {
        // Restores select box and checkbox state using the preferences
        // stored in chrome.storage.
        chrome.storage.sync.get({
            configurations: _customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration,
        }, (items) => {
            const c = items.configurations;
            Object.keys(_customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration).forEach((key) => {
                if (Object.keys(c).indexOf(key) === -1) {
                    c[key] = _customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration[Number(key)];
                }
            });
            customConfigurations.value = c;
        });
    });
    const [expanded, setExpanded] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
    const saveOptions = () => {
        // Saves options to chrome.storage.sync.
        chrome.storage.sync.set({ configurations: customConfigurations.value }, () => {
            status.value = true;
            const id = setTimeout(() => {
                status.value = false;
            }, 1000);
            return () => clearTimeout(id);
        });
    };
    const handleChange = (panel) => (event, isExpanded) => {
        setExpanded(isExpanded ? panel : false);
    };
    const handleAddConfiguration = () => {
        let c = { ..._customConfiguration__WEBPACK_IMPORTED_MODULE_4__.emptyConfiguration };
        c.uuid = new Date().getTime();
        let cs = {
            ...customConfigurations.value,
        };
        cs[c.uuid] = c;
        customConfigurations.value = cs;
    };
    const handleResetConfiguration = () => {
        customConfigurations.value = _customConfiguration__WEBPACK_IMPORTED_MODULE_4__.initialConfiguration;
    };
    const handleReplacerChange = (customConfiguration, index, field, value) => {
        const newReplacers = [...customConfiguration.priceReplacers];
        newReplacers[index] = {
            ...newReplacers[index],
            [field]: value,
        };
        customConfiguration.priceReplacers = newReplacers;
        let c = {
            ...customConfigurations.value,
        };
        c[customConfiguration.uuid] = customConfiguration;
        customConfigurations.value = c;
    };
    const handleAddReplacer = (customConfiguration) => {
        customConfiguration.priceReplacers.push({
            replaced: '',
            replaceBy: '',
        });
        let c = {
            ...customConfigurations.value,
        };
        c[customConfiguration.uuid] = customConfiguration;
        customConfigurations.value = c;
    };
    const handleDelete = (customConfiguration) => {
        let c = {
            ...customConfigurations.value,
        };
        delete c[customConfiguration.uuid];
        customConfigurations.value = c;
    };
    const handleConfigurationChange = (event, customConfiguration) => {
        if (event.target.id === 'name')
            customConfiguration.name = event.target.value;
        if (event.target.id === 'warning')
            customConfiguration.warning = event.target.value;
        if (event.target.id === 'url')
            customConfiguration.url = event.target.value;
        if (event.target.id === 'nameSelector')
            customConfiguration.nameSelector = event.target.value;
        if (event.target.id === 'imgSelector')
            customConfiguration.imgSelector = event.target.value;
        if (event.target.id === 'imgPreUrl')
            customConfiguration.imgPreUrl = event.target.value;
        if (event.target.id === 'priceSelector')
            customConfiguration.priceSelector = event.target.value;
        let c = {
            ...customConfigurations.value,
        };
        c[customConfiguration.uuid] = customConfiguration;
        customConfigurations.value = c;
    };
    const cardContent = {
        display: 'flex',
        'flex-direction': 'column',
        alignItems: 'strech',
        rowGap: '10px',
        minWidth: '800px',
        width: '100%',
    };
    const cardAction = {
        display: 'flex',
        width: '100%',
        columnGap: '5px',
    };
    const inputStyle = {
        width: '100%',
        flex: 1,
    };
    const priceContainerStyle = {
        display: 'flex',
        columnGap: '5px',
    };
    const priceInputStyle = {
        width: '80%',
    };
    const sellerInputStyle = {
        width: '60%',
    };
    const fdpInputStyle = {
        width: '20%',
    };
    const iconStyle = {
        marginRight: '2px',
    };
    const buttonStyle = {
        flex: 1,
    };
    const dividerStyle = {
        marginTop: '10px',
        marginBottom: '10px',
    };
    const priceReplacerStyle = {
        display: 'flex',
    };
    const priceReplacerInputWrapperStyle = {
        display: 'flex',
        'flex-direction': 'column',
        alignItems: 'strech',
        rowGap: '10px',
    };
    const priceReplacerInputStyle = {
        width: '50%',
    };
    const wrapperStyle = {
        minHeight: '550px',
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: wrapperStyle },
            Object.values(customConfigurations.value)
                .sort((a, b) => a.uuid - b.uuid)
                .map((customConfiguration) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Accordion__WEBPACK_IMPORTED_MODULE_5__["default"], { expanded: expanded === customConfiguration.uuid, onChange: handleChange(customConfiguration.uuid) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_AccordionSummary__WEBPACK_IMPORTED_MODULE_6__["default"], { expandIcon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_3__.Icon, { icon: "ooui:expand" }), "aria-controls": "panel1bh-content", id: "panel1bh-header" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7__["default"], { sx: { width: '33%', flexShrink: 0 } },
                        customConfiguration.name,
                        " - ",
                        customConfiguration.uuid),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7__["default"], { sx: { color: 'text.secondary' } }, customConfiguration.url)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_AccordionDetails__WEBPACK_IMPORTED_MODULE_8__["default"], null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardContent },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardContent },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { style: inputStyle, onChange: (e) => handleConfigurationChange(e, customConfiguration), value: customConfiguration.name, id: "name", label: "Name", defaultValue: "Error" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { style: inputStyle, onChange: (e) => handleConfigurationChange(e, customConfiguration), value: customConfiguration.warning, id: "warning", label: "Warning", defaultValue: "Error" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { style: inputStyle, onChange: (e) => handleConfigurationChange(e, customConfiguration), value: customConfiguration.url, id: "url", label: "Url", defaultValue: "Error", helperText: "this configuration will be used if the url of the current website contain this text" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { style: inputStyle, onChange: (e) => handleConfigurationChange(e, customConfiguration), value: customConfiguration.nameSelector, id: "nameSelector", label: "HTML Name Selector", defaultValue: "Error" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { style: inputStyle, onChange: (e) => handleConfigurationChange(e, customConfiguration), value: customConfiguration.imgSelector, id: "imgSelector", label: "HTML Image Selector", defaultValue: "Error" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { style: inputStyle, onChange: (e) => handleConfigurationChange(e, customConfiguration), value: customConfiguration.imgPreUrl, id: "imgPreUrl", label: "Img pre text", defaultValue: "", helperText: "Sometime the url of the picture doesn't contain the first part of the url, you can add this text in front" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { style: inputStyle, onChange: (e) => handleConfigurationChange(e, customConfiguration), value: customConfiguration.priceSelector, id: "priceSelector", label: "Price Selector", defaultValue: "Error" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: priceReplacerStyle },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_10__["default"], null, "Price Replacers"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_11__["default"], { variant: "text", onClick: (e) => handleAddReplacer(customConfiguration) },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_3__.Icon, { style: iconStyle, icon: "ic:baseline-plus" }))),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: priceReplacerInputWrapperStyle }, customConfiguration.priceReplacers.map((replacer, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: inputStyle, key: index },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { style: priceReplacerInputStyle, label: "Replaced", value: replacer.replaced, onChange: (e) => handleReplacerChange(customConfiguration, index, 'replaced', e.target.value) }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { style: priceReplacerInputStyle, label: "Replace By", value: replacer.replaceBy, onChange: (e) => handleReplacerChange(customConfiguration, index, 'replaceBy', e.target.value) }))))))))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_12__["default"], { style: dividerStyle }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardContent },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: cardAction },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_11__["default"], { variant: "contained", onClick: saveOptions },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_3__.Icon, { style: iconStyle, icon: "pixelarticons:save" }),
                        "Save"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_11__["default"], { variant: "contained", onClick: handleAddConfiguration },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_3__.Icon, { style: iconStyle, icon: "pixelarticons:plus" }),
                        "New Configuration"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_11__["default"], { variant: "contained", onClick: handleResetConfiguration },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_iconify_react__WEBPACK_IMPORTED_MODULE_3__.Icon, { style: iconStyle, icon: "pixelarticons:recycle" }),
                        "Reset Configuration")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material_Snackbar__WEBPACK_IMPORTED_MODULE_13__["default"], { open: status.value, autoHideDuration: 1000, message: "Configuration Saved" })))));
};
const root = (0,react_dom_client__WEBPACK_IMPORTED_MODULE_1__.createRoot)(document.getElementById('root'));
root.render(react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().StrictMode), null,
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Options, null)));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"options": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkdeal_sniffer"] = self["webpackChunkdeal_sniffer"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor"], () => (__webpack_require__("./src/options.tsx")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3B0aW9ucy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQzhCO0FBQ0U7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdRTjtBQUNvQjtBQUNrQjtBQUN0QjtBQUNNO0FBQ1Y7QUFDUTtBQUNGO0FBQ3NDO0FBQ3RDO0FBQ0k7QUFDYztBQUNBO0FBQ1o7QUFDbEQsZUFBZSw2REFBTTtBQUNyQiw2QkFBNkIsNkRBQU0sQ0FBQyxzRUFBb0I7QUFDeEQ7QUFDQSxJQUFJLHNFQUFlO0FBQ25CO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixzRUFBb0I7QUFDaEQsU0FBUztBQUNUO0FBQ0Esd0JBQXdCLHNFQUFvQjtBQUM1QztBQUNBLDZCQUE2QixzRUFBb0I7QUFDakQ7QUFDQSxhQUFhO0FBQ2I7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMLG9DQUFvQyxxREFBYztBQUNsRDtBQUNBO0FBQ0Esa0NBQWtDLDRDQUE0QztBQUM5RTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixHQUFHLG9FQUFrQjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLHNFQUFvQjtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksMERBQW1CLENBQUMsdURBQWM7QUFDOUMsUUFBUSwwREFBbUIsVUFBVSxxQkFBcUI7QUFDMUQ7QUFDQTtBQUNBLCtDQUErQywwREFBbUIsQ0FBQywrREFBUyxJQUFJLG1HQUFtRztBQUNuTCxnQkFBZ0IsMERBQW1CLENBQUMsc0VBQWdCLElBQUksWUFBWSwwREFBbUIsQ0FBQyxnREFBSSxJQUFJLHFCQUFxQiwrREFBK0Q7QUFDcEwsb0JBQW9CLDBEQUFtQixDQUFDLGdFQUFVLElBQUksTUFBTSwrQkFBK0I7QUFDM0Y7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLDBEQUFtQixDQUFDLGdFQUFVLElBQUksTUFBTSwyQkFBMkI7QUFDdkYsZ0JBQWdCLDBEQUFtQixDQUFDLHNFQUFnQjtBQUNwRCxvQkFBb0IsMERBQW1CLFVBQVUsb0JBQW9CO0FBQ3JFLHdCQUF3QiwwREFBbUIsVUFBVSxvQkFBb0I7QUFDekUsNEJBQTRCLDBEQUFtQixDQUFDLCtEQUFTLElBQUksMEtBQTBLO0FBQ3ZPLDRCQUE0QiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLG1MQUFtTDtBQUNoUCw0QkFBNEIsMERBQW1CLENBQUMsK0RBQVMsSUFBSSwwUUFBMFE7QUFDdlUsNEJBQTRCLDBEQUFtQixDQUFDLCtEQUFTLElBQUksd01BQXdNO0FBQ3JRLDRCQUE0QiwwREFBbUIsQ0FBQywrREFBUyxJQUFJLHVNQUF1TTtBQUNwUSw0QkFBNEIsMERBQW1CLENBQUMsK0RBQVMsSUFBSSxnVEFBZ1Q7QUFDN1csNEJBQTRCLDBEQUFtQixDQUFDLCtEQUFTLElBQUksc01BQXNNO0FBQ25RLDRCQUE0QiwwREFBbUIsVUFBVSwyQkFBMkI7QUFDcEYsZ0NBQWdDLDBEQUFtQixDQUFDLHNEQUFVO0FBQzlELGdDQUFnQywwREFBbUIsQ0FBQyw2REFBTSxJQUFJLHlFQUF5RTtBQUN2SSxvQ0FBb0MsMERBQW1CLENBQUMsZ0RBQUksSUFBSSw0Q0FBNEM7QUFDNUcsNEJBQTRCLDBEQUFtQixVQUFVLHVDQUF1QywrREFBK0QsMERBQW1CLFVBQVUsK0JBQStCO0FBQzNOLGdDQUFnQywwREFBbUIsQ0FBQywrREFBUyxJQUFJLDRLQUE0SztBQUM3TyxnQ0FBZ0MsMERBQW1CLENBQUMsK0RBQVMsSUFBSSxnTEFBZ0w7QUFDalAsWUFBWSwwREFBbUIsQ0FBQyw4REFBTyxJQUFJLHFCQUFxQjtBQUNoRSxZQUFZLDBEQUFtQixVQUFVLG9CQUFvQjtBQUM3RCxnQkFBZ0IsMERBQW1CLFVBQVUsbUJBQW1CO0FBQ2hFLG9CQUFvQiwwREFBbUIsQ0FBQyw2REFBTSxJQUFJLDRDQUE0QztBQUM5Rix3QkFBd0IsMERBQW1CLENBQUMsZ0RBQUksSUFBSSw4Q0FBOEM7QUFDbEc7QUFDQSxvQkFBb0IsMERBQW1CLENBQUMsNkRBQU0sSUFBSSx1REFBdUQ7QUFDekcsd0JBQXdCLDBEQUFtQixDQUFDLGdEQUFJLElBQUksOENBQThDO0FBQ2xHO0FBQ0Esb0JBQW9CLDBEQUFtQixDQUFDLDZEQUFNLElBQUkseURBQXlEO0FBQzNHLHdCQUF3QiwwREFBbUIsQ0FBQyxnREFBSSxJQUFJLGlEQUFpRDtBQUNyRztBQUNBLGdCQUFnQiwwREFBbUIsQ0FBQywrREFBUSxJQUFJLDRFQUE0RTtBQUM1SDtBQUNBLGFBQWEsNERBQVU7QUFDdkIsWUFBWSwwREFBbUIsQ0FBQyx5REFBZ0I7QUFDaEQsSUFBSSwwREFBbUI7Ozs7Ozs7VUNqTnZCO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOzs7OztXQzVCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLCtCQUErQix3Q0FBd0M7V0FDdkU7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQkFBaUIscUJBQXFCO1dBQ3RDO1dBQ0E7V0FDQSxrQkFBa0IscUJBQXFCO1dBQ3ZDO1dBQ0E7V0FDQSxLQUFLO1dBQ0w7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOzs7OztXQzNCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsaUNBQWlDLFdBQVc7V0FDNUM7V0FDQTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsR0FBRztXQUNIO1dBQ0E7V0FDQSxDQUFDOzs7OztXQ1BEOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7V0NOQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOzs7OztXQ0pBOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTs7V0FFQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxNQUFNLHFCQUFxQjtXQUMzQjtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBO1dBQ0E7V0FDQTs7Ozs7VUVoREE7VUFDQTtVQUNBO1VBQ0E7VUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL2RlYWwtc25pZmZlci8uL3NyYy9jdXN0b21Db25maWd1cmF0aW9uLnRzeCIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvLi9zcmMvb3B0aW9ucy50c3giLCJ3ZWJwYWNrOi8vZGVhbC1zbmlmZmVyL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY2h1bmsgbG9hZGVkIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvZ2xvYmFsIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvbm9kZSBtb2R1bGUgZGVjb3JhdG9yIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL3J1bnRpbWUvanNvbnAgY2h1bmsgbG9hZGluZyIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly9kZWFsLXNuaWZmZXIvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL2RlYWwtc25pZmZlci93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgaW5pdGlhbENvbmZpZ3VyYXRpb24gPSB7XG4gICAgMToge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIG5hbWU6ICdBbWF6b24gRlInLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcjcHJvZHVjdFRpdGxlJyxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjaW1nVGFnV3JhcHBlcklkIGltZycsXG4gICAgICAgIHByaWNlU2VsZWN0b3I6ICcjY29yZVByaWNlX2ZlYXR1cmVfZGl2IC5hLXByaWNlLXdob2xlJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZXBsYWNlZDogJy4nLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJycsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICB1cmw6ICdhbWF6b24uZnInLFxuICAgICAgICB1dWlkOiAxLFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICAyOiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgbmFtZTogJ0FtYXpvbiBERScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJyNwcm9kdWN0VGl0bGUnLFxuICAgICAgICBpbWdQcmVVcmw6ICcnLFxuICAgICAgICBpbWdTZWxlY3RvcjogJyNpbWdUYWdXcmFwcGVySWQgaW1nJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNjb3JlUHJpY2VfZmVhdHVyZV9kaXYgLmEtcHJpY2Utd2hvbGUnLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJlcGxhY2VkOiAnLicsXG4gICAgICAgICAgICAgICAgcmVwbGFjZUJ5OiAnJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHVybDogJ2FtYXpvbi5kZScsXG4gICAgICAgIHV1aWQ6IDIsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDM6IHtcbiAgICAgICAgZmRwOiAwLFxuICAgICAgICBuYW1lOiAnQW1hem9uIEVTJyxcbiAgICAgICAgbmFtZVNlbGVjdG9yOiAnI3Byb2R1Y3RUaXRsZScsXG4gICAgICAgIGltZ1ByZVVybDogJycsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI2ltZ1RhZ1dyYXBwZXJJZCBpbWcnLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnI2NvcmVQcmljZV9mZWF0dXJlX2RpdiAuYS1wcmljZS13aG9sZScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZWQ6ICcuJyxcbiAgICAgICAgICAgICAgICByZXBsYWNlQnk6ICcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgdXJsOiAnYW1hem9uLmVzJyxcbiAgICAgICAgdXVpZDogMyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG4gICAgNDoge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIG5hbWU6ICdBbWF6b24gSVQnLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcjcHJvZHVjdFRpdGxlJyxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjaW1nVGFnV3JhcHBlcklkIGltZycsXG4gICAgICAgIHByaWNlU2VsZWN0b3I6ICcjY29yZVByaWNlX2ZlYXR1cmVfZGl2IC5hLXByaWNlLXdob2xlJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZXBsYWNlZDogJy4nLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJycsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICB1cmw6ICdhbWF6b24uaXQnLFxuICAgICAgICB1dWlkOiA0LFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICA1OiB7XG4gICAgICAgIGZkcDogMjAsXG4gICAgICAgIGltZ1ByZVVybDogJycsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI21haW5JbWFnZURpdiBpbWcnLFxuICAgICAgICBuYW1lOiAnQlBNLVBvd2VyJyxcbiAgICAgICAgbmFtZVNlbGVjdG9yOiAnLnRpdGxlVGV4dCBoMScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXSxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNkaXZQcm9kdWN0SW5mb0FuZEhlbHAgLnByZXp6b1NjaGVkYScsXG4gICAgICAgIHVybDogJ2JwbS1wb3dlci5jb20nLFxuICAgICAgICB1dWlkOiA1LFxuICAgICAgICB3YXJuaW5nOiBcIkJpZW4gVsOpcmlmaWVyIHNvdXMgNWogcXUnaWwgbid5IGEgcGFzIGRlIGTDqWdhdCBzdXIgbGUgY29saXNcIixcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICA2OiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgdXVpZDogNixcbiAgICAgICAgbmFtZTogJ0Nhc2VLaW5nJyxcbiAgICAgICAgdXJsOiAnY2FzZWtpbmcuZGUnLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcjY2tfZGV0YWlsICAjZGV0YWlsYm94IGgxJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJyNja19kZXRhaWwgI2J1eWJveCBzdHJvbmcnLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJlcGxhY2VkOiAnLicsXG4gICAgICAgICAgICAgICAgcmVwbGFjZUJ5OiAnJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIGltZ1ByZVVybDogJ2h0dHBzOicsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI2NrX2RldGFpbCAgI2RldGFpbGJveCAjaW1nIGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDc6IHtcbiAgICAgICAgZmRwOiAwLFxuICAgICAgICB1dWlkOiA3LFxuICAgICAgICBuYW1lOiAnQ2Rpc2NvdW50JyxcbiAgICAgICAgdXJsOiAnY2Rpc2NvdW50LmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5mcFRNYWluIC5mcERlc0NvbCBoMScsXG4gICAgICAgIHByaWNlU2VsZWN0b3I6ICcuZlRvcFByaWNlICAuZnBQcmljZScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZWQ6ICfigqwnLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJy4nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjZnBablByZE1haW4gaW1nI3BpY3R1cmUwJyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG4gICAgODoge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIHV1aWQ6IDgsXG4gICAgICAgIG5hbWU6ICdDeWJlcnRlaycsXG4gICAgICAgIHVybDogJ2N5YmVydGVrLmZyJyxcbiAgICAgICAgbmFtZVNlbGVjdG9yOiAnLmZpY2hlLXByb2R1aXRfX2Jsb2MtYWNoYXRfX2NvbnRhaW5lciAudGl0bGVfZmljaGUnLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnLmZpY2hlLXByb2R1aXRfX2Jsb2MtYWNoYXRfX3ByaXggIC5maWNoZV9wcm9kdWN0X3ByaWNlID4gc3BhbicsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZWQ6ICfigqwnLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJy4nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjZmljaGUtcHJvZHVpdF9fY29udGFpbmVyLXBob3RvcyBbZGF0YS1zd2lwZXItc2xpZGUtaW5kZXg9XCIwXCJdIGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDk6IHtcbiAgICAgICAgZmRwOiAwLFxuICAgICAgICB1dWlkOiA5LFxuICAgICAgICBuYW1lOiAnR3Jvc2JpbGwnLFxuICAgICAgICB1cmw6ICdncm9zYmlsbC5jb20nLFxuICAgICAgICBuYW1lU2VsZWN0b3I6ICcuZ3JiX2ZjaC1wcm9kX19jb250ZW50LXRpdGxlIC5ncmJfZmNoLXByb2RfX3RpdGxlJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJy5maWNoZS1wcm9kdWl0LXIgIC5maWNoZV9wcm9kdWN0X3ByaWNlID4gc3Bhbi5wLTN4JyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZXBsYWNlZDogJ+KCrCcsXG4gICAgICAgICAgICAgICAgcmVwbGFjZUJ5OiAnLicsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBpbWdQcmVVcmw6ICdodHRwczovL3d3dy5ncm9zYmlsbC5jb20nLFxuICAgICAgICBpbWdTZWxlY3RvcjogJyNwcm9kdWN0X2J1eSBbZGF0YS1zd2lwZXItc2xpZGUtaW5kZXg9XCIwXCJdIGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDEwOiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgdXVpZDogMTAsXG4gICAgICAgIG5hbWU6ICcxRm9EaXNjb3VudCcsXG4gICAgICAgIHVybDogJzFmb2Rpc2NvdW50LmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5wcm9kdWN0LXNoZWV0X3RpdGxlJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJy5wcm9kdWN0LXNoZWV0X2J1eWJveCAucHJvZHVjdC1zaGVldF9idXlib3hfb2ZmZXJfcHJpY2UnLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW10sXG4gICAgICAgIGltZ1ByZVVybDogJycsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnLnByb2R1Y3Qtc2hlZXRfc2xpZGVzaG93X3Njcm9sbGFibGUgaW1nLnByb2R1Y3Qtc2hlZXRfc2xpZGVzaG93X3NsaWRlX2ltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDExOiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgdXVpZDogMTEsXG4gICAgICAgIG5hbWU6ICdQY0NvbXBvbmVudGVzIEZSJyxcbiAgICAgICAgdXJsOiAncGNjb21wb25lbnRlcy5mcicsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJyNwZHAtdGl0bGUnLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnI3BkcC1wcmljZS1jdXJyZW50LWludGVnZXInLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW10sXG4gICAgICAgIGltZ1ByZVVybDogJ2h0dHBzOicsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI3BkcC1zZWN0aW9uLWltYWdlcyBpbWcnLFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICAxMjoge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIHV1aWQ6IDEyLFxuICAgICAgICBuYW1lOiAnUGNDb21wb25lbnRlcyAnLFxuICAgICAgICB1cmw6ICdwY2NvbXBvbmVudGVzLmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJyNwZHAtdGl0bGUnLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnI3BkcC1wcmljZS1jdXJyZW50LWludGVnZXInLFxuICAgICAgICBwcmljZVJlcGxhY2VyczogW10sXG4gICAgICAgIGltZ1ByZVVybDogJ2h0dHBzOicsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnI3BkcC1zZWN0aW9uLWltYWdlcyBpbWcnLFxuICAgICAgICB3YXJuaW5nOiAnJyxcbiAgICAgICAgcGFydG5lclVybDogJycsXG4gICAgfSxcbiAgICAxMzoge1xuICAgICAgICBmZHA6IDAsXG4gICAgICAgIGltZ1ByZVVybDogJycsXG4gICAgICAgIGltZ1NlbGVjdG9yOiAnLmVsZW1lbnRvci1jYXJvdXNlbC1pbWFnZScsXG4gICAgICAgIG5hbWU6ICdQc2sgTWVnYSBTdG9yZScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5jZS1wcm9kdWN0LW5hbWUnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtdLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnLmNlLXByb2R1Y3QtcHJpY2VzIHNwYW4nLFxuICAgICAgICB1cmw6ICdwc2ttZWdhc3RvcmUuY29tJyxcbiAgICAgICAgdXVpZDogMTMsXG4gICAgICAgIHdhcm5pbmc6ICdFbiB0ZXN0JyxcbiAgICB9LFxuICAgIDE0OiB7XG4gICAgICAgIGZkcDogMCxcbiAgICAgICAgdXVpZDogMTQsXG4gICAgICAgIG5hbWU6ICdSdWUgZHUgQ29tbWVyY2UnLFxuICAgICAgICB1cmw6ICdydWVkdWNvbW1lcmNlLmZyJyxcbiAgICAgICAgbmFtZVNlbGVjdG9yOiAnLnByb2R1Y3QtbmFtZSA+IHNwYW4nLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnLnByb2R1Y3RfX3ByaWNlIC5keW5fcHJvZF9wcmljZScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXSxcbiAgICAgICAgaW1nUHJlVXJsOiAnJyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcjZ2FsbGVyeSAub3dsLWl0ZW0gaW1nJyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG4gICAgMTU6IHtcbiAgICAgICAgZmRwOiA3LFxuICAgICAgICB1dWlkOiAxNSxcbiAgICAgICAgbmFtZTogJ1JlaWNoZWx0JyxcbiAgICAgICAgdXJsOiAnd3d3LnJlaWNoZWx0LmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5hdl9hcnRpY2xlaGVhZGVyIFtpdGVtcHJvcD1cIm5hbWVcIl0nLFxuICAgICAgICBwcmljZVNlbGVjdG9yOiAnI2F2X3ByaWNlJyxcbiAgICAgICAgcHJpY2VSZXBsYWNlcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICByZXBsYWNlZDogJy4nLFxuICAgICAgICAgICAgICAgIHJlcGxhY2VCeTogJycsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBpbWdQcmVVcmw6ICcnLFxuICAgICAgICBpbWdTZWxlY3RvcjogJyNnYWxsZXJ5IGltZycsXG4gICAgICAgIHdhcm5pbmc6ICcnLFxuICAgICAgICBwYXJ0bmVyVXJsOiAnJyxcbiAgICB9LFxuICAgIDE2OiB7XG4gICAgICAgIGZkcDogNSxcbiAgICAgICAgdXVpZDogMTYsXG4gICAgICAgIG5hbWU6ICdUb3BBY2hhdCcsXG4gICAgICAgIHVybDogJ3RvcGFjaGF0LmNvbScsXG4gICAgICAgIG5hbWVTZWxlY3RvcjogJy5wcy1tYWluX19wcm9kdWN0LXRpdGxlJyxcbiAgICAgICAgcHJpY2VTZWxlY3RvcjogJy5wcy1tYWluX19vZmZlciAgLm9mZmVyLXByaWNlX19wcmljZScsXG4gICAgICAgIHByaWNlUmVwbGFjZXJzOiBbXSxcbiAgICAgICAgaW1nUHJlVXJsOiAnaHR0cHM6JyxcbiAgICAgICAgaW1nU2VsZWN0b3I6ICcucHJvZHVjdC1tYWluLWltYWdlLnBzLW1haW5fX21haW4taW1hZ2UgaW1nJyxcbiAgICAgICAgd2FybmluZzogJycsXG4gICAgICAgIHBhcnRuZXJVcmw6ICcnLFxuICAgIH0sXG59O1xuY29uc3QgZW1wdHlDb25maWd1cmF0aW9uID0ge1xuICAgIG5hbWU6ICdOZXcgQ29uZmlndXJhdGlvbicsXG4gICAgZmRwOiAwLFxuICAgIHV1aWQ6IDAsXG4gICAgdXJsOiAnbmV3IHVybCcsXG4gICAgd2FybmluZzogJ0VuIHRlc3QnLFxuICAgIHByaWNlU2VsZWN0b3I6ICcuY2UtcHJvZHVjdC1wcmljZXMgc3BhbicsXG4gICAgcHJpY2VSZXBsYWNlcnM6IFtdLFxuICAgIGltZ1NlbGVjdG9yOiAnLmVsZW1lbnRvci1jYXJvdXNlbC1pbWFnZScsXG4gICAgaW1nUHJlVXJsOiAnJyxcbiAgICBuYW1lU2VsZWN0b3I6ICcuY2UtcHJvZHVjdC1uYW1lJyxcbiAgICBwYXJ0bmVyVXJsOiAnJyxcbn07XG5leHBvcnQgeyBlbXB0eUNvbmZpZ3VyYXRpb24gfTtcbmV4cG9ydCB7IGluaXRpYWxDb25maWd1cmF0aW9uIH07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnO1xuaW1wb3J0IHsgc2lnbmFsLCB1c2VTaWduYWxFZmZlY3QgfSBmcm9tICdAcHJlYWN0L3NpZ25hbHMtcmVhY3QnO1xuaW1wb3J0IEJ1dHRvbiBmcm9tICdAbXVpL21hdGVyaWFsL0J1dHRvbic7XG5pbXBvcnQgVGV4dEZpZWxkIGZyb20gJ0BtdWkvbWF0ZXJpYWwvVGV4dEZpZWxkJztcbmltcG9ydCB7IEljb24gfSBmcm9tICdAaWNvbmlmeS9yZWFjdCc7XG5pbXBvcnQgU25hY2tiYXIgZnJvbSAnQG11aS9tYXRlcmlhbC9TbmFja2Jhcic7XG5pbXBvcnQgRGl2aWRlciBmcm9tICdAbXVpL21hdGVyaWFsL0RpdmlkZXInO1xuaW1wb3J0IHsgaW5pdGlhbENvbmZpZ3VyYXRpb24sIGVtcHR5Q29uZmlndXJhdGlvbiwgfSBmcm9tICcuL2N1c3RvbUNvbmZpZ3VyYXRpb24nO1xuaW1wb3J0IHsgSW5wdXRMYWJlbCwgfSBmcm9tICdAbXVpL21hdGVyaWFsJztcbmltcG9ydCBBY2NvcmRpb24gZnJvbSAnQG11aS9tYXRlcmlhbC9BY2NvcmRpb24nO1xuaW1wb3J0IEFjY29yZGlvbkRldGFpbHMgZnJvbSAnQG11aS9tYXRlcmlhbC9BY2NvcmRpb25EZXRhaWxzJztcbmltcG9ydCBBY2NvcmRpb25TdW1tYXJ5IGZyb20gJ0BtdWkvbWF0ZXJpYWwvQWNjb3JkaW9uU3VtbWFyeSc7XG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tICdAbXVpL21hdGVyaWFsL1R5cG9ncmFwaHknO1xuY29uc3Qgc3RhdHVzID0gc2lnbmFsKGZhbHNlKTtcbmNvbnN0IGN1c3RvbUNvbmZpZ3VyYXRpb25zID0gc2lnbmFsKGluaXRpYWxDb25maWd1cmF0aW9uKTtcbmNvbnN0IE9wdGlvbnMgPSAoKSA9PiB7XG4gICAgdXNlU2lnbmFsRWZmZWN0KCgpID0+IHtcbiAgICAgICAgLy8gUmVzdG9yZXMgc2VsZWN0IGJveCBhbmQgY2hlY2tib3ggc3RhdGUgdXNpbmcgdGhlIHByZWZlcmVuY2VzXG4gICAgICAgIC8vIHN0b3JlZCBpbiBjaHJvbWUuc3RvcmFnZS5cbiAgICAgICAgY2hyb21lLnN0b3JhZ2Uuc3luYy5nZXQoe1xuICAgICAgICAgICAgY29uZmlndXJhdGlvbnM6IGluaXRpYWxDb25maWd1cmF0aW9uLFxuICAgICAgICB9LCAoaXRlbXMpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGMgPSBpdGVtcy5jb25maWd1cmF0aW9ucztcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKGluaXRpYWxDb25maWd1cmF0aW9uKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoT2JqZWN0LmtleXMoYykuaW5kZXhPZihrZXkpID09PSAtMSkge1xuICAgICAgICAgICAgICAgICAgICBjW2tleV0gPSBpbml0aWFsQ29uZmlndXJhdGlvbltOdW1iZXIoa2V5KV07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjdXN0b21Db25maWd1cmF0aW9ucy52YWx1ZSA9IGM7XG4gICAgICAgIH0pO1xuICAgIH0pO1xuICAgIGNvbnN0IFtleHBhbmRlZCwgc2V0RXhwYW5kZWRdID0gUmVhY3QudXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IHNhdmVPcHRpb25zID0gKCkgPT4ge1xuICAgICAgICAvLyBTYXZlcyBvcHRpb25zIHRvIGNocm9tZS5zdG9yYWdlLnN5bmMuXG4gICAgICAgIGNocm9tZS5zdG9yYWdlLnN5bmMuc2V0KHsgY29uZmlndXJhdGlvbnM6IGN1c3RvbUNvbmZpZ3VyYXRpb25zLnZhbHVlIH0sICgpID0+IHtcbiAgICAgICAgICAgIHN0YXR1cy52YWx1ZSA9IHRydWU7XG4gICAgICAgICAgICBjb25zdCBpZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHN0YXR1cy52YWx1ZSA9IGZhbHNlO1xuICAgICAgICAgICAgfSwgMTAwMCk7XG4gICAgICAgICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KGlkKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAocGFuZWwpID0+IChldmVudCwgaXNFeHBhbmRlZCkgPT4ge1xuICAgICAgICBzZXRFeHBhbmRlZChpc0V4cGFuZGVkID8gcGFuZWwgOiBmYWxzZSk7XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVBZGRDb25maWd1cmF0aW9uID0gKCkgPT4ge1xuICAgICAgICBsZXQgYyA9IHsgLi4uZW1wdHlDb25maWd1cmF0aW9uIH07XG4gICAgICAgIGMudXVpZCA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgICBsZXQgY3MgPSB7XG4gICAgICAgICAgICAuLi5jdXN0b21Db25maWd1cmF0aW9ucy52YWx1ZSxcbiAgICAgICAgfTtcbiAgICAgICAgY3NbYy51dWlkXSA9IGM7XG4gICAgICAgIGN1c3RvbUNvbmZpZ3VyYXRpb25zLnZhbHVlID0gY3M7XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVSZXNldENvbmZpZ3VyYXRpb24gPSAoKSA9PiB7XG4gICAgICAgIGN1c3RvbUNvbmZpZ3VyYXRpb25zLnZhbHVlID0gaW5pdGlhbENvbmZpZ3VyYXRpb247XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVSZXBsYWNlckNoYW5nZSA9IChjdXN0b21Db25maWd1cmF0aW9uLCBpbmRleCwgZmllbGQsIHZhbHVlKSA9PiB7XG4gICAgICAgIGNvbnN0IG5ld1JlcGxhY2VycyA9IFsuLi5jdXN0b21Db25maWd1cmF0aW9uLnByaWNlUmVwbGFjZXJzXTtcbiAgICAgICAgbmV3UmVwbGFjZXJzW2luZGV4XSA9IHtcbiAgICAgICAgICAgIC4uLm5ld1JlcGxhY2Vyc1tpbmRleF0sXG4gICAgICAgICAgICBbZmllbGRdOiB2YWx1ZSxcbiAgICAgICAgfTtcbiAgICAgICAgY3VzdG9tQ29uZmlndXJhdGlvbi5wcmljZVJlcGxhY2VycyA9IG5ld1JlcGxhY2VycztcbiAgICAgICAgbGV0IGMgPSB7XG4gICAgICAgICAgICAuLi5jdXN0b21Db25maWd1cmF0aW9ucy52YWx1ZSxcbiAgICAgICAgfTtcbiAgICAgICAgY1tjdXN0b21Db25maWd1cmF0aW9uLnV1aWRdID0gY3VzdG9tQ29uZmlndXJhdGlvbjtcbiAgICAgICAgY3VzdG9tQ29uZmlndXJhdGlvbnMudmFsdWUgPSBjO1xuICAgIH07XG4gICAgY29uc3QgaGFuZGxlQWRkUmVwbGFjZXIgPSAoY3VzdG9tQ29uZmlndXJhdGlvbikgPT4ge1xuICAgICAgICBjdXN0b21Db25maWd1cmF0aW9uLnByaWNlUmVwbGFjZXJzLnB1c2goe1xuICAgICAgICAgICAgcmVwbGFjZWQ6ICcnLFxuICAgICAgICAgICAgcmVwbGFjZUJ5OiAnJyxcbiAgICAgICAgfSk7XG4gICAgICAgIGxldCBjID0ge1xuICAgICAgICAgICAgLi4uY3VzdG9tQ29uZmlndXJhdGlvbnMudmFsdWUsXG4gICAgICAgIH07XG4gICAgICAgIGNbY3VzdG9tQ29uZmlndXJhdGlvbi51dWlkXSA9IGN1c3RvbUNvbmZpZ3VyYXRpb247XG4gICAgICAgIGN1c3RvbUNvbmZpZ3VyYXRpb25zLnZhbHVlID0gYztcbiAgICB9O1xuICAgIGNvbnN0IGhhbmRsZURlbGV0ZSA9IChjdXN0b21Db25maWd1cmF0aW9uKSA9PiB7XG4gICAgICAgIGxldCBjID0ge1xuICAgICAgICAgICAgLi4uY3VzdG9tQ29uZmlndXJhdGlvbnMudmFsdWUsXG4gICAgICAgIH07XG4gICAgICAgIGRlbGV0ZSBjW2N1c3RvbUNvbmZpZ3VyYXRpb24udXVpZF07XG4gICAgICAgIGN1c3RvbUNvbmZpZ3VyYXRpb25zLnZhbHVlID0gYztcbiAgICB9O1xuICAgIGNvbnN0IGhhbmRsZUNvbmZpZ3VyYXRpb25DaGFuZ2UgPSAoZXZlbnQsIGN1c3RvbUNvbmZpZ3VyYXRpb24pID0+IHtcbiAgICAgICAgaWYgKGV2ZW50LnRhcmdldC5pZCA9PT0gJ25hbWUnKVxuICAgICAgICAgICAgY3VzdG9tQ29uZmlndXJhdGlvbi5uYW1lID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xuICAgICAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAnd2FybmluZycpXG4gICAgICAgICAgICBjdXN0b21Db25maWd1cmF0aW9uLndhcm5pbmcgPSBldmVudC50YXJnZXQudmFsdWU7XG4gICAgICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICd1cmwnKVxuICAgICAgICAgICAgY3VzdG9tQ29uZmlndXJhdGlvbi51cmwgPSBldmVudC50YXJnZXQudmFsdWU7XG4gICAgICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICduYW1lU2VsZWN0b3InKVxuICAgICAgICAgICAgY3VzdG9tQ29uZmlndXJhdGlvbi5uYW1lU2VsZWN0b3IgPSBldmVudC50YXJnZXQudmFsdWU7XG4gICAgICAgIGlmIChldmVudC50YXJnZXQuaWQgPT09ICdpbWdTZWxlY3RvcicpXG4gICAgICAgICAgICBjdXN0b21Db25maWd1cmF0aW9uLmltZ1NlbGVjdG9yID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xuICAgICAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAnaW1nUHJlVXJsJylcbiAgICAgICAgICAgIGN1c3RvbUNvbmZpZ3VyYXRpb24uaW1nUHJlVXJsID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xuICAgICAgICBpZiAoZXZlbnQudGFyZ2V0LmlkID09PSAncHJpY2VTZWxlY3RvcicpXG4gICAgICAgICAgICBjdXN0b21Db25maWd1cmF0aW9uLnByaWNlU2VsZWN0b3IgPSBldmVudC50YXJnZXQudmFsdWU7XG4gICAgICAgIGxldCBjID0ge1xuICAgICAgICAgICAgLi4uY3VzdG9tQ29uZmlndXJhdGlvbnMudmFsdWUsXG4gICAgICAgIH07XG4gICAgICAgIGNbY3VzdG9tQ29uZmlndXJhdGlvbi51dWlkXSA9IGN1c3RvbUNvbmZpZ3VyYXRpb247XG4gICAgICAgIGN1c3RvbUNvbmZpZ3VyYXRpb25zLnZhbHVlID0gYztcbiAgICB9O1xuICAgIGNvbnN0IGNhcmRDb250ZW50ID0ge1xuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICdmbGV4LWRpcmVjdGlvbic6ICdjb2x1bW4nLFxuICAgICAgICBhbGlnbkl0ZW1zOiAnc3RyZWNoJyxcbiAgICAgICAgcm93R2FwOiAnMTBweCcsXG4gICAgICAgIG1pbldpZHRoOiAnODAwcHgnLFxuICAgICAgICB3aWR0aDogJzEwMCUnLFxuICAgIH07XG4gICAgY29uc3QgY2FyZEFjdGlvbiA9IHtcbiAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgICB3aWR0aDogJzEwMCUnLFxuICAgICAgICBjb2x1bW5HYXA6ICc1cHgnLFxuICAgIH07XG4gICAgY29uc3QgaW5wdXRTdHlsZSA9IHtcbiAgICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICAgICAgZmxleDogMSxcbiAgICB9O1xuICAgIGNvbnN0IHByaWNlQ29udGFpbmVyU3R5bGUgPSB7XG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgY29sdW1uR2FwOiAnNXB4JyxcbiAgICB9O1xuICAgIGNvbnN0IHByaWNlSW5wdXRTdHlsZSA9IHtcbiAgICAgICAgd2lkdGg6ICc4MCUnLFxuICAgIH07XG4gICAgY29uc3Qgc2VsbGVySW5wdXRTdHlsZSA9IHtcbiAgICAgICAgd2lkdGg6ICc2MCUnLFxuICAgIH07XG4gICAgY29uc3QgZmRwSW5wdXRTdHlsZSA9IHtcbiAgICAgICAgd2lkdGg6ICcyMCUnLFxuICAgIH07XG4gICAgY29uc3QgaWNvblN0eWxlID0ge1xuICAgICAgICBtYXJnaW5SaWdodDogJzJweCcsXG4gICAgfTtcbiAgICBjb25zdCBidXR0b25TdHlsZSA9IHtcbiAgICAgICAgZmxleDogMSxcbiAgICB9O1xuICAgIGNvbnN0IGRpdmlkZXJTdHlsZSA9IHtcbiAgICAgICAgbWFyZ2luVG9wOiAnMTBweCcsXG4gICAgICAgIG1hcmdpbkJvdHRvbTogJzEwcHgnLFxuICAgIH07XG4gICAgY29uc3QgcHJpY2VSZXBsYWNlclN0eWxlID0ge1xuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgfTtcbiAgICBjb25zdCBwcmljZVJlcGxhY2VySW5wdXRXcmFwcGVyU3R5bGUgPSB7XG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgJ2ZsZXgtZGlyZWN0aW9uJzogJ2NvbHVtbicsXG4gICAgICAgIGFsaWduSXRlbXM6ICdzdHJlY2gnLFxuICAgICAgICByb3dHYXA6ICcxMHB4JyxcbiAgICB9O1xuICAgIGNvbnN0IHByaWNlUmVwbGFjZXJJbnB1dFN0eWxlID0ge1xuICAgICAgICB3aWR0aDogJzUwJScsXG4gICAgfTtcbiAgICBjb25zdCB3cmFwcGVyU3R5bGUgPSB7XG4gICAgICAgIG1pbkhlaWdodDogJzU1MHB4JyxcbiAgICB9O1xuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbCxcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IHN0eWxlOiB3cmFwcGVyU3R5bGUgfSxcbiAgICAgICAgICAgIE9iamVjdC52YWx1ZXMoY3VzdG9tQ29uZmlndXJhdGlvbnMudmFsdWUpXG4gICAgICAgICAgICAgICAgLnNvcnQoKGEsIGIpID0+IGEudXVpZCAtIGIudXVpZClcbiAgICAgICAgICAgICAgICAubWFwKChjdXN0b21Db25maWd1cmF0aW9uKSA9PiAoUmVhY3QuY3JlYXRlRWxlbWVudChBY2NvcmRpb24sIHsgZXhwYW5kZWQ6IGV4cGFuZGVkID09PSBjdXN0b21Db25maWd1cmF0aW9uLnV1aWQsIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UoY3VzdG9tQ29uZmlndXJhdGlvbi51dWlkKSB9LFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQWNjb3JkaW9uU3VtbWFyeSwgeyBleHBhbmRJY29uOiBSZWFjdC5jcmVhdGVFbGVtZW50KEljb24sIHsgaWNvbjogXCJvb3VpOmV4cGFuZFwiIH0pLCBcImFyaWEtY29udHJvbHNcIjogXCJwYW5lbDFiaC1jb250ZW50XCIsIGlkOiBcInBhbmVsMWJoLWhlYWRlclwiIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVHlwb2dyYXBoeSwgeyBzeDogeyB3aWR0aDogJzMzJScsIGZsZXhTaHJpbms6IDAgfSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgY3VzdG9tQ29uZmlndXJhdGlvbi5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCIgLSBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RvbUNvbmZpZ3VyYXRpb24udXVpZCksXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVHlwb2dyYXBoeSwgeyBzeDogeyBjb2xvcjogJ3RleHQuc2Vjb25kYXJ5JyB9IH0sIGN1c3RvbUNvbmZpZ3VyYXRpb24udXJsKSksXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChBY2NvcmRpb25EZXRhaWxzLCBudWxsLFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IGNhcmRDb250ZW50IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IGNhcmRDb250ZW50IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiAoZSkgPT4gaGFuZGxlQ29uZmlndXJhdGlvbkNoYW5nZShlLCBjdXN0b21Db25maWd1cmF0aW9uKSwgdmFsdWU6IGN1c3RvbUNvbmZpZ3VyYXRpb24ubmFtZSwgaWQ6IFwibmFtZVwiLCBsYWJlbDogXCJOYW1lXCIsIGRlZmF1bHRWYWx1ZTogXCJFcnJvclwiIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dEZpZWxkLCB7IHN0eWxlOiBpbnB1dFN0eWxlLCBvbkNoYW5nZTogKGUpID0+IGhhbmRsZUNvbmZpZ3VyYXRpb25DaGFuZ2UoZSwgY3VzdG9tQ29uZmlndXJhdGlvbiksIHZhbHVlOiBjdXN0b21Db25maWd1cmF0aW9uLndhcm5pbmcsIGlkOiBcIndhcm5pbmdcIiwgbGFiZWw6IFwiV2FybmluZ1wiLCBkZWZhdWx0VmFsdWU6IFwiRXJyb3JcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IChlKSA9PiBoYW5kbGVDb25maWd1cmF0aW9uQ2hhbmdlKGUsIGN1c3RvbUNvbmZpZ3VyYXRpb24pLCB2YWx1ZTogY3VzdG9tQ29uZmlndXJhdGlvbi51cmwsIGlkOiBcInVybFwiLCBsYWJlbDogXCJVcmxcIiwgZGVmYXVsdFZhbHVlOiBcIkVycm9yXCIsIGhlbHBlclRleHQ6IFwidGhpcyBjb25maWd1cmF0aW9uIHdpbGwgYmUgdXNlZCBpZiB0aGUgdXJsIG9mIHRoZSBjdXJyZW50IHdlYnNpdGUgY29udGFpbiB0aGlzIHRleHRcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IChlKSA9PiBoYW5kbGVDb25maWd1cmF0aW9uQ2hhbmdlKGUsIGN1c3RvbUNvbmZpZ3VyYXRpb24pLCB2YWx1ZTogY3VzdG9tQ29uZmlndXJhdGlvbi5uYW1lU2VsZWN0b3IsIGlkOiBcIm5hbWVTZWxlY3RvclwiLCBsYWJlbDogXCJIVE1MIE5hbWUgU2VsZWN0b3JcIiwgZGVmYXVsdFZhbHVlOiBcIkVycm9yXCIgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiAoZSkgPT4gaGFuZGxlQ29uZmlndXJhdGlvbkNoYW5nZShlLCBjdXN0b21Db25maWd1cmF0aW9uKSwgdmFsdWU6IGN1c3RvbUNvbmZpZ3VyYXRpb24uaW1nU2VsZWN0b3IsIGlkOiBcImltZ1NlbGVjdG9yXCIsIGxhYmVsOiBcIkhUTUwgSW1hZ2UgU2VsZWN0b3JcIiwgZGVmYXVsdFZhbHVlOiBcIkVycm9yXCIgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IGlucHV0U3R5bGUsIG9uQ2hhbmdlOiAoZSkgPT4gaGFuZGxlQ29uZmlndXJhdGlvbkNoYW5nZShlLCBjdXN0b21Db25maWd1cmF0aW9uKSwgdmFsdWU6IGN1c3RvbUNvbmZpZ3VyYXRpb24uaW1nUHJlVXJsLCBpZDogXCJpbWdQcmVVcmxcIiwgbGFiZWw6IFwiSW1nIHByZSB0ZXh0XCIsIGRlZmF1bHRWYWx1ZTogXCJcIiwgaGVscGVyVGV4dDogXCJTb21ldGltZSB0aGUgdXJsIG9mIHRoZSBwaWN0dXJlIGRvZXNuJ3QgY29udGFpbiB0aGUgZmlyc3QgcGFydCBvZiB0aGUgdXJsLCB5b3UgY2FuIGFkZCB0aGlzIHRleHQgaW4gZnJvbnRcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRGaWVsZCwgeyBzdHlsZTogaW5wdXRTdHlsZSwgb25DaGFuZ2U6IChlKSA9PiBoYW5kbGVDb25maWd1cmF0aW9uQ2hhbmdlKGUsIGN1c3RvbUNvbmZpZ3VyYXRpb24pLCB2YWx1ZTogY3VzdG9tQ29uZmlndXJhdGlvbi5wcmljZVNlbGVjdG9yLCBpZDogXCJwcmljZVNlbGVjdG9yXCIsIGxhYmVsOiBcIlByaWNlIFNlbGVjdG9yXCIsIGRlZmF1bHRWYWx1ZTogXCJFcnJvclwiIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBzdHlsZTogcHJpY2VSZXBsYWNlclN0eWxlIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSW5wdXRMYWJlbCwgbnVsbCwgXCJQcmljZSBSZXBsYWNlcnNcIiksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uLCB7IHZhcmlhbnQ6IFwidGV4dFwiLCBvbkNsaWNrOiAoZSkgPT4gaGFuZGxlQWRkUmVwbGFjZXIoY3VzdG9tQ29uZmlndXJhdGlvbikgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbiwgeyBzdHlsZTogaWNvblN0eWxlLCBpY29uOiBcImljOmJhc2VsaW5lLXBsdXNcIiB9KSkpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBzdHlsZTogcHJpY2VSZXBsYWNlcklucHV0V3JhcHBlclN0eWxlIH0sIGN1c3RvbUNvbmZpZ3VyYXRpb24ucHJpY2VSZXBsYWNlcnMubWFwKChyZXBsYWNlciwgaW5kZXgpID0+IChSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IGlucHV0U3R5bGUsIGtleTogaW5kZXggfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IHByaWNlUmVwbGFjZXJJbnB1dFN0eWxlLCBsYWJlbDogXCJSZXBsYWNlZFwiLCB2YWx1ZTogcmVwbGFjZXIucmVwbGFjZWQsIG9uQ2hhbmdlOiAoZSkgPT4gaGFuZGxlUmVwbGFjZXJDaGFuZ2UoY3VzdG9tQ29uZmlndXJhdGlvbiwgaW5kZXgsICdyZXBsYWNlZCcsIGUudGFyZ2V0LnZhbHVlKSB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RmllbGQsIHsgc3R5bGU6IHByaWNlUmVwbGFjZXJJbnB1dFN0eWxlLCBsYWJlbDogXCJSZXBsYWNlIEJ5XCIsIHZhbHVlOiByZXBsYWNlci5yZXBsYWNlQnksIG9uQ2hhbmdlOiAoZSkgPT4gaGFuZGxlUmVwbGFjZXJDaGFuZ2UoY3VzdG9tQ29uZmlndXJhdGlvbiwgaW5kZXgsICdyZXBsYWNlQnknLCBlLnRhcmdldC52YWx1ZSkgfSkpKSkpKSkpKSkpLFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChEaXZpZGVyLCB7IHN0eWxlOiBkaXZpZGVyU3R5bGUgfSksXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgc3R5bGU6IGNhcmRDb250ZW50IH0sXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IHN0eWxlOiBjYXJkQWN0aW9uIH0sXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uLCB7IHZhcmlhbnQ6IFwiY29udGFpbmVkXCIsIG9uQ2xpY2s6IHNhdmVPcHRpb25zIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEljb24sIHsgc3R5bGU6IGljb25TdHlsZSwgaWNvbjogXCJwaXhlbGFydGljb25zOnNhdmVcIiB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiU2F2ZVwiKSxcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCdXR0b24sIHsgdmFyaWFudDogXCJjb250YWluZWRcIiwgb25DbGljazogaGFuZGxlQWRkQ29uZmlndXJhdGlvbiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJY29uLCB7IHN0eWxlOiBpY29uU3R5bGUsIGljb246IFwicGl4ZWxhcnRpY29uczpwbHVzXCIgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICBcIk5ldyBDb25maWd1cmF0aW9uXCIpLFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbiwgeyB2YXJpYW50OiBcImNvbnRhaW5lZFwiLCBvbkNsaWNrOiBoYW5kbGVSZXNldENvbmZpZ3VyYXRpb24gfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbiwgeyBzdHlsZTogaWNvblN0eWxlLCBpY29uOiBcInBpeGVsYXJ0aWNvbnM6cmVjeWNsZVwiIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJSZXNldCBDb25maWd1cmF0aW9uXCIpKSxcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFNuYWNrYmFyLCB7IG9wZW46IHN0YXR1cy52YWx1ZSwgYXV0b0hpZGVEdXJhdGlvbjogMTAwMCwgbWVzc2FnZTogXCJDb25maWd1cmF0aW9uIFNhdmVkXCIgfSkpKSkpO1xufTtcbmNvbnN0IHJvb3QgPSBjcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykpO1xucm9vdC5yZW5kZXIoUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5TdHJpY3RNb2RlLCBudWxsLFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoT3B0aW9ucywgbnVsbCkpKTtcbiIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0aWQ6IG1vZHVsZUlkLFxuXHRcdGxvYWRlZDogZmFsc2UsXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0obW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuXHRtb2R1bGUubG9hZGVkID0gdHJ1ZTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbi8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBfX3dlYnBhY2tfbW9kdWxlc19fO1xuXG4iLCJ2YXIgZGVmZXJyZWQgPSBbXTtcbl9fd2VicGFja19yZXF1aXJlX18uTyA9IChyZXN1bHQsIGNodW5rSWRzLCBmbiwgcHJpb3JpdHkpID0+IHtcblx0aWYoY2h1bmtJZHMpIHtcblx0XHRwcmlvcml0eSA9IHByaW9yaXR5IHx8IDA7XG5cdFx0Zm9yKHZhciBpID0gZGVmZXJyZWQubGVuZ3RoOyBpID4gMCAmJiBkZWZlcnJlZFtpIC0gMV1bMl0gPiBwcmlvcml0eTsgaS0tKSBkZWZlcnJlZFtpXSA9IGRlZmVycmVkW2kgLSAxXTtcblx0XHRkZWZlcnJlZFtpXSA9IFtjaHVua0lkcywgZm4sIHByaW9yaXR5XTtcblx0XHRyZXR1cm47XG5cdH1cblx0dmFyIG5vdEZ1bGZpbGxlZCA9IEluZmluaXR5O1xuXHRmb3IgKHZhciBpID0gMDsgaSA8IGRlZmVycmVkLmxlbmd0aDsgaSsrKSB7XG5cdFx0dmFyIFtjaHVua0lkcywgZm4sIHByaW9yaXR5XSA9IGRlZmVycmVkW2ldO1xuXHRcdHZhciBmdWxmaWxsZWQgPSB0cnVlO1xuXHRcdGZvciAodmFyIGogPSAwOyBqIDwgY2h1bmtJZHMubGVuZ3RoOyBqKyspIHtcblx0XHRcdGlmICgocHJpb3JpdHkgJiAxID09PSAwIHx8IG5vdEZ1bGZpbGxlZCA+PSBwcmlvcml0eSkgJiYgT2JqZWN0LmtleXMoX193ZWJwYWNrX3JlcXVpcmVfXy5PKS5ldmVyeSgoa2V5KSA9PiAoX193ZWJwYWNrX3JlcXVpcmVfXy5PW2tleV0oY2h1bmtJZHNbal0pKSkpIHtcblx0XHRcdFx0Y2h1bmtJZHMuc3BsaWNlKGotLSwgMSk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRmdWxmaWxsZWQgPSBmYWxzZTtcblx0XHRcdFx0aWYocHJpb3JpdHkgPCBub3RGdWxmaWxsZWQpIG5vdEZ1bGZpbGxlZCA9IHByaW9yaXR5O1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZihmdWxmaWxsZWQpIHtcblx0XHRcdGRlZmVycmVkLnNwbGljZShpLS0sIDEpXG5cdFx0XHR2YXIgciA9IGZuKCk7XG5cdFx0XHRpZiAociAhPT0gdW5kZWZpbmVkKSByZXN1bHQgPSByO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufTsiLCIvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuX193ZWJwYWNrX3JlcXVpcmVfXy5uID0gKG1vZHVsZSkgPT4ge1xuXHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cblx0XHQoKSA9PiAobW9kdWxlWydkZWZhdWx0J10pIDpcblx0XHQoKSA9PiAobW9kdWxlKTtcblx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgeyBhOiBnZXR0ZXIgfSk7XG5cdHJldHVybiBnZXR0ZXI7XG59OyIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18uZyA9IChmdW5jdGlvbigpIHtcblx0aWYgKHR5cGVvZiBnbG9iYWxUaGlzID09PSAnb2JqZWN0JykgcmV0dXJuIGdsb2JhbFRoaXM7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIHRoaXMgfHwgbmV3IEZ1bmN0aW9uKCdyZXR1cm4gdGhpcycpKCk7XG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ29iamVjdCcpIHJldHVybiB3aW5kb3c7XG5cdH1cbn0pKCk7IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubm1kID0gKG1vZHVsZSkgPT4ge1xuXHRtb2R1bGUucGF0aHMgPSBbXTtcblx0aWYgKCFtb2R1bGUuY2hpbGRyZW4pIG1vZHVsZS5jaGlsZHJlbiA9IFtdO1xuXHRyZXR1cm4gbW9kdWxlO1xufTsiLCIvLyBubyBiYXNlVVJJXG5cbi8vIG9iamVjdCB0byBzdG9yZSBsb2FkZWQgYW5kIGxvYWRpbmcgY2h1bmtzXG4vLyB1bmRlZmluZWQgPSBjaHVuayBub3QgbG9hZGVkLCBudWxsID0gY2h1bmsgcHJlbG9hZGVkL3ByZWZldGNoZWRcbi8vIFtyZXNvbHZlLCByZWplY3QsIFByb21pc2VdID0gY2h1bmsgbG9hZGluZywgMCA9IGNodW5rIGxvYWRlZFxudmFyIGluc3RhbGxlZENodW5rcyA9IHtcblx0XCJvcHRpb25zXCI6IDBcbn07XG5cbi8vIG5vIGNodW5rIG9uIGRlbWFuZCBsb2FkaW5nXG5cbi8vIG5vIHByZWZldGNoaW5nXG5cbi8vIG5vIHByZWxvYWRlZFxuXG4vLyBubyBITVJcblxuLy8gbm8gSE1SIG1hbmlmZXN0XG5cbl9fd2VicGFja19yZXF1aXJlX18uTy5qID0gKGNodW5rSWQpID0+IChpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0gPT09IDApO1xuXG4vLyBpbnN0YWxsIGEgSlNPTlAgY2FsbGJhY2sgZm9yIGNodW5rIGxvYWRpbmdcbnZhciB3ZWJwYWNrSnNvbnBDYWxsYmFjayA9IChwYXJlbnRDaHVua0xvYWRpbmdGdW5jdGlvbiwgZGF0YSkgPT4ge1xuXHR2YXIgW2NodW5rSWRzLCBtb3JlTW9kdWxlcywgcnVudGltZV0gPSBkYXRhO1xuXHQvLyBhZGQgXCJtb3JlTW9kdWxlc1wiIHRvIHRoZSBtb2R1bGVzIG9iamVjdCxcblx0Ly8gdGhlbiBmbGFnIGFsbCBcImNodW5rSWRzXCIgYXMgbG9hZGVkIGFuZCBmaXJlIGNhbGxiYWNrXG5cdHZhciBtb2R1bGVJZCwgY2h1bmtJZCwgaSA9IDA7XG5cdGlmKGNodW5rSWRzLnNvbWUoKGlkKSA9PiAoaW5zdGFsbGVkQ2h1bmtzW2lkXSAhPT0gMCkpKSB7XG5cdFx0Zm9yKG1vZHVsZUlkIGluIG1vcmVNb2R1bGVzKSB7XG5cdFx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8obW9yZU1vZHVsZXMsIG1vZHVsZUlkKSkge1xuXHRcdFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLm1bbW9kdWxlSWRdID0gbW9yZU1vZHVsZXNbbW9kdWxlSWRdO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZihydW50aW1lKSB2YXIgcmVzdWx0ID0gcnVudGltZShfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblx0fVxuXHRpZihwYXJlbnRDaHVua0xvYWRpbmdGdW5jdGlvbikgcGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24oZGF0YSk7XG5cdGZvcig7aSA8IGNodW5rSWRzLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y2h1bmtJZCA9IGNodW5rSWRzW2ldO1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhpbnN0YWxsZWRDaHVua3MsIGNodW5rSWQpICYmIGluc3RhbGxlZENodW5rc1tjaHVua0lkXSkge1xuXHRcdFx0aW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdWzBdKCk7XG5cdFx0fVxuXHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9IDA7XG5cdH1cblx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18uTyhyZXN1bHQpO1xufVxuXG52YXIgY2h1bmtMb2FkaW5nR2xvYmFsID0gc2VsZltcIndlYnBhY2tDaHVua2RlYWxfc25pZmZlclwiXSA9IHNlbGZbXCJ3ZWJwYWNrQ2h1bmtkZWFsX3NuaWZmZXJcIl0gfHwgW107XG5jaHVua0xvYWRpbmdHbG9iYWwuZm9yRWFjaCh3ZWJwYWNrSnNvbnBDYWxsYmFjay5iaW5kKG51bGwsIDApKTtcbmNodW5rTG9hZGluZ0dsb2JhbC5wdXNoID0gd2VicGFja0pzb25wQ2FsbGJhY2suYmluZChudWxsLCBjaHVua0xvYWRpbmdHbG9iYWwucHVzaC5iaW5kKGNodW5rTG9hZGluZ0dsb2JhbCkpOyIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgZGVwZW5kcyBvbiBvdGhlciBsb2FkZWQgY2h1bmtzIGFuZCBleGVjdXRpb24gbmVlZCB0byBiZSBkZWxheWVkXG52YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IF9fd2VicGFja19yZXF1aXJlX18uTyh1bmRlZmluZWQsIFtcInZlbmRvclwiXSwgKCkgPT4gKF9fd2VicGFja19yZXF1aXJlX18oXCIuL3NyYy9vcHRpb25zLnRzeFwiKSkpXG5fX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXy5PKF9fd2VicGFja19leHBvcnRzX18pO1xuIiwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9