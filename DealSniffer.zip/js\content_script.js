/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!********************************!*\
  !*** ./src/content_script.tsx ***!
  \********************************/

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg.color) {
        console.log("Receive color = " + msg.color);
        document.body.style.backgroundColor = msg.color;
        sendResponse("Change color to " + msg.color);
    }
    else {
        sendResponse("Color message is none.");
    }
});

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudF9zY3JpcHQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vRGVhbCBTbmlmZmVyLy4vc3JjL2NvbnRlbnRfc2NyaXB0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihmdW5jdGlvbiAobXNnLCBzZW5kZXIsIHNlbmRSZXNwb25zZSkge1xuICAgIGlmIChtc2cuY29sb3IpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJSZWNlaXZlIGNvbG9yID0gXCIgKyBtc2cuY29sb3IpO1xuICAgICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLmJhY2tncm91bmRDb2xvciA9IG1zZy5jb2xvcjtcbiAgICAgICAgc2VuZFJlc3BvbnNlKFwiQ2hhbmdlIGNvbG9yIHRvIFwiICsgbXNnLmNvbG9yKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHNlbmRSZXNwb25zZShcIkNvbG9yIG1lc3NhZ2UgaXMgbm9uZS5cIik7XG4gICAgfVxufSk7XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=